﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Boolean UnityEngine.SubsystemRegistration::CreateDescriptor(UnityEngine.SubsystemDescriptor)
extern void SubsystemRegistration_CreateDescriptor_m6C69D0D80C317F66888FEBF67DFEE327E3462A54 (void);
// 0x00000002 System.Void UnityEngine.SubsystemRegistration::.cctor()
extern void SubsystemRegistration__cctor_mBF0AA0C4A0DC12B169964CBE93D081FCA7CA9643 (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	SubsystemRegistration_CreateDescriptor_m6C69D0D80C317F66888FEBF67DFEE327E3462A54,
	SubsystemRegistration__cctor_mBF0AA0C4A0DC12B169964CBE93D081FCA7CA9643,
};
static const int32_t s_InvokerIndices[2] = 
{
	4331,
	4497,
};
extern const CustomAttributesCacheGenerator g_Unity_Subsystem_Registration_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_Subsystem_Registration_CodeGenModule;
const Il2CppCodeGenModule g_Unity_Subsystem_Registration_CodeGenModule = 
{
	"Unity.Subsystem.Registration.dll",
	2,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_Unity_Subsystem_Registration_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
