﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_mAC9C3449B2C8D4A1D89A8CD60B6B4EBB909A549E (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor()
extern void IsReadOnlyAttribute__ctor_m8B9BA0350D77FDDE0896361AA2369B9EA7707B80 (void);
// 0x00000003 System.Boolean InputHelpers::IsPressed(UnityEngine.XR.InputDevice,InputHelpers/Button,System.Boolean&,System.Single)
extern void InputHelpers_IsPressed_mB00997B52B6344649223F8EADB92DDEDB538C756 (void);
// 0x00000004 System.Void InputHelpers::.cctor()
extern void InputHelpers__cctor_m548375FA7CA8F39D5314E887BFFBE3235274F7F2 (void);
// 0x00000005 System.Void InputHelpers/ButtonInfo::.ctor(System.String,InputHelpers/ButtonReadType)
extern void ButtonInfo__ctor_m3CD43D1CD1FBA164B697DC217C9E21B157386DE3 (void);
// 0x00000006 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_positionAction()
extern void ActionBasedController_get_positionAction_m0AADCA1A0CF65DC7C9A1F61D70E6B42EE356DEA3 (void);
// 0x00000007 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_positionAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_positionAction_m3DD4181DF028697C4E759CE2AA43CE3ADA29D414 (void);
// 0x00000008 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_rotationAction()
extern void ActionBasedController_get_rotationAction_mB57BAAEDBC922F5FC8D6B8D4C2713F64988FDC25 (void);
// 0x00000009 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_rotationAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_rotationAction_m3152E9F30F4B13D7093A0F61A5A8C9552558B37B (void);
// 0x0000000A UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_selectAction()
extern void ActionBasedController_get_selectAction_m6ADEA0B73AE3166CF6B02388146ECC1F81A1682E (void);
// 0x0000000B System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_selectAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_selectAction_m4E612329CD70CC6362F3B016B90B5FCF4BECDB35 (void);
// 0x0000000C UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_activateAction()
extern void ActionBasedController_get_activateAction_m200FF238E6977609B538D02C91BD99745948BD65 (void);
// 0x0000000D System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_activateAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_activateAction_mE7BD4D80E6E3F59A377528DECBDCFE330E78BF40 (void);
// 0x0000000E UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_uiPressAction()
extern void ActionBasedController_get_uiPressAction_mD20BCF7C349822D5AFEA00ACB8B7DB262541E6AC (void);
// 0x0000000F System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_uiPressAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_uiPressAction_mEFA630BEFEFFDA66C597D6F8A18D9BF019626B79 (void);
// 0x00000010 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_hapticDeviceAction()
extern void ActionBasedController_get_hapticDeviceAction_mC7F3DCF6C1252AFDBD3E79CF6BFAE2521DB6BE36 (void);
// 0x00000011 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_hapticDeviceAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_hapticDeviceAction_m18609366C2182371B1129EE6760EF120BF4923E1 (void);
// 0x00000012 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_rotateAnchorAction()
extern void ActionBasedController_get_rotateAnchorAction_m734CD5E7AD3A576AA923AD4BBD6F33D0D9860BFD (void);
// 0x00000013 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_rotateAnchorAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_rotateAnchorAction_mD34C2A5E9330D248ECF49DE278EA165A78236FBE (void);
// 0x00000014 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_translateAnchorAction()
extern void ActionBasedController_get_translateAnchorAction_m0BF8F391A2E284BD8D9C394B6A779B2959AD822E (void);
// 0x00000015 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_translateAnchorAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_translateAnchorAction_m0DA2728F63003878AD450F04198F3DD925FA18D8 (void);
// 0x00000016 System.Single UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_buttonPressPoint()
extern void ActionBasedController_get_buttonPressPoint_mD9B5EFC9425E80B5F0D791F0CE53C931B4091C84 (void);
// 0x00000017 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_buttonPressPoint(System.Single)
extern void ActionBasedController_set_buttonPressPoint_mE1A59AEF71617036B254A944EC891770B835F9F8 (void);
// 0x00000018 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::OnEnable()
extern void ActionBasedController_OnEnable_m6C33FC4A4969963F02A25EBB371A222281FDDB99 (void);
// 0x00000019 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::OnDisable()
extern void ActionBasedController_OnDisable_m069B9518CAC115BB8E238E9B70054A5A4A1D28D8 (void);
// 0x0000001A System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void ActionBasedController_UpdateTrackingInput_m568B22E088E8F01F7BFC85B7976833A9297856B8 (void);
// 0x0000001B System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void ActionBasedController_UpdateInput_m0B3DDE7A00DE36ADCF14E08D29F62F78A2FEF82B (void);
// 0x0000001C System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::SendHapticImpulse(System.Single,System.Single)
extern void ActionBasedController_SendHapticImpulse_m9F724BBED89194C5CAE2732B193A118BD1D762A9 (void);
// 0x0000001D System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::EnableAllDirectActions()
extern void ActionBasedController_EnableAllDirectActions_m8C9F714E9D9C9DBE082A4D88D6DE707ABBAE3441 (void);
// 0x0000001E System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::DisableAllDirectActions()
extern void ActionBasedController_DisableAllDirectActions_m1EBA07E5B1414C9D2493D21C5996E2DFC05E587D (void);
// 0x0000001F System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_SetInputActionProperty_m98D4EFE06FF96DBA4068B7E020270C2A35D231A4 (void);
// 0x00000020 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::ComputeInteractionActionStates(System.Boolean,UnityEngine.XR.Interaction.Toolkit.InteractionState&)
extern void ActionBasedController_ComputeInteractionActionStates_m6B8D5FE7B0DFF2E69916825EBD28145DFF95C01B (void);
// 0x00000021 System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::IsDisabledReferenceAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_IsDisabledReferenceAction_mCF9D764FF310B57381355CA4FF2E30480AA20449 (void);
// 0x00000022 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::.ctor()
extern void ActionBasedController__ctor_m0C9570FA19BF70B4A388ACA2CAA279E6AC263B1D (void);
// 0x00000023 System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::<UpdateInput>g__IsPressed|41_0(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_U3CUpdateInputU3Eg__IsPressedU7C41_0_m4C6B3A82BE1DB5BBC3BA0677F86EA30EAE4B120F (void);
// 0x00000024 UnityEngine.XR.Interaction.Toolkit.XRBaseController/UpdateType UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_updateTrackingType()
extern void XRBaseController_get_updateTrackingType_m5617506ED652752BB55754ABA4DE8C2E894C14C4 (void);
// 0x00000025 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_updateTrackingType(UnityEngine.XR.Interaction.Toolkit.XRBaseController/UpdateType)
extern void XRBaseController_set_updateTrackingType_mB6BCA78BFDE129C3F9D2CA469D4BB764C5CACF55 (void);
// 0x00000026 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_enableInputTracking()
extern void XRBaseController_get_enableInputTracking_mF608E1C27CF0A0910FB841F7158E1867DD1599AD (void);
// 0x00000027 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_enableInputTracking(System.Boolean)
extern void XRBaseController_set_enableInputTracking_m89ED425F3D4A6831A52999D5FC1E4948E0A4F5C9 (void);
// 0x00000028 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_enableInputActions()
extern void XRBaseController_get_enableInputActions_mF6250B1868B5D622924B6CDF8BA3596C1068FDC2 (void);
// 0x00000029 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_enableInputActions(System.Boolean)
extern void XRBaseController_set_enableInputActions_mDA19367438E10EF377988F45C871F22E38D737D8 (void);
// 0x0000002A UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelPrefab()
extern void XRBaseController_get_modelPrefab_m87435DFA1E0F3B408894381BDDDC1F5C484BB1E2 (void);
// 0x0000002B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelPrefab(UnityEngine.Transform)
extern void XRBaseController_set_modelPrefab_mDE3FFA7597E30C78EF0E2F6231F2BE66A40E859E (void);
// 0x0000002C UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelTransform()
extern void XRBaseController_get_modelTransform_m58AD96452188704A96861A17491678489CF3F523 (void);
// 0x0000002D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelTransform(UnityEngine.Transform)
extern void XRBaseController_set_modelTransform_m820A35F61B577A9D344E07DA5CD64B1B0A134467 (void);
// 0x0000002E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_animateModel()
extern void XRBaseController_get_animateModel_m5F530843D2729A625443EED53D8099E4C15742BE (void);
// 0x0000002F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_animateModel(System.Boolean)
extern void XRBaseController_set_animateModel_m3B2EEAC7737A4526ED3631644DA2E796DBD60A06 (void);
// 0x00000030 System.String UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelSelectTransition()
extern void XRBaseController_get_modelSelectTransition_m13743153B2E41C5AC23F7FC47B140C25C55F1824 (void);
// 0x00000031 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelSelectTransition(System.String)
extern void XRBaseController_set_modelSelectTransition_m20BD140741F5672C0827EA2CDBAB99BAC863CDE3 (void);
// 0x00000032 System.String UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelDeSelectTransition()
extern void XRBaseController_get_modelDeSelectTransition_m17385AD0220F07F344061A9F7B0753A3E7401DA1 (void);
// 0x00000033 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelDeSelectTransition(System.String)
extern void XRBaseController_set_modelDeSelectTransition_m2A32CD331F3268D4AACC295F0E201E7DE947C5A7 (void);
// 0x00000034 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_anchorControlDeadzone()
extern void XRBaseController_get_anchorControlDeadzone_m9F9DBCEC323C94B24516AE0FF52E40A1E627F4C7 (void);
// 0x00000035 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_anchorControlDeadzone(System.Single)
extern void XRBaseController_set_anchorControlDeadzone_m41337A9B4A24CAFE99F9690F34A6612D895221D3 (void);
// 0x00000036 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_anchorControlOffAxisDeadzone()
extern void XRBaseController_get_anchorControlOffAxisDeadzone_mC1893C2994AFFF6BD8AA4C5826C2D4BEF811BAD7 (void);
// 0x00000037 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_anchorControlOffAxisDeadzone(System.Single)
extern void XRBaseController_set_anchorControlOffAxisDeadzone_mB1363FD2B8EC8080427D152610508FE63BE33495 (void);
// 0x00000038 UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_selectInteractionState()
extern void XRBaseController_get_selectInteractionState_mBDF090DC9419A5EF00CFA30A2EC986DCEEDF739E (void);
// 0x00000039 UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_activateInteractionState()
extern void XRBaseController_get_activateInteractionState_m9AFCE26B34A251949B7D74148DA864067F01F9CB (void);
// 0x0000003A UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_uiPressInteractionState()
extern void XRBaseController_get_uiPressInteractionState_mC7F202067BF61FA31D26D27874EE3BB4F3958620 (void);
// 0x0000003B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_hideControllerModel()
extern void XRBaseController_get_hideControllerModel_m8AD5F3E01DC84FB16CE4D6026B706320723AF0E4 (void);
// 0x0000003C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_hideControllerModel(System.Boolean)
extern void XRBaseController_set_hideControllerModel_m26D1BC994A9855F0B3C1A25BC999FEF71E557AC8 (void);
// 0x0000003D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::Awake()
extern void XRBaseController_Awake_m8B420246FD368F0B65C7D8C98F70954802F495E2 (void);
// 0x0000003E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnEnable()
extern void XRBaseController_OnEnable_m02CFDA51FD8E7690CA0086BAE7FA2D12E61674AB (void);
// 0x0000003F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnDisable()
extern void XRBaseController_OnDisable_mA62B8654196C51B7738936EA29FB839F2C3E1DA8 (void);
// 0x00000040 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::Update()
extern void XRBaseController_Update_m358201A21E9EB4CC20F928066F0BDBB6C56CFE0E (void);
// 0x00000041 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::PerformSetup()
extern void XRBaseController_PerformSetup_m31B932595CFD9A5F21F8B97CEB9519D1A303F2CD (void);
// 0x00000042 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::SetupModel()
extern void XRBaseController_SetupModel_m0585E51D87E28C6A808E15ADFF8EFCDE99BBF457 (void);
// 0x00000043 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateController()
extern void XRBaseController_UpdateController_mF301729BB5049513E7C212730AA649C72FD25AE4 (void);
// 0x00000044 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnBeforeRender()
extern void XRBaseController_OnBeforeRender_m1ADEAF2008D945D2DDC07C0A03CB52F54F257722 (void);
// 0x00000045 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::GetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState&)
extern void XRBaseController_GetControllerState_m45F78F6C3292FC3293300D622AF88618FA7712B2 (void);
// 0x00000046 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::SetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_SetControllerState_m2AF4981ECD219E50C89BFD37D1E95E40811DE0C9 (void);
// 0x00000047 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::ApplyControllerState(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase,UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_ApplyControllerState_m1EA076044D7E7D03D520B54D4A67C4B2AF7B8A9C (void);
// 0x00000048 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_UpdateTrackingInput_m1F8E54931C67A201C3E0A08BA742C5FD11FE844C (void);
// 0x00000049 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateInputInternal(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_UpdateInputInternal_m57AE52F3C07E29C2FFE882773F0E2A6E0202F0BB (void);
// 0x0000004A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_UpdateInput_mCC315B351B14AB1B3D9D16B41FECEFE4FE0903B6 (void);
// 0x0000004B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateControllerModelAnimation()
extern void XRBaseController_UpdateControllerModelAnimation_m3490A339D3385CC306C28A9E94A8B2C0D5CD9CF4 (void);
// 0x0000004C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateControllerPose(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void XRBaseController_UpdateControllerPose_m69E9DC66E14A7400335E32BC2E22F5762F1711DD (void);
// 0x0000004D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::SendHapticImpulse(System.Single,System.Single)
extern void XRBaseController_SendHapticImpulse_m01B5416F7A4FD009E2D1D75B9891F0E8F20FDFDF (void);
// 0x0000004E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::.ctor()
extern void XRBaseController__ctor_m038B0CE7FE2B33C2127099D7F4D22749F83FE8D3 (void);
// 0x0000004F System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_active()
extern void InteractionState_get_active_mEB70F6F01B332BF518B3F7D0048614DF3D11416D (void);
// 0x00000050 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_active(System.Boolean)
extern void InteractionState_set_active_m4D33BA01AC08B427995FB81C61AADE55059E5D8E (void);
// 0x00000051 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_activatedThisFrame()
extern void InteractionState_get_activatedThisFrame_m3805CFB50DE51865E8B0CF64EAD512E6535F5990 (void);
// 0x00000052 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_activatedThisFrame(System.Boolean)
extern void InteractionState_set_activatedThisFrame_mC09EBD51CFF932E8EF2D2234D98F6F4A68220C04 (void);
// 0x00000053 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_deactivatedThisFrame()
extern void InteractionState_get_deactivatedThisFrame_m33159255C5B5A45C78F331152CAD09878CDBECC5 (void);
// 0x00000054 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_deactivatedThisFrame(System.Boolean)
extern void InteractionState_set_deactivatedThisFrame_m6463CD864EB7142897A97F8C32485016A6282369 (void);
// 0x00000055 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_deActivatedThisFrame()
extern void InteractionState_get_deActivatedThisFrame_m77D75E7C5865BE2C111506E4CC5F090AE7F813DB (void);
// 0x00000056 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_deActivatedThisFrame(System.Boolean)
extern void InteractionState_set_deActivatedThisFrame_m739E5BF6021D03E5C2D9BA5AD6902AD1D2AA6156 (void);
// 0x00000057 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::ResetFrameDependent()
extern void InteractionState_ResetFrameDependent_m81E03E441EFBB763DC1DB870345606C2CFB85996 (void);
// 0x00000058 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::Reset()
extern void InteractionState_Reset_m7144B5C32B6E7118DA7048CC9A5FE9B3A30E3656 (void);
// 0x00000059 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor()
extern void XRControllerState__ctor_m614CC3405B369D91A759FF9A4972B96EC7B997D7 (void);
// 0x0000005A System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRControllerState__ctor_mE65319B73768784FCDB2B637AE4F3DFA410F593D (void);
// 0x0000005B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerState__ctor_mDA85D68054385D4727F140A8E1CD38953573F18D (void);
// 0x0000005C System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::SimulateInteractionState(System.Boolean,UnityEngine.XR.Interaction.Toolkit.InteractionState&)
extern void XRControllerState_SimulateInteractionState_mD9BD85F6531A81B8F01FA1232076872754CFBDDB (void);
// 0x0000005D System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::ResetFrameDependentStates()
extern void XRControllerState_ResetFrameDependentStates_mFA9DF9BFA158AD761B225BCA93D76D81111487BE (void);
// 0x0000005E System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::ResetInputs()
extern void XRControllerState_ResetInputs_m7EAB3D35A24CAD36078397F16352407C516D1441 (void);
// 0x0000005F System.String UnityEngine.XR.Interaction.Toolkit.XRControllerState::ToString()
extern void XRControllerState_ToString_mA21AA8A881F229A4607F46B88AA145D1CD47F57A (void);
// 0x00000060 UnityEngine.XR.XRNode UnityEngine.XR.Interaction.Toolkit.XRController::get_controllerNode()
extern void XRController_get_controllerNode_m54C0C4162BB973DB887DD1ECF3A7A0E56655BA46 (void);
// 0x00000061 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_controllerNode(UnityEngine.XR.XRNode)
extern void XRController_set_controllerNode_m13905CA96B3F68C853691AD1E38BEF45ECA859BB (void);
// 0x00000062 InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_selectUsage()
extern void XRController_get_selectUsage_m7FD077238F16FEC9A1CF4B4B9C0CD50021A8CB25 (void);
// 0x00000063 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_selectUsage(InputHelpers/Button)
extern void XRController_set_selectUsage_mD6848C9CBB851F850B85A636FD6438B92380451E (void);
// 0x00000064 InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_activateUsage()
extern void XRController_get_activateUsage_m2FB0740C8E4F85ACC3842BFC97B34DCABAC816F3 (void);
// 0x00000065 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_activateUsage(InputHelpers/Button)
extern void XRController_set_activateUsage_m0B417D2EC47E06F546D35E329544587349D91BFA (void);
// 0x00000066 InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_uiPressUsage()
extern void XRController_get_uiPressUsage_mB0EE585B594A385F1A3296DC30FFA4B22639B335 (void);
// 0x00000067 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_uiPressUsage(InputHelpers/Button)
extern void XRController_set_uiPressUsage_m6BEB77B69F61E2A5D5E7FD174F4F048AA53DC88B (void);
// 0x00000068 System.Single UnityEngine.XR.Interaction.Toolkit.XRController::get_axisToPressThreshold()
extern void XRController_get_axisToPressThreshold_m65C5EA04847A1D5F41BFCC3D6ABF90EA310CC571 (void);
// 0x00000069 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_axisToPressThreshold(System.Single)
extern void XRController_set_axisToPressThreshold_m865B390F6B0CEE1E850760BE2900A0021290C973 (void);
// 0x0000006A InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_rotateObjectLeft()
extern void XRController_get_rotateObjectLeft_m28EBEE652169242B46BD46EDAC6C15547E786633 (void);
// 0x0000006B System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_rotateObjectLeft(InputHelpers/Button)
extern void XRController_set_rotateObjectLeft_m5713AAF2B3F7058207C486299173189F6075846F (void);
// 0x0000006C InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_rotateObjectRight()
extern void XRController_get_rotateObjectRight_mF5F44ECAF1C5D48483549C1950F0F222B58B16B1 (void);
// 0x0000006D System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_rotateObjectRight(InputHelpers/Button)
extern void XRController_set_rotateObjectRight_mB7E16FA470B26434C01C9674D56AD094BA7D8F57 (void);
// 0x0000006E InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_moveObjectIn()
extern void XRController_get_moveObjectIn_m0E91BDC51941009816B19343CEDE21AA32D6611E (void);
// 0x0000006F System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_moveObjectIn(InputHelpers/Button)
extern void XRController_set_moveObjectIn_m6A51FB0FB29FA121A92B693CAA40B11C8217E299 (void);
// 0x00000070 InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_moveObjectOut()
extern void XRController_get_moveObjectOut_m9CB4766D0202BFE57668C449121551DF09B24714 (void);
// 0x00000071 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_moveObjectOut(InputHelpers/Button)
extern void XRController_set_moveObjectOut_m2F816B3C99BCE961C233FE216A534CE5142AFA07 (void);
// 0x00000072 UnityEngine.Experimental.XR.Interaction.BasePoseProvider UnityEngine.XR.Interaction.Toolkit.XRController::get_poseProvider()
extern void XRController_get_poseProvider_m80650DFEEDD4A1151248C71081FFAEA20C5D05D3 (void);
// 0x00000073 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_poseProvider(UnityEngine.Experimental.XR.Interaction.BasePoseProvider)
extern void XRController_set_poseProvider_mE40E2D1BAA62CD70BC69081C052AF6FCF572938F (void);
// 0x00000074 UnityEngine.XR.InputDevice UnityEngine.XR.Interaction.Toolkit.XRController::get_inputDevice()
extern void XRController_get_inputDevice_m4CC8E85AD90CF53E7620EF97C4A96E7C925C622A (void);
// 0x00000075 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRController_UpdateTrackingInput_m8E43C8418966B0FE73EAEF9F190D97B7A1589A39 (void);
// 0x00000076 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRController_UpdateInput_mEED730BC2C5E30789F0C2254FCC317EB1F2F9B15 (void);
// 0x00000077 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::HandleInteractionAction(InputHelpers/Button,UnityEngine.XR.Interaction.Toolkit.InteractionState&)
extern void XRController_HandleInteractionAction_mEEDCEF64135CD4F98C84D452490D67E65F57CA13 (void);
// 0x00000078 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::SendHapticImpulse(System.Single,System.Single)
extern void XRController_SendHapticImpulse_m9C734D7336276A6C455E6BE93F4D5178209A7598 (void);
// 0x00000079 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::.ctor()
extern void XRController__ctor_m88DB4C4C3D0C68CB314F15CA017C275FD6FB46B3 (void);
// 0x0000007A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_playOnStart()
extern void XRControllerRecorder_get_playOnStart_mBA5F968462B33ECC485445E339A4295739E1409D (void);
// 0x0000007B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_playOnStart(System.Boolean)
extern void XRControllerRecorder_set_playOnStart_m1F34C285B92D68751506B22056753C141B9A75A3 (void);
// 0x0000007C UnityEngine.XR.Interaction.Toolkit.XRControllerRecording UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_recording()
extern void XRControllerRecorder_get_recording_mBB8CD5A9A982F39C1C7B68F2E1FC93C48C1DEE2C (void);
// 0x0000007D System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_recording(UnityEngine.XR.Interaction.Toolkit.XRControllerRecording)
extern void XRControllerRecorder_set_recording_m4542D06A9AFFB6B7D9B963FF72B81B016045772E (void);
// 0x0000007E UnityEngine.XR.Interaction.Toolkit.XRBaseController UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_xrController()
extern void XRControllerRecorder_get_xrController_mE9F25207F8F79CA5A85A0A0BF87D423B92A269BE (void);
// 0x0000007F System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_xrController(UnityEngine.XR.Interaction.Toolkit.XRBaseController)
extern void XRControllerRecorder_set_xrController_mA877E3E528387AD4BDF5A2206C4D1BFD9802A30D (void);
// 0x00000080 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isRecording()
extern void XRControllerRecorder_get_isRecording_m0B796286A9F90713BBEE260AEF189402A11E569D (void);
// 0x00000081 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isRecording(System.Boolean)
extern void XRControllerRecorder_set_isRecording_mAF60918F432FA46245466ADC744B15BEA313AF64 (void);
// 0x00000082 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isPlaying()
extern void XRControllerRecorder_get_isPlaying_m9DEEF9C2ACC9A9CEEF86BECD315EC315DFF07E18 (void);
// 0x00000083 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isPlaying(System.Boolean)
extern void XRControllerRecorder_set_isPlaying_m68BEFD3E2655B3C95D62555B4AF9C48D740A8627 (void);
// 0x00000084 System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_currentTime()
extern void XRControllerRecorder_get_currentTime_m1B27ABF4F274AD624F1BF0F6EE2C5021B77E333F (void);
// 0x00000085 System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_duration()
extern void XRControllerRecorder_get_duration_m239BA50A898ECE55544CFA3D820B653A49CB5EEC (void);
// 0x00000086 System.Single UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_recordingStartTime()
extern void XRControllerRecorder_get_recordingStartTime_m1AE42301A5D3E07A69EFEFC685AEAEBA1CB08ED1 (void);
// 0x00000087 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_recordingStartTime(System.Single)
extern void XRControllerRecorder_set_recordingStartTime_mC65BE1B8434FADD1F9C4C1082F0D92EABA3174B8 (void);
// 0x00000088 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Awake()
extern void XRControllerRecorder_Awake_m7162AACDD8D0A635DD964D591160CA87BAE2D921 (void);
// 0x00000089 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Update()
extern void XRControllerRecorder_Update_mA6E3D2E4212BFECAA0DCF8F7CBDE127A8D19E41B (void);
// 0x0000008A System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::OnDestroy()
extern void XRControllerRecorder_OnDestroy_m05EAB4CB3182F4CEE71EA3D5A1D26D7465459AE7 (void);
// 0x0000008B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::ResetPlayback()
extern void XRControllerRecorder_ResetPlayback_m6861367E8F0B1FC50BDFDA33C33C32E8F5F65F6B (void);
// 0x0000008C System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::UpdatePlaybackTime(System.Double)
extern void XRControllerRecorder_UpdatePlaybackTime_mEC0D9F0AE8C6D578C544BFB20E90A6FA6C077CDA (void);
// 0x0000008D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::GetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState&)
extern void XRControllerRecorder_GetControllerState_m93FB8795A7424522C5F4FE53D9A2C92CFE33502A (void);
// 0x0000008E System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::.ctor()
extern void XRControllerRecorder__ctor_mD93981DBDE451E33495328CC4A769CA0F9EE0D4A (void);
// 0x0000008F System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRControllerState> UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_frames()
extern void XRControllerRecording_get_frames_m06617405971DCF6D72348E90FF67B4D0619CCAA3 (void);
// 0x00000090 System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_duration()
extern void XRControllerRecording_get_duration_m1D8A6A96023DE4C3C4831A84C0F90005F507AB8F (void);
// 0x00000091 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrame(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerRecording_AddRecordingFrame_mBD57B7658FEB9AE284C37B5D0FDFBA64A0EB3FBA (void);
// 0x00000092 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrame(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRControllerRecording_AddRecordingFrame_mB502408F2B591C1F15E886821703DC20F9F67BD8 (void);
// 0x00000093 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::InitRecording()
extern void XRControllerRecording_InitRecording_mA96B431A3D692EA4FBE899E6EAC5BE4F51E80488 (void);
// 0x00000094 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::SaveRecording()
extern void XRControllerRecording_SaveRecording_mF6C7E8B317AECEE8993ABEB9E39BDE2F2373689E (void);
// 0x00000095 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::.ctor()
extern void XRControllerRecording__ctor_m4BDF7F9C31E84DC26B6348A9F93CE7A3A133B682 (void);
// 0x00000096 UnityEngine.Color UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintColor()
extern void XRTintInteractableVisual_get_tintColor_mF4CFC0CD22080D5F34611CFAC029AEFDEED98F6D (void);
// 0x00000097 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintColor(UnityEngine.Color)
extern void XRTintInteractableVisual_set_tintColor_m4DA3C1E2DE29E73DC64ABCE44994B6B7EF69EBEC (void);
// 0x00000098 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnHover()
extern void XRTintInteractableVisual_get_tintOnHover_m581859C1FD7E763BBE1BA8B8F5414A7F7C4A5C1F (void);
// 0x00000099 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnHover(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnHover_m6FF161A29E321C3C4F609E3ACDF4EA2DA0033A3A (void);
// 0x0000009A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnSelection()
extern void XRTintInteractableVisual_get_tintOnSelection_m711A01F086697C23C9B833C4B3A31A3E76767556 (void);
// 0x0000009B System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnSelection(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnSelection_m80091389BD85C3896B397443D1AE43CB6ADFFFCA (void);
// 0x0000009C System.Collections.Generic.List`1<UnityEngine.Renderer> UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintRenderers()
extern void XRTintInteractableVisual_get_tintRenderers_m9F1B0E0FC957ECFEA30D3E7DD19F0F9E74567232 (void);
// 0x0000009D System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintRenderers(System.Collections.Generic.List`1<UnityEngine.Renderer>)
extern void XRTintInteractableVisual_set_tintRenderers_m1B47C2A8E5559448730415A816EF14B0FA6D8570 (void);
// 0x0000009E System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::Awake()
extern void XRTintInteractableVisual_Awake_m21662E7AD0A9674B11DF6999B2A02FFBBBAC7F3A (void);
// 0x0000009F System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnDestroy()
extern void XRTintInteractableVisual_OnDestroy_m7EAD174B82B295D281F9F1E1E1CA41D91602D58C (void);
// 0x000000A0 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::SetTint(System.Boolean)
extern void XRTintInteractableVisual_SetTint_m387BF4E8F18AF3DE52CCDCFC1FB187934DF7549F (void);
// 0x000000A1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::GetEmissionEnabled()
extern void XRTintInteractableVisual_GetEmissionEnabled_m5B7E90A1193C870C5744FFA3A4B47CD25CBC880C (void);
// 0x000000A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnFirstHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRTintInteractableVisual_OnFirstHoverEntered_m5B02D3FFD8CB35FDFABF9D4CF9A5B9469363EDFF (void);
// 0x000000A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnLastHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRTintInteractableVisual_OnLastHoverExited_mA54347833D6CB963BA0CAD89D9AE3072BE61F2BE (void);
// 0x000000A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRTintInteractableVisual_OnSelectEntered_m0AB2BE5502FBB496CC36DD03D2AABB7BCD4C4784 (void);
// 0x000000A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRTintInteractableVisual_OnSelectExited_mC389F628E075BBB25472D02EBD03D1F01AFCC1DD (void);
// 0x000000A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::.ctor()
extern void XRTintInteractableVisual__ctor_mFFFDF785AE0E373B77DB4BD0E36431E15A09169A (void);
// 0x000000A7 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::.cctor()
extern void XRTintInteractableVisual__cctor_mDF7CC141CF345A7C85A288849F8ECA50C053A2A7 (void);
// 0x000000A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual/ShaderPropertyLookup::.cctor()
extern void ShaderPropertyLookup__cctor_mC12D9753B4F99040B1CD7196F89DAACD44FD460D (void);
// 0x000000A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRBaseInteractable_add_registered_m405585D459AD7261614D4137F18098F556495F8E (void);
// 0x000000AA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRBaseInteractable_remove_registered_mB63ADB2C904C6550CB5A7C05A1400DB286264743 (void);
// 0x000000AB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRBaseInteractable_add_unregistered_m02354E663718C7E4E659433ABFBA57DFEEEDD838 (void);
// 0x000000AC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRBaseInteractable_remove_unregistered_m21193D4582EB0FE2FB93A889D0EE345D8066136B (void);
// 0x000000AD UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionManager()
extern void XRBaseInteractable_get_interactionManager_m640673C7B55F3D01578509FB8966184EEA80EAAD (void);
// 0x000000AE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractable_set_interactionManager_m7526D2E6F075DA81E69E857360A867410EFDEC57 (void);
// 0x000000AF System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_colliders()
extern void XRBaseInteractable_get_colliders_m51A75DA8027253CB43306DADB8B17EE79A3EEF15 (void);
// 0x000000B0 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionLayerMask()
extern void XRBaseInteractable_get_interactionLayerMask_m7F9D3EB36FAB586EA1C137010E3045226792BB9C (void);
// 0x000000B1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractable_set_interactionLayerMask_m12FC8F91CB48383130353651110260B6D81240D3 (void);
// 0x000000B2 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_customReticle()
extern void XRBaseInteractable_get_customReticle_m254DEFD1CA160078C4A5B1890DCD97E14B202F70 (void);
// 0x000000B3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_customReticle(UnityEngine.GameObject)
extern void XRBaseInteractable_set_customReticle_mE89A29C0E89957256AE35E9C81547B6E86204A88 (void);
// 0x000000B4 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_firstHoverEntered()
extern void XRBaseInteractable_get_firstHoverEntered_mA96938C6F42F633333D11B5767AA4FDF1DAE2CCC (void);
// 0x000000B5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_firstHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractable_set_firstHoverEntered_mAEB12A94B8A960A6796CB32F9ED509FD379060FE (void);
// 0x000000B6 UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_lastHoverExited()
extern void XRBaseInteractable_get_lastHoverExited_m85254089D36C6F3C70096DE0F86F1F89E0C921F8 (void);
// 0x000000B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_lastHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractable_set_lastHoverExited_m5C1DCB0DAAEFEFBC445A3617A954131F2EF2EA38 (void);
// 0x000000B8 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoverEntered()
extern void XRBaseInteractable_get_hoverEntered_m9DE6B043E318823EC079966C1A3D47913011BE9B (void);
// 0x000000B9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_hoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractable_set_hoverEntered_m6010B718168EF27561C85B168E0BEEEB0A799D7F (void);
// 0x000000BA UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoverExited()
extern void XRBaseInteractable_get_hoverExited_m19E497FF5E045CF29001BCA1BEC6C9722B7240A5 (void);
// 0x000000BB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_hoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractable_set_hoverExited_m359D425550007641982634A126C7C5B264D5C51F (void);
// 0x000000BC UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectEntered()
extern void XRBaseInteractable_get_selectEntered_mD07C4B7FF65C8DAACC8423411E57CC189A3B0055 (void);
// 0x000000BD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent)
extern void XRBaseInteractable_set_selectEntered_m4E4622236FF91421D485D055FA579BD49759A903 (void);
// 0x000000BE UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectExited()
extern void XRBaseInteractable_get_selectExited_m1AE52740D4FB9B1D8BF94EFA5D65EA528574507F (void);
// 0x000000BF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEvent)
extern void XRBaseInteractable_set_selectExited_mF9F8780FC4098116CFE274A45F91768612998394 (void);
// 0x000000C0 UnityEngine.XR.Interaction.Toolkit.ActivateEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_activated()
extern void XRBaseInteractable_get_activated_mFBD1EB00DB391C3AA0EE5F1EFE6F8D7C33D28CFB (void);
// 0x000000C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_activated(UnityEngine.XR.Interaction.Toolkit.ActivateEvent)
extern void XRBaseInteractable_set_activated_m238C4CE2FC3C9FAA676A94F6E991C00C6F4B5293 (void);
// 0x000000C2 UnityEngine.XR.Interaction.Toolkit.DeactivateEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_deactivated()
extern void XRBaseInteractable_get_deactivated_m4F3972C715EAD95AD9F0F3EEA7E223627D28357A (void);
// 0x000000C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_deactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEvent)
extern void XRBaseInteractable_set_deactivated_m225ED5AA5CE8E4FB321AFDA74E3016AEE4C5BAA5 (void);
// 0x000000C4 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoveringInteractors()
extern void XRBaseInteractable_get_hoveringInteractors_m85B57133A957A0D23C49CACCA8B1291FE52AAE88 (void);
// 0x000000C5 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectingInteractor()
extern void XRBaseInteractable_get_selectingInteractor_mBE9C84329FE5F872F9CC6652C6B8920F8EE538A7 (void);
// 0x000000C6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectingInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_set_selectingInteractor_m2E9E65FEB53E58D546B63D4B869D8EF3B66EB943 (void);
// 0x000000C7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isHovered()
extern void XRBaseInteractable_get_isHovered_m24852D564014E7068242CD43AB2393E0615D7FC6 (void);
// 0x000000C8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_isHovered(System.Boolean)
extern void XRBaseInteractable_set_isHovered_m50F19A45B41FDC5D6880D6554A05AFE6AC2F249E (void);
// 0x000000C9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isSelected()
extern void XRBaseInteractable_get_isSelected_mB1CAAE9B24246EC0384C7ADF7C7716FAD729E4BD (void);
// 0x000000CA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_isSelected(System.Boolean)
extern void XRBaseInteractable_set_isSelected_mFBB8634E77DA109306374B2F558C80700CA2E1D4 (void);
// 0x000000CB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Reset()
extern void XRBaseInteractable_Reset_m66A78118F8165035FFC43ED016346F29D2074B49 (void);
// 0x000000CC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Awake()
extern void XRBaseInteractable_Awake_mB55C0806771AD6C28848884D1787ABA4585BC79B (void);
// 0x000000CD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnEnable()
extern void XRBaseInteractable_OnEnable_m956A8781750EF3EC35191B236F6D38F0E95E5D01 (void);
// 0x000000CE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDisable()
extern void XRBaseInteractable_OnDisable_m3FB9E8412F412817BFAAE674E8CC946C8BCD7B72 (void);
// 0x000000CF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDestroy()
extern void XRBaseInteractable_OnDestroy_m780A3BA2640F5F6B52371DC5BB073D7B3581B478 (void);
// 0x000000D0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::FindCreateInteractionManager()
extern void XRBaseInteractable_FindCreateInteractionManager_mD4F04B3358C3B4A81516F04FD04665948FD43AFF (void);
// 0x000000D1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RegisterWithInteractionManager()
extern void XRBaseInteractable_RegisterWithInteractionManager_mB086602EBFCC5972BEDA2F9CC49A4D43B42D5117 (void);
// 0x000000D2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnregisterWithInteractionManager()
extern void XRBaseInteractable_UnregisterWithInteractionManager_m040C9A4EC028908F81579E72AEBE566D96F43524 (void);
// 0x000000D3 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetDistanceSqrToInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_GetDistanceSqrToInteractor_m81DC0ECC9DD8C54BE8DAB4A52D8A8969C204E5A9 (void);
// 0x000000D4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsOnValidLayerMask(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsOnValidLayerMask_m54CF5103B30EC1A00669D6D86E9B75AB47658114 (void);
// 0x000000D5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsHoverableBy_m7CAE7F8BB3C31B880C0D7F8EB565801E4607AC30 (void);
// 0x000000D6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsSelectableBy_m2F3DDCB18B173222EC4152A3D948D896CA38556B (void);
// 0x000000D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::AttachCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_AttachCustomReticle_m696031810F15523598A081E29033396CB7671141 (void);
// 0x000000D8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RemoveCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_RemoveCustomReticle_m859DB0BE59BB130EE396D16C7913375ADB764668 (void);
// 0x000000D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseInteractable_ProcessInteractable_m8AF5B2051D82B42877967B45DE15DEBEB691125A (void);
// 0x000000DA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRBaseInteractable_OnRegistered_mAF5DEA11FB57458DC26B9BA8692CF64A02252CE8 (void);
// 0x000000DB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRBaseInteractable_OnUnregistered_m77864664BC2E7CC3F8F92C89AE414BAD1FD0C0F8 (void);
// 0x000000DC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_OnHoverEntering_m5AC1A2CD2C69249D37F5922C6779CED67AABE99C (void);
// 0x000000DD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_OnHoverEntered_m1DF5B7F9A891305A02E699C68E6A4D55CD074451 (void);
// 0x000000DE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_OnHoverExiting_m55E4C9FAEDD0C0B0C92DA20D8BCBA3D5F3D13F46 (void);
// 0x000000DF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_OnHoverExited_m4F245DAAE60CEBA1BA3C0D89EFA4CE0A9594633C (void);
// 0x000000E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_OnSelectEntering_mC0E59B356CA5FE4C6D908B94A1E76D8DB7FBAED7 (void);
// 0x000000E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_OnSelectEntered_mC35925CA537E42534CC448ED295E997596C9FC27 (void);
// 0x000000E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_OnSelectExiting_m21B9BDC19835790F7E4A5E247B061DC55639327B (void);
// 0x000000E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_OnSelectExited_m4F6ACED938C04F1AA99885D185AAB87D34C055AA (void);
// 0x000000E4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
extern void XRBaseInteractable_OnActivated_m9F38EB7FF264C451CD234E66BF957B998AA5CAF0 (void);
// 0x000000E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
extern void XRBaseInteractable_OnDeactivated_m122AF324746EF55FE98C9255FC6DEDB273CF1F2F (void);
// 0x000000E6 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onFirstHoverEntered()
extern void XRBaseInteractable_get_onFirstHoverEntered_mE9BC88ACDE186EC6AE93ECADE09EC7586E4EC14A (void);
// 0x000000E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onFirstHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onFirstHoverEntered_m2AF37DBC7BC51270C8CEA3FF15C23FC8C230EC94 (void);
// 0x000000E8 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onLastHoverExited()
extern void XRBaseInteractable_get_onLastHoverExited_m7F454EEB1CFB13B656C2730977091E78CB9088CF (void);
// 0x000000E9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onLastHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onLastHoverExited_m3DBB6A6E92400C1285302AD612D84A3DDB1006F7 (void);
// 0x000000EA UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverEntered()
extern void XRBaseInteractable_get_onHoverEntered_mBCAEB17B75AB1E1FF63D244E98C24D10396E14F0 (void);
// 0x000000EB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverEntered_mDE2D3D71FB700C220437012BE6DCFE76D1BDA3C3 (void);
// 0x000000EC UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverExited()
extern void XRBaseInteractable_get_onHoverExited_m7124A867CDEBF2D2DCEA09FF53DB1431AE7E6D4C (void);
// 0x000000ED System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverExited_m5C09C610896F32D5FFB99CFDDAE7EE25F8BF5F73 (void);
// 0x000000EE UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectEntered()
extern void XRBaseInteractable_get_onSelectEntered_m505C109ACF65671CF86EF5491A439626F7377C95 (void);
// 0x000000EF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectEntered_mB97E680610149DD02EB476810EE72158D64C30F8 (void);
// 0x000000F0 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectExited()
extern void XRBaseInteractable_get_onSelectExited_m12A0F58B60CA091BB209F769C6F4A97C6AD52DC6 (void);
// 0x000000F1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectExited_m895693F67B6902E63596EAB4187E3A4CD645C5E4 (void);
// 0x000000F2 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectCanceled()
extern void XRBaseInteractable_get_onSelectCanceled_mC45E3F544D34B9E2E7F9345BE074DF0C8036F32F (void);
// 0x000000F3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectCanceled(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectCanceled_mD182B405C4B8FBEA94E3437853EF532BEF97B9D7 (void);
// 0x000000F4 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onActivate()
extern void XRBaseInteractable_get_onActivate_m9504CF7605613F890AEC8329E14E8F33D6853C01 (void);
// 0x000000F5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onActivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onActivate_mB94D4DA7F35314D1D9BED43CF29B4F8C52D808CA (void);
// 0x000000F6 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onDeactivate()
extern void XRBaseInteractable_get_onDeactivate_m283A38AA07BC69AF140537FD548D038CC88F48CD (void);
// 0x000000F7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onDeactivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onDeactivate_mDA096E9F7ACAF2DBEC630D9E146D8C47B2B9ECC7 (void);
// 0x000000F8 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onFirstHoverEnter()
extern void XRBaseInteractable_get_onFirstHoverEnter_m4291CD3E502724E909AD87A056FFCD7F39C640EF (void);
// 0x000000F9 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverEnter()
extern void XRBaseInteractable_get_onHoverEnter_mDC7E5C0BD57D83841A2F43D2D44D1D98BCABB0A9 (void);
// 0x000000FA UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverExit()
extern void XRBaseInteractable_get_onHoverExit_m1FAA6CE01CCA1D235586C98D5153E3992AC40469 (void);
// 0x000000FB UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onLastHoverExit()
extern void XRBaseInteractable_get_onLastHoverExit_mA5AC01568346EBE0A9F77F11EC8F4724C1D88126 (void);
// 0x000000FC UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectEnter()
extern void XRBaseInteractable_get_onSelectEnter_m02091456C0663A61F506F273E73703AECC2E3B35 (void);
// 0x000000FD UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectExit()
extern void XRBaseInteractable_get_onSelectExit_m3BD12DAB18901906BBA106472CC82749C592D693 (void);
// 0x000000FE UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectCancel()
extern void XRBaseInteractable_get_onSelectCancel_m4CD2EB174EA26F7907F34BC99DD707225B311124 (void);
// 0x000000FF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverEntering_m588E25A00CF1DCA119F223C6BEADDD3B59D9AB1B (void);
// 0x00000100 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverEntered_m412FB9342515A3A22FE92CA30A0F170EE2EF2853 (void);
// 0x00000101 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverExiting_m589A6A23AF8ED178D75C0936ADC2758462AEE019 (void);
// 0x00000102 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverExited_m9915A3C9B8E9BF9C2FB3C72E166F9AFC13F180B6 (void);
// 0x00000103 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectEntering_m897698ADCBABB2893944F19AB9B75BA289E09F9E (void);
// 0x00000104 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectEntered_m92C88883CAABC0299A9C8F76086E77DEC37BFA0D (void);
// 0x00000105 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectExiting_m14F2025DF6CDE08CEFC32CBC0DFD05B322386265 (void);
// 0x00000106 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectExited_mEB5BA537E00FF5A6E78C231668A2C5150AB49239 (void);
// 0x00000107 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectCanceling(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectCanceling_m52437F3B08279B8F50252F2BB3B95E970C2324C8 (void);
// 0x00000108 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectCanceled(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectCanceled_m4543868A2D75DFF30C44BB177118D536C95F1457 (void);
// 0x00000109 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnActivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnActivate_m2AD33C7A74CE6181F174853627F10C809F604303 (void);
// 0x0000010A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDeactivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnDeactivate_m33F1A2AD3F147334702A4972FEE33C98AE7F3335 (void);
// 0x0000010B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::.ctor()
extern void XRBaseInteractable__ctor_mDF809A206563ADCC895A710AA04677E2643E523B (void);
// 0x0000010C UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachTransform()
extern void XRGrabInteractable_get_attachTransform_mCFEED1B9F7BED3005EF66CD725F2B54C8E385662 (void);
// 0x0000010D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachTransform(UnityEngine.Transform)
extern void XRGrabInteractable_set_attachTransform_mBDEAABEC1FBDB9C8DE9A6BC57F5C269B74DC594E (void);
// 0x0000010E System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachEaseInTime()
extern void XRGrabInteractable_get_attachEaseInTime_m1ADEC0485E9494533DFCB76DC58B245A74932538 (void);
// 0x0000010F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachEaseInTime(System.Single)
extern void XRGrabInteractable_set_attachEaseInTime_m2F1D75DB03563723A037A9BC473C27297766687F (void);
// 0x00000110 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_movementType()
extern void XRGrabInteractable_get_movementType_m5336B231E28E90E4BEC58627DD65E825960B6E16 (void);
// 0x00000111 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_movementType(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType)
extern void XRGrabInteractable_set_movementType_m23145D15E650595B7A3684901A551A48D007E563 (void);
// 0x00000112 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_velocityDamping()
extern void XRGrabInteractable_get_velocityDamping_mC45991DF3D1F8A65BBAF9BE0964904CC0B75964D (void);
// 0x00000113 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_velocityDamping(System.Single)
extern void XRGrabInteractable_set_velocityDamping_m4653C1A619B3519C8B93DB8DF1E0786E24B28699 (void);
// 0x00000114 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_velocityScale()
extern void XRGrabInteractable_get_velocityScale_mACA3EFE62399701C768E12DFCA1A7B4F86B4410A (void);
// 0x00000115 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_velocityScale(System.Single)
extern void XRGrabInteractable_set_velocityScale_mBFF3F95337B68FB43A1FC7558EE9D2CDC7AF1C90 (void);
// 0x00000116 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_angularVelocityDamping()
extern void XRGrabInteractable_get_angularVelocityDamping_m1EB0412F4AB85880E9A25E42B4CB97944E005DFB (void);
// 0x00000117 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_angularVelocityDamping(System.Single)
extern void XRGrabInteractable_set_angularVelocityDamping_m4A51A86F6CA6F933795E52362AC70FABAC334843 (void);
// 0x00000118 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_angularVelocityScale()
extern void XRGrabInteractable_get_angularVelocityScale_m67144C00D787AA3E981F0B49B6C0F5C164147EF5 (void);
// 0x00000119 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_angularVelocityScale(System.Single)
extern void XRGrabInteractable_set_angularVelocityScale_mECF85D0A7F3AAFB2870D90C0BD407EB7BA73E581 (void);
// 0x0000011A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackPosition()
extern void XRGrabInteractable_get_trackPosition_mFAFF6F0139571549C6DA1A2E393697A614839514 (void);
// 0x0000011B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackPosition(System.Boolean)
extern void XRGrabInteractable_set_trackPosition_m588E2349E2135A9FD8AFD651BB88E0E5B33DFCB4 (void);
// 0x0000011C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPosition()
extern void XRGrabInteractable_get_smoothPosition_m9E1C79DE378EC3BAFE7CAB8AA6C9F11CDC1FF9D2 (void);
// 0x0000011D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPosition(System.Boolean)
extern void XRGrabInteractable_set_smoothPosition_m2DAB04DD912FD109A710BE4CD1F1E0085D69814E (void);
// 0x0000011E System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPositionAmount()
extern void XRGrabInteractable_get_smoothPositionAmount_mB53562269982B3870532799C6A20D81C5D73E541 (void);
// 0x0000011F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPositionAmount(System.Single)
extern void XRGrabInteractable_set_smoothPositionAmount_m39F5B69A68503EE8C142CFE7D0D5EF463D0C8321 (void);
// 0x00000120 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenPosition()
extern void XRGrabInteractable_get_tightenPosition_mB6C11F873870015814C2559ECCFFC4DEF3B21F61 (void);
// 0x00000121 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenPosition(System.Single)
extern void XRGrabInteractable_set_tightenPosition_mACB34AE0650D7B0EBAAB559B18099502DBF1CC32 (void);
// 0x00000122 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackRotation()
extern void XRGrabInteractable_get_trackRotation_mC594D923EB5F01E79249DB9DE57296512968D7B9 (void);
// 0x00000123 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackRotation(System.Boolean)
extern void XRGrabInteractable_set_trackRotation_m2EF07501B37C171377E269FD015668D2659D199A (void);
// 0x00000124 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotation()
extern void XRGrabInteractable_get_smoothRotation_mD0F9582301A1F41A98EC87E6AFD88B5827A133CF (void);
// 0x00000125 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotation(System.Boolean)
extern void XRGrabInteractable_set_smoothRotation_m96191A71676A90F01CD4C661E19BD6C927C8FAE3 (void);
// 0x00000126 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotationAmount()
extern void XRGrabInteractable_get_smoothRotationAmount_m98B0B68F49FCC228141059C133999632D7D55E0A (void);
// 0x00000127 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotationAmount(System.Single)
extern void XRGrabInteractable_set_smoothRotationAmount_mCACF2B56019831A1311E54D12A9FE325520A7444 (void);
// 0x00000128 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenRotation()
extern void XRGrabInteractable_get_tightenRotation_m11681E043ECA567163F95EFD74F8EED52643D649 (void);
// 0x00000129 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenRotation(System.Single)
extern void XRGrabInteractable_set_tightenRotation_m01DEB304B70C2A105C9AA00D2914106F47673B8E (void);
// 0x0000012A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwOnDetach()
extern void XRGrabInteractable_get_throwOnDetach_m4E6B3395E082D656F160F25555F018407CDD4395 (void);
// 0x0000012B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwOnDetach(System.Boolean)
extern void XRGrabInteractable_set_throwOnDetach_m9245D3707FCCD624D0A8B1828CD9EEDE7801840D (void);
// 0x0000012C System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwSmoothingDuration()
extern void XRGrabInteractable_get_throwSmoothingDuration_m295093BA950E8E1ADF0F912C9DAA8E81E86E4684 (void);
// 0x0000012D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwSmoothingDuration(System.Single)
extern void XRGrabInteractable_set_throwSmoothingDuration_m63B2F31FD388EB12B8E0766086F908EFFE7CEC93 (void);
// 0x0000012E UnityEngine.AnimationCurve UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwSmoothingCurve()
extern void XRGrabInteractable_get_throwSmoothingCurve_mFB8C99F7A201983789F2F08282A45DB71F399EE4 (void);
// 0x0000012F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwSmoothingCurve(UnityEngine.AnimationCurve)
extern void XRGrabInteractable_set_throwSmoothingCurve_m15F19E4A0E2902C77F96903E74B8A2EAD0F87F13 (void);
// 0x00000130 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwVelocityScale()
extern void XRGrabInteractable_get_throwVelocityScale_m7F183D3754A5FD353B63508511E522F9E003DEA9 (void);
// 0x00000131 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwVelocityScale_m9290B8C247785BD1A2B3DB7E5D931FDBD4C9480F (void);
// 0x00000132 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwAngularVelocityScale()
extern void XRGrabInteractable_get_throwAngularVelocityScale_m923593F0D5F82DC1E28896EEB58C31A97DBD0E97 (void);
// 0x00000133 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwAngularVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwAngularVelocityScale_m07ACE9E817DFD81C93A587FED4C2E7D97D294618 (void);
// 0x00000134 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_forceGravityOnDetach()
extern void XRGrabInteractable_get_forceGravityOnDetach_m4FEAFC00B60688A66291297C086278286AE2635C (void);
// 0x00000135 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_forceGravityOnDetach(System.Boolean)
extern void XRGrabInteractable_set_forceGravityOnDetach_m1B2D30772BEE2919AF67178138D66D16A6B89F66 (void);
// 0x00000136 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_gravityOnDetach()
extern void XRGrabInteractable_get_gravityOnDetach_mCDB9A3BF3C089057D4AF53570C81BA7E3B618FB1 (void);
// 0x00000137 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_gravityOnDetach(System.Boolean)
extern void XRGrabInteractable_set_gravityOnDetach_mD96B1445F40246A77045E73124A42E5B45987CE3 (void);
// 0x00000138 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_retainTransformParent()
extern void XRGrabInteractable_get_retainTransformParent_m317451259253BBE1D90FBF305103B8FBF4E6C7F9 (void);
// 0x00000139 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_retainTransformParent(System.Boolean)
extern void XRGrabInteractable_set_retainTransformParent_m2A8CB82E4DBD7678529368B91C7610A4C544817A (void);
// 0x0000013A System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Awake()
extern void XRGrabInteractable_Awake_m6A3973C982B38E9C8656B60E201DA3DEC1D5F6B6 (void);
// 0x0000013B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_ProcessInteractable_m5CBB4BC09224BC549919E50AF61096A607780D9B (void);
// 0x0000013C UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachPosition(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_GetWorldAttachPosition_mB51F5D79BF1F2D486C7B6B817405D53A5FC90D6B (void);
// 0x0000013D UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachRotation(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_GetWorldAttachRotation_mEEA750341259E9A98C3AADA59F1B4315E68B0987 (void);
// 0x0000013E System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateTarget(System.Single)
extern void XRGrabInteractable_UpdateTarget_m65DFB9528AC6373329CD0106C444920D08405609 (void);
// 0x0000013F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformInstantaneousUpdate(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformInstantaneousUpdate_m319A1EDD10F8C7D530080E1FE375CFBD19A58775 (void);
// 0x00000140 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformKinematicUpdate(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformKinematicUpdate_m653F5F5987CC234B8031E1620DF0D393B07593FE (void);
// 0x00000141 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformVelocityTrackingUpdate(System.Single,UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformVelocityTrackingUpdate_m40F49A6922A04C36872C9573B7D74F0B105F8289 (void);
// 0x00000142 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateInteractorLocalPose(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_UpdateInteractorLocalPose_mC2C9A7FFDD809A2B8FBD07531458BD07BB02F5A8 (void);
// 0x00000143 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRGrabInteractable_OnSelectEntering_m35C0E7642A44DFE4395F8714910A826A8C9AD558 (void);
// 0x00000144 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRGrabInteractable_OnSelectExiting_m29DB52D4EEBD6694AD216CC1A89423527B358451 (void);
// 0x00000145 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Grab()
extern void XRGrabInteractable_Grab_mC60AEB14AE55DBB446EFE7B3E8C7F4957D8AD71B (void);
// 0x00000146 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Drop()
extern void XRGrabInteractable_Drop_mC831156FD7C1A840A5626DBFFB0FE354E17BEC0E (void);
// 0x00000147 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Detach()
extern void XRGrabInteractable_Detach_mBDDBEBD3C4104BF0BFCAF22F5EA17F07C7B15641 (void);
// 0x00000148 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SetupRigidbodyGrab(UnityEngine.Rigidbody)
extern void XRGrabInteractable_SetupRigidbodyGrab_m0FBB2455BA6001AF5422A40458185D528AE0D31A (void);
// 0x00000149 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SetupRigidbodyDrop(UnityEngine.Rigidbody)
extern void XRGrabInteractable_SetupRigidbodyDrop_m97C5E90449A546142A823596B6EB8C94EA6DCB5F (void);
// 0x0000014A System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityStart()
extern void XRGrabInteractable_SmoothVelocityStart_m467C56A03D741840C08A29E62053FE41ABA99530 (void);
// 0x0000014B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityEnd()
extern void XRGrabInteractable_SmoothVelocityEnd_mE3E18D53F3184FD88E9BFBF5E14F2418F5C81069 (void);
// 0x0000014C System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityUpdate()
extern void XRGrabInteractable_SmoothVelocityUpdate_mF23E340AFEA898D1EA7EE07069D854115678C17B (void);
// 0x0000014D UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetSmoothedVelocityValue(UnityEngine.Vector3[])
extern void XRGrabInteractable_GetSmoothedVelocityValue_m06973B9DE4F19E11F149D5AFB0D55E7858CC1695 (void);
// 0x0000014E System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::.ctor()
extern void XRGrabInteractable__ctor_m73CCE84E4C6F31D6A132742A416C9F8EE8B1D2CE (void);
// 0x0000014F System.Void UnityEngine.XR.Interaction.Toolkit.XRSimpleInteractable::.ctor()
extern void XRSimpleInteractable__ctor_m1C9CE017DFB92D8830865DB23E005E5DAD8C26B9 (void);
// 0x00000150 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::AttachCustomReticle(UnityEngine.GameObject)
// 0x00000151 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::RemoveCustomReticle()
// 0x00000152 System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
// 0x00000153 System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
// 0x00000154 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineWidth()
extern void XRInteractorLineVisual_get_lineWidth_m96F69834A319911566BA6C6EA391FE1CE525098F (void);
// 0x00000155 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineWidth(System.Single)
extern void XRInteractorLineVisual_set_lineWidth_m8D462CDF8C3E7AC1EEB6E78A3D2AC9945D968C79 (void);
// 0x00000156 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_overrideInteractorLineLength()
extern void XRInteractorLineVisual_get_overrideInteractorLineLength_m4F61A9339BFE1ABB4D85ED99472CF3CC6A32C1C6 (void);
// 0x00000157 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_overrideInteractorLineLength(System.Boolean)
extern void XRInteractorLineVisual_set_overrideInteractorLineLength_m43A0D9FAF8C58359E6B1F3D0067C3CDBADBCC4FC (void);
// 0x00000158 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineLength()
extern void XRInteractorLineVisual_get_lineLength_mC83680A06C8249E27FA406D689A04D53D3529B81 (void);
// 0x00000159 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineLength(System.Single)
extern void XRInteractorLineVisual_set_lineLength_m3DF95007ADBEC21EA4DA41A4280E6C23DA9147C3 (void);
// 0x0000015A UnityEngine.AnimationCurve UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_widthCurve()
extern void XRInteractorLineVisual_get_widthCurve_mF804C47DA68A1027E03E3028CFCA531178A44B17 (void);
// 0x0000015B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_widthCurve(UnityEngine.AnimationCurve)
extern void XRInteractorLineVisual_set_widthCurve_m4C2F1F0D65A7B5AB0933DF76C9C214D2D5D92B92 (void);
// 0x0000015C UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_validColorGradient()
extern void XRInteractorLineVisual_get_validColorGradient_m1942AE896FACCC12B00FA17ABBC41A8FBB9EA80E (void);
// 0x0000015D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_validColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_validColorGradient_m0671AAC1AD10F554D1D26B388AF118D2AC85BCB8 (void);
// 0x0000015E UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_invalidColorGradient()
extern void XRInteractorLineVisual_get_invalidColorGradient_m677F7427379394B54F1E3E838D5B45D4714C6245 (void);
// 0x0000015F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_invalidColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_invalidColorGradient_m101018631A998BF4AD272D091FFB22B80770B843 (void);
// 0x00000160 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_smoothMovement()
extern void XRInteractorLineVisual_get_smoothMovement_m57D41D24159058B8A6A418D4FAFBA3ACB0F362CA (void);
// 0x00000161 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_smoothMovement(System.Boolean)
extern void XRInteractorLineVisual_set_smoothMovement_mBC06B064251D4E7F0DC77BB3DF5AA46846CFB78C (void);
// 0x00000162 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_followTightness()
extern void XRInteractorLineVisual_get_followTightness_mDF82AC5DE6AA47E72B2CBCFF21F578AD0F360CE6 (void);
// 0x00000163 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_followTightness(System.Single)
extern void XRInteractorLineVisual_set_followTightness_m49C4452709A84E3A35D99FA02C533FBCDDA47589 (void);
// 0x00000164 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_snapThresholdDistance()
extern void XRInteractorLineVisual_get_snapThresholdDistance_mCDFE5584EC55099D19657124395EC0BB5DE07697 (void);
// 0x00000165 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_snapThresholdDistance(System.Single)
extern void XRInteractorLineVisual_set_snapThresholdDistance_m937662B2F9F69BDE5DC1EBFBAE920A94B60478E5 (void);
// 0x00000166 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_reticle()
extern void XRInteractorLineVisual_get_reticle_mC2D9F4B3880B5402F6A5D46DC2A78440CD73DEC7 (void);
// 0x00000167 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_reticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_set_reticle_m44FEEF3BEA4325256C3982922AC6166DCA1ACCF6 (void);
// 0x00000168 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_stopLineAtFirstRaycastHit()
extern void XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m6611D67930B530767533378E788F82D38998F508 (void);
// 0x00000169 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_stopLineAtFirstRaycastHit(System.Boolean)
extern void XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m63991065E359CEDD74739C8B4D012E3190E0E1EF (void);
// 0x0000016A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Reset()
extern void XRInteractorLineVisual_Reset_m67A0585521324F156C781BA92F934230B52B2A4B (void);
// 0x0000016B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnValidate()
extern void XRInteractorLineVisual_OnValidate_mFED6AB0B0E9430A250806AA066EFF5CC9DAF673C (void);
// 0x0000016C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Awake()
extern void XRInteractorLineVisual_Awake_mC445AE47F6A85EE78747A26C19DDEF3327D6879A (void);
// 0x0000016D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnEnable()
extern void XRInteractorLineVisual_OnEnable_m455984A1E3DD708A5D5DE7A58439B4427FA3738E (void);
// 0x0000016E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnDisable()
extern void XRInteractorLineVisual_OnDisable_m8E5223F3219AB4F58866A93EE6A449C8D3AA8096 (void);
// 0x0000016F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::ClearLineRenderer()
extern void XRInteractorLineVisual_ClearLineRenderer_m57218609C8FEA820DB02F352B9243634464CE51C (void);
// 0x00000170 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnBeforeRenderLineVisual()
extern void XRInteractorLineVisual_OnBeforeRenderLineVisual_mC41BB0EA7A5E1652634D180F145C5E9C167F734D (void);
// 0x00000171 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateLineVisual()
extern void XRInteractorLineVisual_UpdateLineVisual_m296B3CBA8AA7648594D544D6363F3ACDF2C31A3B (void);
// 0x00000172 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateSettings()
extern void XRInteractorLineVisual_UpdateSettings_mEB1476ABF7670809FB934D27E32DEFC9D2B3BB7E (void);
// 0x00000173 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::TryFindLineRenderer()
extern void XRInteractorLineVisual_TryFindLineRenderer_mB36EF9B9C2806849CBD8AB3CAB04C4161030CC08 (void);
// 0x00000174 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::AttachCustomReticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_AttachCustomReticle_mC8EC6F97C16D8BF41A9B78934AA0A50A9535587B (void);
// 0x00000175 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::RemoveCustomReticle()
extern void XRInteractorLineVisual_RemoveCustomReticle_mEA4749C68830C9D8F3EB366E83A6B74DBEDE4B32 (void);
// 0x00000176 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::.ctor()
extern void XRInteractorLineVisual__ctor_mE32646D14194660D4F4635BB6801E78684288B69 (void);
// 0x00000177 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_maxRaycastDistance()
extern void XRInteractorReticleVisual_get_maxRaycastDistance_m5D0656EA4D259FF477324974AB897FBE1124C65A (void);
// 0x00000178 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_maxRaycastDistance(System.Single)
extern void XRInteractorReticleVisual_set_maxRaycastDistance_mCBA0DEA0865FF45CC43AE2F65EB5CF56E5AF9A32 (void);
// 0x00000179 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticlePrefab()
extern void XRInteractorReticleVisual_get_reticlePrefab_m3D4FC0E27D10392B5CB8AB6358ADA40504C38FA6 (void);
// 0x0000017A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticlePrefab(UnityEngine.GameObject)
extern void XRInteractorReticleVisual_set_reticlePrefab_m28D662BB77B70F49738F267067D5E1D7BF0D2CA2 (void);
// 0x0000017B System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_prefabScalingFactor()
extern void XRInteractorReticleVisual_get_prefabScalingFactor_m6062599B315F28A063AC4FB49AA826DCCAE64939 (void);
// 0x0000017C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_prefabScalingFactor(System.Single)
extern void XRInteractorReticleVisual_set_prefabScalingFactor_m6E59EBA702C6D5A77FD0EBD7ACC31D8BF82ADAB9 (void);
// 0x0000017D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_undoDistanceScaling()
extern void XRInteractorReticleVisual_get_undoDistanceScaling_mA841A28F57F526B2C0A73B32155B0185CEF34B43 (void);
// 0x0000017E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_undoDistanceScaling(System.Boolean)
extern void XRInteractorReticleVisual_set_undoDistanceScaling_mCA75AD5FEFC2C184C73515D301CA862ED44AAC14 (void);
// 0x0000017F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_alignPrefabWithSurfaceNormal()
extern void XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_m1A9A614A9C71EA40059A3483B730EBA008354FDB (void);
// 0x00000180 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_alignPrefabWithSurfaceNormal(System.Boolean)
extern void XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_mE97E04F0153A85D2A244ACE7B6C2DF1B7F5AB3B8 (void);
// 0x00000181 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_endpointSmoothingTime()
extern void XRInteractorReticleVisual_get_endpointSmoothingTime_mEEE5AF6B0734098FA3C421B8A053045062973DFB (void);
// 0x00000182 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_endpointSmoothingTime(System.Single)
extern void XRInteractorReticleVisual_set_endpointSmoothingTime_m20ECF8503C3A6D521206B971512508F785537874 (void);
// 0x00000183 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_drawWhileSelecting()
extern void XRInteractorReticleVisual_get_drawWhileSelecting_m477F2BFBC936257D7AB6DF513B31F4C2097938E9 (void);
// 0x00000184 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_drawWhileSelecting(System.Boolean)
extern void XRInteractorReticleVisual_set_drawWhileSelecting_m6382A849853A1D89A56E85C2A0A87C3689598E21 (void);
// 0x00000185 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_raycastMask()
extern void XRInteractorReticleVisual_get_raycastMask_mFE2021B73CBDF71F66ABC700CD29C8AECB274D30 (void);
// 0x00000186 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_raycastMask(UnityEngine.LayerMask)
extern void XRInteractorReticleVisual_set_raycastMask_m48E875278ABCD7CE9785BCA53DEE9A3D93790186 (void);
// 0x00000187 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticleActive()
extern void XRInteractorReticleVisual_get_reticleActive_m8B672179381DB7C6F6C37CBFF71812D2656BB44C (void);
// 0x00000188 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticleActive(System.Boolean)
extern void XRInteractorReticleVisual_set_reticleActive_m0CF10850536624150F369012C157A05D12955917 (void);
// 0x00000189 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Awake()
extern void XRInteractorReticleVisual_Awake_m91DBF982CECFD91ED7C25CCFED7CD843015BF21E (void);
// 0x0000018A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Update()
extern void XRInteractorReticleVisual_Update_m76C76FA19939699C2612463789190DA57B10EE3C (void);
// 0x0000018B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnDestroy()
extern void XRInteractorReticleVisual_OnDestroy_m2A083EF5B41662AB6E7EE5526FF08FDECCCC29A6 (void);
// 0x0000018C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::SetupReticlePrefab()
extern void XRInteractorReticleVisual_SetupReticlePrefab_mB2034615F130AB7CC65C6CB763871D4B13F075AB (void);
// 0x0000018D UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void XRInteractorReticleVisual_FindClosestHit_m7DAAF993CD38DD7C3BF877D130350A00E43022F4 (void);
// 0x0000018E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::TryGetRaycastPoint(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRInteractorReticleVisual_TryGetRaycastPoint_m7603C50426032F46D99419A3E14C862364D8B9C3 (void);
// 0x0000018F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::UpdateReticleTarget()
extern void XRInteractorReticleVisual_UpdateReticleTarget_m982FA1B4BD60EEEF9504200B6E3B4B3F78051237 (void);
// 0x00000190 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::ActivateReticleAtTarget()
extern void XRInteractorReticleVisual_ActivateReticleAtTarget_mD7236C5B94F1F6B08C8CC015C336D18C325C3D18 (void);
// 0x00000191 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractorReticleVisual_OnSelectEntered_mB681FC8AD5FB5B691F8A67E2C222453CF4CA6BE2 (void);
// 0x00000192 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRInteractorReticleVisual_OnSelectExited_m913728EDDE7D0DAF8E860EBC8D4FF83BB36B5D28 (void);
// 0x00000193 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::.ctor()
extern void XRInteractorReticleVisual__ctor_mFD83E499E0FA07F10EABBEE23FD64E49B2E36242 (void);
// 0x00000194 UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/InputTriggerType UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_selectActionTrigger()
extern void XRBaseControllerInteractor_get_selectActionTrigger_mEB3F19A8FAF90DFBE213816D80877BB422531872 (void);
// 0x00000195 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_selectActionTrigger(UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/InputTriggerType)
extern void XRBaseControllerInteractor_set_selectActionTrigger_m4C36C53409C73DE7D2953A1398281E40CFC8A2B8 (void);
// 0x00000196 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hideControllerOnSelect()
extern void XRBaseControllerInteractor_get_hideControllerOnSelect_mDF23B89216D3A760F0B8D0CBE14E346021A4DA42 (void);
// 0x00000197 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hideControllerOnSelect(System.Boolean)
extern void XRBaseControllerInteractor_set_hideControllerOnSelect_m3658DFD475416E84FD25A7B61B86AB1C9AF0882B (void);
// 0x00000198 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectEntered()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectEntered_mD283375EF9251B0CA334854C89E1EC9FA266A228 (void);
// 0x00000199 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectEntered_mBD1C058768A84ED6EC9F314E37F4592AF1FD1F4D (void);
// 0x0000019A UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectEntered()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectEntered_m9C9FF63AC7A1C8D91D11348A0D31E6074ED24049 (void);
// 0x0000019B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectEntered(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectEntered_m473038F69E9D7F786BCAB27E9E552A5269271A1A (void);
// 0x0000019C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectExited()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectExited_m08658F645DC323C76B6B8E21AFE6241FBB759364 (void);
// 0x0000019D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectExited_m335EC8ACA5A77DB98C06C7771BC5CA3547DEEA8B (void);
// 0x0000019E UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectExited()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectExited_mEFF33393BF04B828AC59CF7732438074D0C7C623 (void);
// 0x0000019F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectExited(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectExited_m4504F9A5426F547679B4AF306AF5AABDD6A1762A (void);
// 0x000001A0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectCanceled()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectCanceled_m87290C6673A2379E6F821133C9F56BBB6A38AEB0 (void);
// 0x000001A1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectCanceled_m9EB7D464A0B7AE48251953FD0C27A20F2A9FE842 (void);
// 0x000001A2 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectCanceled()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectCanceled_m4C3EC5CBE13D843E0F70502453DA6E440594EEA7 (void);
// 0x000001A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectCanceled(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectCanceled_mD1418B6C8C7D9BE930B61065A0B4426BB4DC2142 (void);
// 0x000001A4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverEntered()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverEntered_mC16557975B7ED2B7EB9BEAA7F9773C1977E40EFD (void);
// 0x000001A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverEntered_m8D391B6A3E43EDA651E4F6B8A2E98F41E7929F4B (void);
// 0x000001A6 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverEntered()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverEntered_mC5F687C936BE25BBEF1F98F018DBBAE9D6CAA4B9 (void);
// 0x000001A7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverEntered(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverEntered_m5D97BC75543001C1A6761F3E79D0DEED45E6002B (void);
// 0x000001A8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverExited()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverExited_m1059950C6BBA35508C69953A47A22E2CAEBB1FF2 (void);
// 0x000001A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverExited_mFFA05FF99316D3D2061B5E161957C12D8295A3F4 (void);
// 0x000001AA UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverExited()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverExited_mDB0AA5F79BF2780B18A1C34F21591B2C02F13BF8 (void);
// 0x000001AB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverExited(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverExited_mF81EF5D32D07A2A409669469E3A97D5A987E6CE9 (void);
// 0x000001AC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverCanceled()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverCanceled_mEC0540AA2F83B04F65D0DA7A42631E6DA292AC39 (void);
// 0x000001AD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverCanceled_m14EC235BE3C0B901FF33CAFA16D2759A2EF5CB56 (void);
// 0x000001AE UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverCanceled()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverCanceled_mD0D9C079B9C92FD38D4B1A482EA742D3B5925AF8 (void);
// 0x000001AF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverCanceled(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverCanceled_m7DB50A112B6BBAB000143ACB89D23000D173E20E (void);
// 0x000001B0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectEntered()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectEntered_mF2BB6170CFA6508A4ED9BB929BAA83E615C557AB (void);
// 0x000001B1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectEntered_mCADF142EC70C0C0F3631B2678F3A5043BE2AC146 (void);
// 0x000001B2 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectEnterIntensity_m5F736B8319F66BBA84625A6D75ADCBA873CA7473 (void);
// 0x000001B3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterIntensity_m4EB02CAF14353FBFCEAFFA2BDE85D8C681CD4490 (void);
// 0x000001B4 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterDuration()
extern void XRBaseControllerInteractor_get_hapticSelectEnterDuration_m35CD2EB4663BBE4BB2BB88C5A16814AE64508169 (void);
// 0x000001B5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterDuration_m8467B6E79882E4634E0D2D03C3019E4E1387CEE8 (void);
// 0x000001B6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectExited()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectExited_mCFA009625873489354775C5F0A7C189BEACB06BB (void);
// 0x000001B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectExited_m1B2B37CDBB81E9CC06D660FB789A56AE997DB1F1 (void);
// 0x000001B8 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectExitIntensity_m8B308438949D301C73193A18A0C418F7DE6CB43E (void);
// 0x000001B9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitIntensity_m9480569A24FE04DEF370071C331052527EF91EB5 (void);
// 0x000001BA System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitDuration()
extern void XRBaseControllerInteractor_get_hapticSelectExitDuration_mF95447258248FD7C1EFFAFE5AA44465F4C925174 (void);
// 0x000001BB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitDuration_m9CDAA15FB96BC535F8A2C9306F1801DFBF09F731 (void);
// 0x000001BC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectCanceled()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectCanceled_mB61136F04A77A69C974AD2C6613C843B96FD446B (void);
// 0x000001BD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectCanceled_m2768F130380A8B453605886FAEB5D4A217DAF514 (void);
// 0x000001BE System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectCancelIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectCancelIntensity_mC44B6CF2D6E2383295A885AC4782B53B84F5E609 (void);
// 0x000001BF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectCancelIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectCancelIntensity_m3DDF5CDF9D8239AF079790851E3D5BC34A5A89A0 (void);
// 0x000001C0 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectCancelDuration()
extern void XRBaseControllerInteractor_get_hapticSelectCancelDuration_m34DE8956EA0A74344706BE49FBAAA168E5941F53 (void);
// 0x000001C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectCancelDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectCancelDuration_m283CFEB61814CFBD127E6D8ACE726E61EFC3ACBB (void);
// 0x000001C2 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverEntered()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverEntered_m93D2390D87F047CCBB0F119DF15C115D1F076926 (void);
// 0x000001C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverEntered_mA90AC1C3FA080363C0B73EEE75F3A158889942D7 (void);
// 0x000001C4 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverEnterIntensity_m40C3EEE7C7F370148E53839507A83D6139E7ADC8 (void);
// 0x000001C5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterIntensity_m5A991BFABB8D84600AE577E20DED548563ECFCDF (void);
// 0x000001C6 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterDuration()
extern void XRBaseControllerInteractor_get_hapticHoverEnterDuration_m52B5409E6D2753C2A08DBCD5D1C9FC41E0F14FE7 (void);
// 0x000001C7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterDuration_m8788CB468B533D8D732828EB5026E93BAC139006 (void);
// 0x000001C8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverExited()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverExited_mA339F20F0CF89A50E5368147578CA292356F3C36 (void);
// 0x000001C9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverExited_mF31BE0F7E52E53D04582C45F0A21A5534663949E (void);
// 0x000001CA System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverExitIntensity_m8721A715EC3A9536DA76AD710C20774DEB4E2DBE (void);
// 0x000001CB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitIntensity_m63B54A4CC033C27C08B27DD470E7457415500435 (void);
// 0x000001CC System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitDuration()
extern void XRBaseControllerInteractor_get_hapticHoverExitDuration_m2BBCA730DED74BCAAA3B7FE7AD561B0EE74C22CF (void);
// 0x000001CD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitDuration_mCBEDDF666434D1BE8B41CA4C46CC311206F037FC (void);
// 0x000001CE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverCanceled()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverCanceled_mA4B3774B49FFB5A33A98F02A29170C8FC1DF83E8 (void);
// 0x000001CF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverCanceled_m1DBDAEF87815F4EC72B40FDF277F69216180F53C (void);
// 0x000001D0 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverCancelIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverCancelIntensity_m7F8FA26D95AC57C6D540FE557306FA23BFECF9E6 (void);
// 0x000001D1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverCancelIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverCancelIntensity_mDFEBCBB209E0B58DD5987151572075FC46043CCF (void);
// 0x000001D2 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverCancelDuration()
extern void XRBaseControllerInteractor_get_hapticHoverCancelDuration_m98D8EA0FA49739D52C9E90581A7F0A51F14420AD (void);
// 0x000001D3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverCancelDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverCancelDuration_mD924C78944E3ABA1A78367D497ADED5230799FC1 (void);
// 0x000001D4 UnityEngine.XR.Interaction.Toolkit.XRBaseController UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_xrController()
extern void XRBaseControllerInteractor_get_xrController_mD5F553C6509F366C42DBCBE094C88C8E4911F30C (void);
// 0x000001D5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_xrController(UnityEngine.XR.Interaction.Toolkit.XRBaseController)
extern void XRBaseControllerInteractor_set_xrController_m6976CFA96A0AB2C0A16670FB353706777B698BB2 (void);
// 0x000001D6 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_validTargets()
// 0x000001D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::Awake()
extern void XRBaseControllerInteractor_Awake_m5928A93A57F57571124F8165E9FB5A78F03D6C1E (void);
// 0x000001D8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseControllerInteractor_ProcessInteractor_m48B7F4340BFD8B4F7E6C0AB5F7D0478916A18E3D (void);
// 0x000001D9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isSelectActive()
extern void XRBaseControllerInteractor_get_isSelectActive_m07495FDEC77FF5660F1E4F0EAA30740BF80D0D8C (void);
// 0x000001DA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isUISelectActive()
extern void XRBaseControllerInteractor_get_isUISelectActive_mF377D3864A70E34C5ADACF00AAF3C344DB8275EB (void);
// 0x000001DB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseControllerInteractor_OnSelectEntering_mE03EEB44AAA35297AA1ABEB45167ABCD7C1B318F (void);
// 0x000001DC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseControllerInteractor_OnSelectExiting_mF0482C8368115E0F15EC7805DE569C0A5585631D (void);
// 0x000001DD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseControllerInteractor_OnHoverEntering_m9683A9F31AEB67A0842F4BA8693372C4743735E7 (void);
// 0x000001DE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseControllerInteractor_OnHoverExiting_m2137AF8DA95FD98EABC55DE3A16CE8BA15422667 (void);
// 0x000001DF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::SendHapticImpulse(System.Single,System.Single)
extern void XRBaseControllerInteractor_SendHapticImpulse_mD4DD3CB4B43725EF55994A8B79B00F05D16076BA (void);
// 0x000001E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::PlayAudio(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_PlayAudio_m46DA65BC88916FC5BF839AC76352803ED96F185D (void);
// 0x000001E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::CreateEffectsAudioSource()
extern void XRBaseControllerInteractor_CreateEffectsAudioSource_mC46CFB8149442289C6CBDA01B6BD69FF7DAC0B30 (void);
// 0x000001E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::HandleSelecting()
extern void XRBaseControllerInteractor_HandleSelecting_mA0AD415937149F3D40FECD2414D6B93126DF717B (void);
// 0x000001E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::HandleDeselecting()
extern void XRBaseControllerInteractor_HandleDeselecting_mC0A8A94F47655F67981524052CBFDBAC584983E3 (void);
// 0x000001E4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_mD4A2D6672AC00E0ABCA375C25B3E5F91FD0B3B0C (void);
// 0x000001E5 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectEnter()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectEnter_m542ED00D22426B9F2720A006CC4A8A9AC1F1CEC9 (void);
// 0x000001E6 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m36BB85ADCEDE964ECFD978109BCDC6CC02832A94 (void);
// 0x000001E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m6E7A0E1DC45B2B35CD2FB049991C8FC5C19E8679 (void);
// 0x000001E8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m62CBE6A8A87E25AFB9FD14A7557B9898141F5FA2 (void);
// 0x000001E9 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectExit()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectExit_mB89C17FB92E542CE40AB3CEE65D200FAF6DDF40E (void);
// 0x000001EA UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectExit_m1B854FD0BA8D624F29980EB7371B0A2869883CB5 (void);
// 0x000001EB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mC6B39D83157978775708C8FF97BE7D9D5E84C111 (void);
// 0x000001EC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_mF3A6DE58ED5E608605A0C57B8A58E40EDE32F288 (void);
// 0x000001ED UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverEnter()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverEnter_m3579C9FDB8E9A3EAE90DC9A7D59C8EC6C01FA1C2 (void);
// 0x000001EE UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_m298AC1C585EBC7399C93BEE1D0E789950C2A4620 (void);
// 0x000001EF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_m58478657E548BE914881AD2E1ED9A5607198D5F2 (void);
// 0x000001F0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverExit_mE0440D9008F7396FE6A385C91213A52A0DDBDFD0 (void);
// 0x000001F1 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverExit()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverExit_mD3F78A869E279EC2CD04E0B9275A05AE6CB51458 (void);
// 0x000001F2 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverExit_mA08B482833C2793EC0983C63F631AABB483DBA1C (void);
// 0x000001F3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverExit_mA233E5410865DE254706F4A6420ED125C1D7D638 (void);
// 0x000001F4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectEnter_mBE869139D32D2FCB4A7A1E625D4BB8270CDEC5CD (void);
// 0x000001F5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectExit()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectExit_m2B565B8BDC73161C9164FDE54C16CEE59FEC0789 (void);
// 0x000001F6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverEnter_mCCE460E3803E34602FC18E580ADFE42AED145F6E (void);
// 0x000001F7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::.ctor()
extern void XRBaseControllerInteractor__ctor_m9DFBF006FE6B69171E8913BFCE74D2E9000EF2D5 (void);
// 0x000001F8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRBaseInteractor_add_registered_mB0EFEF8438E6EA4ACECDD9B291AAE1A9BE0AD5D5 (void);
// 0x000001F9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRBaseInteractor_remove_registered_mCB720EC6C856730BFF04241DE157D5FDB83390C4 (void);
// 0x000001FA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRBaseInteractor_add_unregistered_m2C80C55F46F1F9A8107D0F44701A67A21F723024 (void);
// 0x000001FB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRBaseInteractor_remove_unregistered_m9C5E7918732F01064D4076C6A40CE13A519AA854 (void);
// 0x000001FC UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionManager()
extern void XRBaseInteractor_get_interactionManager_mD788218F91219F2327A02B1350DC930E3D3432F4 (void);
// 0x000001FD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractor_set_interactionManager_mF970116906FFAE5CD7772CE24FBB41D491C00695 (void);
// 0x000001FE UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionLayerMask()
extern void XRBaseInteractor_get_interactionLayerMask_m8CF4046276AFD5EC4E36EC86176123742CEB5C13 (void);
// 0x000001FF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractor_set_interactionLayerMask_m835B6F35ACFC0B66F5C664707B0DBCD25EBCBF89 (void);
// 0x00000200 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_attachTransform()
extern void XRBaseInteractor_get_attachTransform_m9B4E7DE7F5374B2CDAA5256E6CF2D72FC3AF09D1 (void);
// 0x00000201 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_attachTransform(UnityEngine.Transform)
extern void XRBaseInteractor_set_attachTransform_mE9AFEDA319291A10B90FA10D74C8A1D110D6B8B1 (void);
// 0x00000202 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_startingSelectedInteractable()
extern void XRBaseInteractor_get_startingSelectedInteractable_m6E35F0706C2BDBE89010B65B465F7610949B4680 (void);
// 0x00000203 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_startingSelectedInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_set_startingSelectedInteractable_m8A13723D7F503A44FEDED4440A9C475EE0AA4A84 (void);
// 0x00000204 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverEntered()
extern void XRBaseInteractor_get_hoverEntered_m444F4A60AE6CF56FCC4522225155A49A46A5B9A8 (void);
// 0x00000205 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_hoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractor_set_hoverEntered_m575703CB90F96D04C1DE1098A326EF7B45A420AD (void);
// 0x00000206 UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverExited()
extern void XRBaseInteractor_get_hoverExited_m2D37FB1C6B47CC020603FAA640642DB9F14798FE (void);
// 0x00000207 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_hoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractor_set_hoverExited_m7BBD5F61B4ECB566AF224A7E41E50F0EBA8ED7FB (void);
// 0x00000208 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectEntered()
extern void XRBaseInteractor_get_selectEntered_m957269B06CBB2BB5CBF550B0B7853F0CE296DF64 (void);
// 0x00000209 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent)
extern void XRBaseInteractor_set_selectEntered_mED77DDD1F8739A97581B359ACAF8848F58E1E1DC (void);
// 0x0000020A UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectExited()
extern void XRBaseInteractor_get_selectExited_m05B02D438D30646B7AD5827FCEBCA401E8AA0C23 (void);
// 0x0000020B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEvent)
extern void XRBaseInteractor_set_selectExited_m4F835CD06D8F72BA0984AE3A0A86A668AD92B4B1 (void);
// 0x0000020C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowHover()
extern void XRBaseInteractor_get_allowHover_m491FE90B83669D9AB429D271AD1B88D31B01393E (void);
// 0x0000020D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowHover(System.Boolean)
extern void XRBaseInteractor_set_allowHover_m313B52A3C885E13A10C6D611D1EA2EC43CD1B352 (void);
// 0x0000020E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowSelect()
extern void XRBaseInteractor_get_allowSelect_m07A9ADAC4DE19A8533147926B68B6F4B1B742850 (void);
// 0x0000020F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowSelect(System.Boolean)
extern void XRBaseInteractor_set_allowSelect_m094F101EE5C21F36E284A38CF94A46AA1320E359 (void);
// 0x00000210 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isPerformingManualInteraction()
extern void XRBaseInteractor_get_isPerformingManualInteraction_m7357ED7B9A1C9806164865C951928171899F1B3C (void);
// 0x00000211 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectTarget()
extern void XRBaseInteractor_get_selectTarget_mEA10D51DB4A57FC59E69E115A4408F1414FC38BA (void);
// 0x00000212 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectTarget(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_set_selectTarget_mBB9E53626D2294BDFAAA9251FA4E196B551F9D65 (void);
// 0x00000213 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverTargets()
extern void XRBaseInteractor_get_hoverTargets_mF2CC203D60951BBD907931F8971169D29867074B (void);
// 0x00000214 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Reset()
extern void XRBaseInteractor_Reset_mAD176832E0C0B17DD0AAE6B19369ABFAA0D288AC (void);
// 0x00000215 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Awake()
extern void XRBaseInteractor_Awake_m3F11BBAC030E198213D828F5E5CB262C45FEC88A (void);
// 0x00000216 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnEnable()
extern void XRBaseInteractor_OnEnable_mCEEA2E704A8CB811724219B0742C216CA16124D0 (void);
// 0x00000217 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDisable()
extern void XRBaseInteractor_OnDisable_mF1966E65AABD1F5BC73F5F27593AEA54DA366A3A (void);
// 0x00000218 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Start()
extern void XRBaseInteractor_Start_mE91DB6506CB783CAF6E0E47F1B8423571BBB9052 (void);
// 0x00000219 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDestroy()
extern void XRBaseInteractor_OnDestroy_mF09360B0AFBDF120CE1FD1D70885C7950F8B4C65 (void);
// 0x0000021A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetHoverTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRBaseInteractor_GetHoverTargets_mC312C5DB084E10B8BF10BF4D02C01DFB2B53374A (void);
// 0x0000021B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
// 0x0000021C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::FindCreateInteractionManager()
extern void XRBaseInteractor_FindCreateInteractionManager_mF3D7E524D16482729F4858716C73792F4C09A37F (void);
// 0x0000021D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::RegisterWithInteractionManager()
extern void XRBaseInteractor_RegisterWithInteractionManager_m8BEA8B1B49C1011214ED028284B16AFFD8E36150 (void);
// 0x0000021E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnregisterWithInteractionManager()
extern void XRBaseInteractor_UnregisterWithInteractionManager_mBC307B23DC4B6EB37BAF84CF7D8A086863F31E20 (void);
// 0x0000021F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsOnValidLayerMask(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_IsOnValidLayerMask_m2D17074B0D638D87C9D16DC1F3F62835381313E8 (void);
// 0x00000220 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isHoverActive()
extern void XRBaseInteractor_get_isHoverActive_m95DA85F5073E46E3CB78302FADD40807BEE8C9BF (void);
// 0x00000221 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isSelectActive()
extern void XRBaseInteractor_get_isSelectActive_m26E5368E8E32FE4AD712BB72630281B06FA174DD (void);
// 0x00000222 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanHover_m7F915707B115431AC270F5C7DD2F7508C6FFAD9E (void);
// 0x00000223 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanSelect_m808F054C8D6DB8394F942167FF67CD992F9D00E8 (void);
// 0x00000224 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_requireSelectExclusive()
extern void XRBaseInteractor_get_requireSelectExclusive_m86FD377045D63B47945CCCCF82D30C48848A1402 (void);
// 0x00000225 System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m2CF71D48E97E8A9635AF9D395A59D6080D5DD422 (void);
// 0x00000226 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRBaseInteractor_OnRegistered_mD7B06E16B9875D9DBE6CF50596192358F2AA96C1 (void);
// 0x00000227 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRBaseInteractor_OnUnregistered_m4EBE7B17873E8113BC9BACDBAB75249D7FBDD2FC (void);
// 0x00000228 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_OnHoverEntering_m4FC0C04996461A443E49534463151B94DEF77021 (void);
// 0x00000229 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_OnHoverEntered_mD6E30228AB6FCEA8A80BBFF2ECD5B791B2AE396C (void);
// 0x0000022A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_OnHoverExiting_m44F40CB3CF558B99A38BFB6553A15EC229A2B71E (void);
// 0x0000022B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_OnHoverExited_m7DF29FD62673E9662D29307768AC98DB082EB18E (void);
// 0x0000022C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_OnSelectEntering_m374F174098B188059D3F76C2CBFB94923144212B (void);
// 0x0000022D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_OnSelectEntered_mB11BF9F302085510EE9DDF6C3B81DE2C1632EEC0 (void);
// 0x0000022E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_OnSelectExiting_mC47F4AECFED9FD4E5F6A8C0BE93C9A0A7C43749D (void);
// 0x0000022F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_OnSelectExited_m5A8A9818741F28F05EA3A36836BC399B9867D218 (void);
// 0x00000230 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseInteractor_ProcessInteractor_m23376B99DA8A3C6638CC3FD4FD2148A399C5D915 (void);
// 0x00000231 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::StartManualInteraction(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_StartManualInteraction_m7AC3B5F8B8F8D29B4C7C87DC4D4BDD49F808C650 (void);
// 0x00000232 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::EndManualInteraction()
extern void XRBaseInteractor_EndManualInteraction_mF0BA787739E0EB7FD78E43E705F3FA90AFE39622 (void);
// 0x00000233 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_enableInteractions()
extern void XRBaseInteractor_get_enableInteractions_m9FD194A044BF2D85E6C3DF9DF9901F755F65FEC3 (void);
// 0x00000234 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_enableInteractions(System.Boolean)
extern void XRBaseInteractor_set_enableInteractions_m2845CDCC919232D2D5FB94868E08EAC87CA90EDD (void);
// 0x00000235 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverEntered()
extern void XRBaseInteractor_get_onHoverEntered_mAFF22647AE75A7B54B680500E2F4BF2F0065EBD7 (void);
// 0x00000236 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverEntered_m7044D9AD6CC2B4918295FD460EA4EA5C123821DC (void);
// 0x00000237 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverExited()
extern void XRBaseInteractor_get_onHoverExited_m1F67BDE7594CDEDD404445CC3B17D1BCB4596C7A (void);
// 0x00000238 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverExited_m0517740B5A0EA2C50E1B5C75C5F34D5690CF8420 (void);
// 0x00000239 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectEntered()
extern void XRBaseInteractor_get_onSelectEntered_m274BD10B2794A5BB403939A510642A03573DB6D0 (void);
// 0x0000023A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectEntered_m0E83F4755C4D4BE02CE4ACA9829325C634AD872F (void);
// 0x0000023B UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectExited()
extern void XRBaseInteractor_get_onSelectExited_mE1AFE8A1F0694D4666EC5358B535424E227EB977 (void);
// 0x0000023C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectExited(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectExited_m1284249A6BC3784D72B563D343C681BD198D0EE5 (void);
// 0x0000023D UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverEnter()
extern void XRBaseInteractor_get_onHoverEnter_m693C212A919B03F74F2D69B20DAA2D93B906DE76 (void);
// 0x0000023E UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverExit()
extern void XRBaseInteractor_get_onHoverExit_m2A0CAE4341ACE33B509BE2EC9D613F9323252CD2 (void);
// 0x0000023F UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectEnter()
extern void XRBaseInteractor_get_onSelectEnter_mE7024934D5DEF00A4FFEF5A63BDBC670586EFFD2 (void);
// 0x00000240 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectExit()
extern void XRBaseInteractor_get_onSelectExit_m9047E0F399D8D1492DCD0BD341CB481AC8C6BB26 (void);
// 0x00000241 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverEntering_m83374B43BDABEC4D426B097C5ACB41DD54495350 (void);
// 0x00000242 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverEntered_m49ECCF88AE091262B4B0583842AF79F3B623C6B7 (void);
// 0x00000243 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverExiting_mC519C8B22745BE1F74A7248DE60C6162EB05199D (void);
// 0x00000244 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverExited_mD9E7E14FA53A1EE27E9D6FD5803FDC1A32F2E4F6 (void);
// 0x00000245 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectEntering_mEB04C1D0F5658BE9834F60F11176131C2E269ABA (void);
// 0x00000246 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectEntered_m141EDCD666A08B559AAFDC9B4F4554D79A620358 (void);
// 0x00000247 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectExiting_m9E592E95AF9402E23F9BF24591ED343ABFC85087 (void);
// 0x00000248 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectExited_m9B7CF8908EBD9B81811E92373CB81F2A060F8429 (void);
// 0x00000249 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::.ctor()
extern void XRBaseInteractor__ctor_m416F8C37308B52430F9AD423030D16AB7E05A485 (void);
// 0x0000024A System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::get_validTargets()
extern void XRDirectInteractor_get_validTargets_m1AF702AA9B4EB8013898DC46745291C36EA7C751 (void);
// 0x0000024B System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::Awake()
extern void XRDirectInteractor_Awake_m6A97849BF2715AFAE1B45A58DEAC64321E58A170 (void);
// 0x0000024C System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerEnter_m2BED922A3348BC78CD78EF76A681C61C0B1FB859 (void);
// 0x0000024D System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerExit_m12DDECA7D86D1FBBE158E18ACCDB67E1E81CEB2E (void);
// 0x0000024E System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRDirectInteractor_GetValidTargets_m8CA5BC1503992AA42CC5F28F49B104B11ECAB2A1 (void);
// 0x0000024F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanHover_mC2A95DB54AB18945121EC18C22ADA8B1FBAF808C (void);
// 0x00000250 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanSelect_m2293AFCD6B146DE13457AC62C663375CCA80E634 (void);
// 0x00000251 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRDirectInteractor_OnRegistered_m3EDF1F3036E19EEDAB2A0F590EDAEFAC62BA5FA1 (void);
// 0x00000252 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRDirectInteractor_OnUnregistered_m62CC0E93B54511BE86FE3FDCA518E1C06A2F1ED0 (void);
// 0x00000253 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnInteractableUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRDirectInteractor_OnInteractableUnregistered_mF5B17FC26121AF3482D3CADDBD2CCBAD21B329D5 (void);
// 0x00000254 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::InteractableSortComparison(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_InteractableSortComparison_m143F0F61981CFCE474AFCA233BA3681F49B67A99 (void);
// 0x00000255 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::.ctor()
extern void XRDirectInteractor__ctor_m7C0F3A54E51B983F48EB7F5863FCAC7C42F149F0 (void);
// 0x00000256 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<>c::.cctor()
extern void U3CU3Ec__cctor_m7113D3B1D2708F3917ED2EAC05D1388E8A0869EA (void);
// 0x00000257 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<>c::.ctor()
extern void U3CU3Ec__ctor_m7BFB0E1AB4BB50E1AF50E2EF22CC0DFD6582F206 (void);
// 0x00000258 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<>c::<Awake>b__5_0(UnityEngine.Collider)
extern void U3CU3Ec_U3CAwakeU3Eb__5_0_m79517FA0D828BB2DDD9BA228C01AD9BE8F2D12AB (void);
// 0x00000259 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/LineType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_lineType()
extern void XRRayInteractor_get_lineType_m11B4D85B8C272C14A1E56D10BE445E8FA4FE7691 (void);
// 0x0000025A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_lineType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/LineType)
extern void XRRayInteractor_set_lineType_m17CBCF1710C4A02973ABC04180519A4554B16CFA (void);
// 0x0000025B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_blendVisualLinePoints()
extern void XRRayInteractor_get_blendVisualLinePoints_m6C845075BDFDEFD63E97FA42AE6DB662D1851D14 (void);
// 0x0000025C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_blendVisualLinePoints(System.Boolean)
extern void XRRayInteractor_set_blendVisualLinePoints_m0BFBF471BADBDAF001F2C2EA997182155FFE064C (void);
// 0x0000025D System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_maxRaycastDistance()
extern void XRRayInteractor_get_maxRaycastDistance_mE47EBDEA1527A4BDF74BBFD9D530BD4184C5AA09 (void);
// 0x0000025E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_maxRaycastDistance(System.Single)
extern void XRRayInteractor_set_maxRaycastDistance_m38BACC2D65D05D5696748475060D7E3B44804319 (void);
// 0x0000025F UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_referenceFrame()
extern void XRRayInteractor_get_referenceFrame_mA29F959BDD666B803C63F5DD648E898AB583C6F9 (void);
// 0x00000260 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_referenceFrame(UnityEngine.Transform)
extern void XRRayInteractor_set_referenceFrame_mA6EF45AC331203EC2EB9A9DA1B27959DC70B5860 (void);
// 0x00000261 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_velocity()
extern void XRRayInteractor_get_velocity_m227A140028A71A480D57CDF9616943D527481EC3 (void);
// 0x00000262 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_velocity(System.Single)
extern void XRRayInteractor_set_velocity_m5DB40D005635BE837486D8E804ABD630F368BAAB (void);
// 0x00000263 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Velocity()
extern void XRRayInteractor_get_Velocity_mCAA5773EC425C7C8D406B6E9CDE0E73EB53D7A44 (void);
// 0x00000264 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Velocity(System.Single)
extern void XRRayInteractor_set_Velocity_m97774541B2086E548751AC4B1284BDE9002B824F (void);
// 0x00000265 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_acceleration()
extern void XRRayInteractor_get_acceleration_m19C2CF4596F8D511C547D4A3A1812DC97B1A20E6 (void);
// 0x00000266 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_acceleration(System.Single)
extern void XRRayInteractor_set_acceleration_mEF6265CE2277BD768AB3D2554211A20969F95531 (void);
// 0x00000267 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Acceleration()
extern void XRRayInteractor_get_Acceleration_m9B8D964257B15D8775D8303164197A33AFE9F584 (void);
// 0x00000268 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Acceleration(System.Single)
extern void XRRayInteractor_set_Acceleration_mDB202F18C30CE5041AB9B1FC62E4D19CCFE73074 (void);
// 0x00000269 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_additionalGroundHeight()
extern void XRRayInteractor_get_additionalGroundHeight_mC0BB49D530C0CC6F908D8DDE5C17BB5E68829CB1 (void);
// 0x0000026A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_additionalGroundHeight(System.Single)
extern void XRRayInteractor_set_additionalGroundHeight_mD709D8B7D9C89E68517A5F7CF2B826160D0F2F86 (void);
// 0x0000026B System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_additionalFlightTime()
extern void XRRayInteractor_get_additionalFlightTime_m5971989C99031D0872BDB3D70C8FAF97ADD37865 (void);
// 0x0000026C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_additionalFlightTime(System.Single)
extern void XRRayInteractor_set_additionalFlightTime_m8425E7065E133CC3C1EA0F87317323531E134C9B (void);
// 0x0000026D System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_AdditionalFlightTime()
extern void XRRayInteractor_get_AdditionalFlightTime_m1F9FC8CB6580E5E2B5F8436221BA619DDE0EE78A (void);
// 0x0000026E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_AdditionalFlightTime(System.Single)
extern void XRRayInteractor_set_AdditionalFlightTime_m961FC7F399D855DEFCFD7ED18C738A694E2FCE11 (void);
// 0x0000026F System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointDistance()
extern void XRRayInteractor_get_endPointDistance_mE30109C61BC5A973748E3EC6C9C9A5822EA0C9B1 (void);
// 0x00000270 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointDistance(System.Single)
extern void XRRayInteractor_set_endPointDistance_m5F04BAEBA57074C0EA3782B1E18C138AE91F855E (void);
// 0x00000271 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointHeight()
extern void XRRayInteractor_get_endPointHeight_m00E3D4BD1AAE1682300E4D4C30178B75C6EEC809 (void);
// 0x00000272 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointHeight(System.Single)
extern void XRRayInteractor_set_endPointHeight_mC9726D5243B67607F2CE487A768D9F473790D522 (void);
// 0x00000273 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointDistance()
extern void XRRayInteractor_get_controlPointDistance_mB480B8CF83CD8212F64D86F174F6A58781052781 (void);
// 0x00000274 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointDistance(System.Single)
extern void XRRayInteractor_set_controlPointDistance_m8552521764279C47C50AF061B17D6931C1B8506D (void);
// 0x00000275 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointHeight()
extern void XRRayInteractor_get_controlPointHeight_m88F12EB5E089D06EF31370972B99D89B29237DD6 (void);
// 0x00000276 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointHeight(System.Single)
extern void XRRayInteractor_set_controlPointHeight_m844AC6D4A4AFF0AFC15675C17693E7F1F74F6527 (void);
// 0x00000277 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sampleFrequency()
extern void XRRayInteractor_get_sampleFrequency_m8D920A45B693FA1B4F5D050B2479D5B1C0F5ED74 (void);
// 0x00000278 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sampleFrequency(System.Int32)
extern void XRRayInteractor_set_sampleFrequency_mFF32EB51ECFC30638F77B13DC6DF29B6428E3CD2 (void);
// 0x00000279 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/HitDetectionType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hitDetectionType()
extern void XRRayInteractor_get_hitDetectionType_mF3AB6CD1643A777AA8E51647B54F0C6E39557C33 (void);
// 0x0000027A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hitDetectionType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/HitDetectionType)
extern void XRRayInteractor_set_hitDetectionType_m2B3FC19DB2D0DCCD71162EC1A451039363CA17DA (void);
// 0x0000027B System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sphereCastRadius()
extern void XRRayInteractor_get_sphereCastRadius_mBCEE5E284DE90F4F6FE0408B10A99737467743E7 (void);
// 0x0000027C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sphereCastRadius(System.Single)
extern void XRRayInteractor_set_sphereCastRadius_m40DBA5693FC75B4AA5DCEEBAA3569BBF6D9BF913 (void);
// 0x0000027D UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastMask()
extern void XRRayInteractor_get_raycastMask_m5DD13EF3F5F85E41ED1CCF8267F81355E94D0A6D (void);
// 0x0000027E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastMask(UnityEngine.LayerMask)
extern void XRRayInteractor_set_raycastMask_m890AF8A4109415139463FFBCE431D82868689ED4 (void);
// 0x0000027F UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastTriggerInteraction()
extern void XRRayInteractor_get_raycastTriggerInteraction_m12AFB0195BEF2E3DF8598605430E2598F327C914 (void);
// 0x00000280 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void XRRayInteractor_set_raycastTriggerInteraction_m71DE8A036D3EF39798A49A5A07FFD1BA3A467D98 (void);
// 0x00000281 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hitClosestOnly()
extern void XRRayInteractor_get_hitClosestOnly_m025D49BD73B2E060EAF90CAF59627F780879E96B (void);
// 0x00000282 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hitClosestOnly(System.Boolean)
extern void XRRayInteractor_set_hitClosestOnly_mE09BC1C251D5F72271B2D41B26429DEA4A0A8CF5 (void);
// 0x00000283 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_keepSelectedTargetValid()
extern void XRRayInteractor_get_keepSelectedTargetValid_mFB34B5504DFCCF73DC1E2043A4904621D017AE44 (void);
// 0x00000284 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_keepSelectedTargetValid(System.Boolean)
extern void XRRayInteractor_set_keepSelectedTargetValid_m396CF73104C5A4E4A8804E93F27190ED2C78F854 (void);
// 0x00000285 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverToSelect()
extern void XRRayInteractor_get_hoverToSelect_mD75EAD2BC3C0FD473C2129F174838EE300F3B93A (void);
// 0x00000286 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverToSelect(System.Boolean)
extern void XRRayInteractor_set_hoverToSelect_m3C4B41C2FA76048E938262B260DDB95552C359F5 (void);
// 0x00000287 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverTimeToSelect()
extern void XRRayInteractor_get_hoverTimeToSelect_m0A153949AB600C6F36F704DC3F18A797E08E416C (void);
// 0x00000288 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverTimeToSelect(System.Single)
extern void XRRayInteractor_set_hoverTimeToSelect_mC9200C05C52151CE7CF6528DBF08EF869DDA38F7 (void);
// 0x00000289 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_enableUIInteraction()
extern void XRRayInteractor_get_enableUIInteraction_m14935C7E914EFBE4DD26D0E3ED572468DF32237B (void);
// 0x0000028A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_enableUIInteraction(System.Boolean)
extern void XRRayInteractor_set_enableUIInteraction_m2AE7009548EB5C565E3D75FEF5E248F709B3DAF6 (void);
// 0x0000028B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_allowAnchorControl()
extern void XRRayInteractor_get_allowAnchorControl_m242237B56F9D006AF8D11276574ECB530720A2ED (void);
// 0x0000028C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_allowAnchorControl(System.Boolean)
extern void XRRayInteractor_set_allowAnchorControl_mEE404127B285C2165FCF33E1814B69DCF4FF04FA (void);
// 0x0000028D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_useForceGrab()
extern void XRRayInteractor_get_useForceGrab_m1620DE5DB43598F5039EC0776685DC2DDB7F04F9 (void);
// 0x0000028E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_useForceGrab(System.Boolean)
extern void XRRayInteractor_set_useForceGrab_mFFE852F1EA638243A48679A40090155CE9906130 (void);
// 0x0000028F System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_rotateSpeed()
extern void XRRayInteractor_get_rotateSpeed_m2D6670B86E97DBBF4694C45F8DE20C085B9D5D8F (void);
// 0x00000290 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_rotateSpeed(System.Single)
extern void XRRayInteractor_set_rotateSpeed_m2D4B2F9773FC63AD8CB9000F9BB17D75F6B6770B (void);
// 0x00000291 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_translateSpeed()
extern void XRRayInteractor_get_translateSpeed_m6924A183E73DE03B4D492AB2C616E9DB9DCA6837 (void);
// 0x00000292 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_translateSpeed(System.Single)
extern void XRRayInteractor_set_translateSpeed_mEDDF4A2F6B3E98752CEAC5FAF0FA6E582458D591 (void);
// 0x00000293 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_anchorRotateReferenceFrame()
extern void XRRayInteractor_get_anchorRotateReferenceFrame_mBCDA92984F7C4CC671A9886D082711139263AE20 (void);
// 0x00000294 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_anchorRotateReferenceFrame(UnityEngine.Transform)
extern void XRRayInteractor_set_anchorRotateReferenceFrame_m883BB8D901022956EE2F9971ED616888AC610E30 (void);
// 0x00000295 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_angle()
extern void XRRayInteractor_get_angle_mEDC17A18128FA628AAC2CE9BC2A8A5403E6D034A (void);
// 0x00000296 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Angle()
extern void XRRayInteractor_get_Angle_m70550DA809D001294D8E33E8F76DE8C7286E95C8 (void);
// 0x00000297 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_validTargets()
extern void XRRayInteractor_get_validTargets_m65662331C48C792FB9FF65ED8A69F6A366155ACC (void);
// 0x00000298 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_originalAttachTransform()
extern void XRRayInteractor_get_originalAttachTransform_m8CD24BD76F86C1F744D0F5F57010A5957B2DC8FB (void);
// 0x00000299 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_originalAttachTransform(UnityEngine.Transform)
extern void XRRayInteractor_set_originalAttachTransform_m3CA533F587EDA6C7C181C15FC5E87100B9E5D2B9 (void);
// 0x0000029A UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_startTransform()
extern void XRRayInteractor_get_startTransform_m00666CB85DDDA0A708CDAE97B28CCD84478F91C1 (void);
// 0x0000029B System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_closestAnyHitIndex()
extern void XRRayInteractor_get_closestAnyHitIndex_mFD451C9E7949B9549D237491B7D7DAC13FF90126 (void);
// 0x0000029C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnValidate()
extern void XRRayInteractor_OnValidate_m6060C5021926329D95CF1F6162DE6A424EC9B632 (void);
// 0x0000029D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::Awake()
extern void XRRayInteractor_Awake_m4503C881D61C7126AB419599B588224FF00FA0DB (void);
// 0x0000029E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnEnable()
extern void XRRayInteractor_OnEnable_mC1ACDA1ADC5ED1A4042CDC7B7FD8F5467EEC9692 (void);
// 0x0000029F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnDisable()
extern void XRRayInteractor_OnDisable_m847772A1615B3E214E40FDF6457AD4EB2D829A59 (void);
// 0x000002A0 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnDrawGizmosSelected()
extern void XRRayInteractor_OnDrawGizmosSelected_mC987E08C5D085D1E689743228B20A5AFFE39085E (void);
// 0x000002A1 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::DrawQuadraticBezierGizmo(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_DrawQuadraticBezierGizmo_m595235FA27EC9B4183EE1DB3B94BECBCF4D08B88 (void);
// 0x000002A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindReferenceFrame()
extern void XRRayInteractor_FindReferenceFrame_mA3D7EF2139B3C22305D33F24529C0FC27DE64BF8 (void);
// 0x000002A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindOrCreateXRUIInputModule()
extern void XRRayInteractor_FindOrCreateXRUIInputModule_m2FD04205A59C9F9115CE8721D7B7E2B90DEDD0BE (void);
// 0x000002A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RegisterWithXRUIInputModule()
extern void XRRayInteractor_RegisterWithXRUIInputModule_mA50537933174D1DC0DE9C6DBB59AC38A363E8E95 (void);
// 0x000002A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UnregisterFromXRUIInputModule()
extern void XRRayInteractor_UnregisterFromXRUIInputModule_mE0528A10E0B76823EC56B44904604BF3B4D06710 (void);
// 0x000002A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RegisterOrUnregisterXRUIInputModule()
extern void XRRayInteractor_RegisterOrUnregisterXRUIInputModule_mD07A6BC10395319460483F32FADE18557038E8C3 (void);
// 0x000002A7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&,System.Int32)
extern void XRRayInteractor_GetLinePoints_mA1067E0F64AAE5D39D020231CEF416B0C5893189 (void);
// 0x000002A8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
extern void XRRayInteractor_GetLinePoints_m9315038405AE0F4312E52CEA0A8A7913E0DE818E (void);
// 0x000002A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::EnsureCapacity(UnityEngine.Vector3[]&,System.Int32)
extern void XRRayInteractor_EnsureCapacity_m0742B92557999003466040218B42B985D4133A0E (void);
// 0x000002AA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&,System.Int32)
extern void XRRayInteractor_TryGetHitInfo_m1368D9C2A57C2A93E81457E39D2030FA459BF31D (void);
// 0x000002AB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
extern void XRRayInteractor_TryGetHitInfo_m0A30AF00366B29D4D3A3DD39BE123594F26A82D2 (void);
// 0x000002AC System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_UpdateUIModel_mF222C4CBACAF69BAD574C7872AAC2527B99A3B7E (void);
// 0x000002AD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_TryGetUIModel_mB22719D248F0BE483F4317627B2006AFA06B3EFD (void);
// 0x000002AE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetCurrentRaycastHit(UnityEngine.RaycastHit&)
extern void XRRayInteractor_GetCurrentRaycastHit_mC20769C958197D0ED1DB3FFE90411BB501E86262 (void);
// 0x000002AF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrent3DRaycastHit(UnityEngine.RaycastHit&)
extern void XRRayInteractor_TryGetCurrent3DRaycastHit_m57BAB5FB88C551B6DDB78E8F1059DBBBF80E0E2E (void);
// 0x000002B0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrent3DRaycastHit(UnityEngine.RaycastHit&,System.Int32&)
extern void XRRayInteractor_TryGetCurrent3DRaycastHit_m3F194C672E7D82034ECB54FCD4A2AFE925C5C574 (void);
// 0x000002B1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentUIRaycastResult(UnityEngine.EventSystems.RaycastResult&)
extern void XRRayInteractor_TryGetCurrentUIRaycastResult_m873AD7A618192FDDA0B7990DCE69FD3E0FD05390 (void);
// 0x000002B2 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentUIRaycastResult(UnityEngine.EventSystems.RaycastResult&,System.Int32&)
extern void XRRayInteractor_TryGetCurrentUIRaycastResult_m06AD58F70472B153B2ED72C6CE602EC8F80600F9 (void);
// 0x000002B3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentRaycast(System.Nullable`1<UnityEngine.RaycastHit>&,System.Int32&,System.Nullable`1<UnityEngine.EventSystems.RaycastResult>&,System.Int32&,System.Boolean&)
extern void XRRayInteractor_TryGetCurrentRaycast_mDF9BCCC480B67F1E423E33780E2D75B360368047 (void);
// 0x000002B4 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateBezierControlPoints()
extern void XRRayInteractor_UpdateBezierControlPoints_m4D3AEE19ACA147B78F66EFB00617A1D349821F64 (void);
// 0x000002B5 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleQuadraticBezierPoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleQuadraticBezierPoint_mF99E85DD1BCB3A1C656B394ED00A5B97CE28596F (void);
// 0x000002B6 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleCubicBezierPoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleCubicBezierPoint_m4FCC23E9AEE4290F8578DA757004C2E0FC66CE85 (void);
// 0x000002B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::ElevateQuadraticToCubicBezier(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRRayInteractor_ElevateQuadraticToCubicBezier_mE079E333BE4F24BDFF31B35A4B29DC00E42EEDC7 (void);
// 0x000002B8 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleProjectilePoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleProjectilePoint_mD5AAE68C6FAB7744A2D478B1E0076615A4BCFB6B (void);
// 0x000002B9 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CalculateProjectileParameters(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single&)
extern void XRRayInteractor_CalculateProjectileParameters_m89EA1DF264CF5F32ABD024AD091BFAD1CE975360 (void);
// 0x000002BA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryRead2DAxis(UnityEngine.InputSystem.InputAction,UnityEngine.Vector2&)
extern void XRRayInteractor_TryRead2DAxis_m6B5E0A91275EDAAE1EA3FAD7CBA14A15AF11B59E (void);
// 0x000002BB System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RotateAnchor(UnityEngine.Transform,System.Single)
extern void XRRayInteractor_RotateAnchor_m36FD2AC828192525A141F57BDB6337043B890231 (void);
// 0x000002BC System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TranslateAnchor(UnityEngine.Transform,UnityEngine.Transform,System.Single)
extern void XRRayInteractor_TranslateAnchor_m3604BE2C6F77AF6E10F24D4F35505974707C15F8 (void);
// 0x000002BD System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRRayInteractor_ProcessInteractor_m1881C82B2284A766690FFB544604FB963BFF4FDA (void);
// 0x000002BE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_isSelectActive()
extern void XRRayInteractor_get_isSelectActive_m19B054D7EF01D479910BC9B5A7A10BACBBCD1993 (void);
// 0x000002BF System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRRayInteractor_GetValidTargets_m3BD7A590E7F3B0E56921826F434A4D16F7EB946B (void);
// 0x000002C0 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateSamplePoints(System.Int32,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint>)
extern void XRRayInteractor_UpdateSamplePoints_mD0B51E5A4E0F451465CE3C163E234401C2DD697F (void);
// 0x000002C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateRaycastHits()
extern void XRRayInteractor_UpdateRaycastHits_mB5D7F591CE398668F8B4C9185DEA7B07A365AF32 (void);
// 0x000002C2 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CheckCollidersBetweenPoints(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_CheckCollidersBetweenPoints_mC36DA90F348192A355B6B0FDC0AF5F708DDA446B (void);
// 0x000002C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateUIHitIndex()
extern void XRRayInteractor_UpdateUIHitIndex_mF0D6C7E6DA1DB671DA3FE1194E780CEA55C76894 (void);
// 0x000002C4 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CreateBezierCurve(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint>,System.Int32,UnityEngine.Vector3[])
extern void XRRayInteractor_CreateBezierCurve_m5BAB7B604D8B01BD21E2AF25B0BD925345C29A15 (void);
// 0x000002C5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanHover_m2100A7C5A34B1620B00CF043AD63A62716967073 (void);
// 0x000002C6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanSelect_m0507A5DA43219DBB9AE8EFBBB010827EB50C4385 (void);
// 0x000002C7 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRRayInteractor_OnSelectEntering_mA511478A84FE506514E016415F293D55B93E58F9 (void);
// 0x000002C8 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRRayInteractor_OnSelectExiting_m77F4E955A8561D1F9107486538CF03EA2940CCD9 (void);
// 0x000002C9 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CaptureAttachTransform()
extern void XRRayInteractor_CaptureAttachTransform_mBDB77F465D20CAEEB60408756111AAE7BED02CC3 (void);
// 0x000002CA System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RestoreAttachTransform()
extern void XRRayInteractor_RestoreAttachTransform_mEB75D4539FC78187A17A14F009A5B89CAE77C16B (void);
// 0x000002CB System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SanitizeSampleFrequency(System.Int32)
extern void XRRayInteractor_SanitizeSampleFrequency_mC5778BD588E31A60C8DFA544B3998FAF73FDE9F8 (void);
// 0x000002CC System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::.ctor()
extern void XRRayInteractor__ctor_m7911B2AC53C4731D2B7BF9AFDFD9CB47D6A7CFC1 (void);
// 0x000002CD System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::.cctor()
extern void XRRayInteractor__cctor_m19E45D7A20D823826A10DD5419E06785B7CE35B8 (void);
// 0x000002CE System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_m35FC88786C4C31D0A05D7399C3E493F746399DB6 (void);
// 0x000002CF System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_m7354D9FDF5790BBA5DCE25BF09F3AA167A90C513 (void);
// 0x000002D0 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::get_position()
extern void SamplePoint_get_position_m936C42938CBE72F7E0E0D69CC7B3A7BDE7C844C7 (void);
// 0x000002D1 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::set_position(UnityEngine.Vector3)
extern void SamplePoint_set_position_m3E16630C4554106B58E1BF98C3EC58318EBBD763 (void);
// 0x000002D2 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::get_parameter()
extern void SamplePoint_get_parameter_m84322EF1929DC8BEC41F6756BC0D3AB7BF4E2052 (void);
// 0x000002D3 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::set_parameter(System.Single)
extern void SamplePoint_set_parameter_m4D939B740644F770649CCE42F187777F65FE805A (void);
// 0x000002D4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_showInteractableHoverMeshes()
extern void XRSocketInteractor_get_showInteractableHoverMeshes_mC102B4DCEC03266C0912F0B5FBB0F363B10C0ED8 (void);
// 0x000002D5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_showInteractableHoverMeshes(System.Boolean)
extern void XRSocketInteractor_set_showInteractableHoverMeshes_m66F111C8846F033EB6069BE51C821E855151D23B (void);
// 0x000002D6 UnityEngine.Material UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverMeshMaterial()
extern void XRSocketInteractor_get_interactableHoverMeshMaterial_m174CCD552AE76F1585F8E50DD5185A1189804B9F (void);
// 0x000002D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverMeshMaterial(UnityEngine.Material)
extern void XRSocketInteractor_set_interactableHoverMeshMaterial_mD4B5964256A3C6B97316FAD3591AF05B95766DB5 (void);
// 0x000002D8 UnityEngine.Material UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableCantHoverMeshMaterial()
extern void XRSocketInteractor_get_interactableCantHoverMeshMaterial_mAE89B2421D313EC9B9F5DBD3448F22EC815FC9DF (void);
// 0x000002D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableCantHoverMeshMaterial(UnityEngine.Material)
extern void XRSocketInteractor_set_interactableCantHoverMeshMaterial_m91F102A1757C50F47C569E01633BF66F76D399E1 (void);
// 0x000002DA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_socketActive()
extern void XRSocketInteractor_get_socketActive_mB2D54E1615E846F0AAA0BA249AE4517BF269410C (void);
// 0x000002DB System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_socketActive(System.Boolean)
extern void XRSocketInteractor_set_socketActive_m0E7EA6A077BE5C53FDDCECF36B00B7AEF9498055 (void);
// 0x000002DC System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverScale()
extern void XRSocketInteractor_get_interactableHoverScale_m52DFE5CB13BC3610F422690D67BBE94FDFFFB3C8 (void);
// 0x000002DD System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverScale(System.Single)
extern void XRSocketInteractor_set_interactableHoverScale_m0625AD9055F69C50CCBA05CF744FD74B5ACC7F8F (void);
// 0x000002DE System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_recycleDelayTime()
extern void XRSocketInteractor_get_recycleDelayTime_m44F5FA7B381CFCD260F68D2738FF83AA740ACACD (void);
// 0x000002DF System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_recycleDelayTime(System.Single)
extern void XRSocketInteractor_set_recycleDelayTime_m96B6AB49E939DE7BA69165261E2E62E49B20F2A6 (void);
// 0x000002E0 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::InteractableSortComparison(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_InteractableSortComparison_m2906766C3D9B2E0A2D95D010C508740772980598 (void);
// 0x000002E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::Awake()
extern void XRSocketInteractor_Awake_m61293C64F70812A938AE5908A047FFBB09C4A8AF (void);
// 0x000002E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerEnter_m4B8CBEE7042CBF5771AFD0D327B169B4F7E97771 (void);
// 0x000002E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerExit_m98A6B4B6222B440E2C71AB57765C0C5E25223E0B (void);
// 0x000002E4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CreateDefaultHoverMaterials()
extern void XRSocketInteractor_CreateDefaultHoverMaterials_m4C49192ADDD48632B7B274ABC075383732B7BB3A (void);
// 0x000002E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::SetMaterialFade(UnityEngine.Material,UnityEngine.Color)
extern void XRSocketInteractor_SetMaterialFade_m748E673634DAA0BFC13A303486231F0225CD8FB1 (void);
// 0x000002E6 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRSocketInteractor_OnHoverEntering_m6F7D0542179E6B06812F290B99B4311E098DC558 (void);
// 0x000002E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRSocketInteractor_OnHoverExiting_mF88506FD24ABC0D7856C4F66FB88F274AE44DD77 (void);
// 0x000002E8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRSocketInteractor_OnSelectExiting_m035C4A65225F67027400AA43B338BDD7F34C0146 (void);
// 0x000002E9 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRSocketInteractor_ProcessInteractor_m89C012C732872B9FE06335587C61D8A0230A1A3D (void);
// 0x000002EA UnityEngine.Matrix4x4 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetInteractableAttachMatrix(UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable,UnityEngine.MeshFilter,UnityEngine.Vector3)
extern void XRSocketInteractor_GetInteractableAttachMatrix_m0F69D87804267DAA495A1FB5DD01A86EA5184749 (void);
// 0x000002EB System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::DrawHoveredInteractables()
extern void XRSocketInteractor_DrawHoveredInteractables_m510B6F637780296099D682669E5A1EFFFFE1730D (void);
// 0x000002EC System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRSocketInteractor_GetValidTargets_m873238B1C7641D14F29D535C799D919EE2CF7DE2 (void);
// 0x000002ED System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isHoverActive()
extern void XRSocketInteractor_get_isHoverActive_mDB9CF3EB632D53438D507C3BC1FA7047257AE1D6 (void);
// 0x000002EE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isSelectActive()
extern void XRSocketInteractor_get_isSelectActive_m49267FD7875988D8653EBC13E1FE60E8F6272892 (void);
// 0x000002EF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_requireSelectExclusive()
extern void XRSocketInteractor_get_requireSelectExclusive_m6549FDB88D5983F00BC676FE7D1AA9CDC90DDFFC (void);
// 0x000002F0 System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType> UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRSocketInteractor_get_selectedInteractableMovementTypeOverride_m93A4A394F26E0984D2B3869CECD05C37A07124EE (void);
// 0x000002F1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanSelect_m76164FD5D8638544248150699D989D4C8FBA3C60 (void);
// 0x000002F2 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanHover_m3A4EEDAA8ECD7C2AD03E90D14F65599CADA9069A (void);
// 0x000002F3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::ShouldDrawHoverMesh(UnityEngine.MeshFilter,UnityEngine.Renderer,UnityEngine.Camera)
extern void XRSocketInteractor_ShouldDrawHoverMesh_m5E0ED4F8CC9B6ABAE6E652B935367C79B4FFC4D8 (void);
// 0x000002F4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRSocketInteractor_OnRegistered_mFDD3F105FA7FA03CD0704394A2D89C3C950E3EE0 (void);
// 0x000002F5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRSocketInteractor_OnUnregistered_m5BFE13D1762F6292EDD06401FC45C15FA2FD979A (void);
// 0x000002F6 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnInteractableUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRSocketInteractor_OnInteractableUnregistered_mBB058DE64F186A984FAEB1E55C9CB7B4761FAD1A (void);
// 0x000002F7 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::.ctor()
extern void XRSocketInteractor__ctor_mA9AECC24339310C8D28B7C86DA4DCA7C6730C3F2 (void);
// 0x000002F8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::.cctor()
extern void XRSocketInteractor__cctor_m5261C135610BEC8E34BA0B5DCD2936D23E8DE778 (void);
// 0x000002F9 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/ShaderPropertyLookup::.cctor()
extern void ShaderPropertyLookup__cctor_m56508837482E0DC1CA8286B0379C705DD05F9117 (void);
// 0x000002FA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent::.ctor()
extern void XRInteractableEvent__ctor_mE784C1ADE5999824CBDFB841D954E948F1944436 (void);
// 0x000002FB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent::.ctor()
extern void XRInteractorEvent__ctor_mD73327AEF9613FBE0E3997D81852A2B9E4ECF52C (void);
// 0x000002FC UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactor()
extern void BaseInteractionEventArgs_get_interactor_m2119370F273F0FF0FECA442EA5D9AB5665D36E44 (void);
// 0x000002FD System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseInteractionEventArgs_set_interactor_m80AEBD280C3115C9C3EA56FA160BD1C120A4F7E4 (void);
// 0x000002FE UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactable()
extern void BaseInteractionEventArgs_get_interactable_m4A4FCEF1E72EDCB1DF503141DEA939818FDF040C (void);
// 0x000002FF System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void BaseInteractionEventArgs_set_interactable_m90A6DC899E726BB45A3A57098734C280C7A482D0 (void);
// 0x00000300 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::.ctor()
extern void BaseInteractionEventArgs__ctor_m9D21E804D1DEB1407C51A1F8090FF9A0265962F5 (void);
// 0x00000301 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent::.ctor()
extern void HoverEnterEvent__ctor_mAFCC1AFC6B069966A16783E0F2E85040CA0EDDB7 (void);
// 0x00000302 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::.ctor()
extern void HoverEnterEventArgs__ctor_mB9443E41C4DE462C6488746EE7FFFC090A9C8193 (void);
// 0x00000303 System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEvent::.ctor()
extern void HoverExitEvent__ctor_mD0B6D04D4042B6E461773D290E52D20E51674424 (void);
// 0x00000304 System.Boolean UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::get_isCanceled()
extern void HoverExitEventArgs_get_isCanceled_mF796A4E1A7EB0B69D6F0C5B0D713E448324EB86C (void);
// 0x00000305 System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::set_isCanceled(System.Boolean)
extern void HoverExitEventArgs_set_isCanceled_mDEF194AF3E45036631E8E732C1141CF638511439 (void);
// 0x00000306 System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::.ctor()
extern void HoverExitEventArgs__ctor_m9FBA318245CEC6F630BAF3FAB3D80095D2E6F722 (void);
// 0x00000307 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent::.ctor()
extern void SelectEnterEvent__ctor_m959093821735EF8DDFFAA1F6C94100F7F056EE8B (void);
// 0x00000308 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::.ctor()
extern void SelectEnterEventArgs__ctor_m9BA655B9E94E47CC651E7987A8D660F86323A7B4 (void);
// 0x00000309 System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEvent::.ctor()
extern void SelectExitEvent__ctor_mD8B97D564D22BA51E86C2609FB999E0739A1D992 (void);
// 0x0000030A System.Boolean UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::get_isCanceled()
extern void SelectExitEventArgs_get_isCanceled_m593A728ECD659A477152A4B823EC709070063ADB (void);
// 0x0000030B System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::set_isCanceled(System.Boolean)
extern void SelectExitEventArgs_set_isCanceled_m11626375CC34F372980C171602C7FBAF68737EE7 (void);
// 0x0000030C System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::.ctor()
extern void SelectExitEventArgs__ctor_mCFB1C217E20C4F49D80532A2CA92D2621E1F8932 (void);
// 0x0000030D System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEvent::.ctor()
extern void ActivateEvent__ctor_m1EA8D06FBF79DC5435F769D40942C5C85B2EE2BB (void);
// 0x0000030E System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::.ctor()
extern void ActivateEventArgs__ctor_m8869B99604F99AD2336CC6F5BC30DC9F66AB6B98 (void);
// 0x0000030F System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEvent::.ctor()
extern void DeactivateEvent__ctor_m510A01F9AC878145DB26A3777E8AB3EFC8301A5C (void);
// 0x00000310 System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::.ctor()
extern void DeactivateEventArgs__ctor_mDDA4CC88A23B3D39CF8BBD68BB2AF3EB51FF4AC7 (void);
// 0x00000311 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::get_manager()
extern void BaseRegistrationEventArgs_get_manager_m0BE09F10BCBCEBAC776E08F26D4241BC00C13255 (void);
// 0x00000312 System.Void UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void BaseRegistrationEventArgs_set_manager_m40D70ACA0BAAE2A1E7AC9950919F2CCE0BEE946D (void);
// 0x00000313 System.Void UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::.ctor()
extern void BaseRegistrationEventArgs__ctor_m64F07C2047D7BE3DDD5B517FFEC0D5837188E874 (void);
// 0x00000314 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::get_interactor()
extern void InteractorRegisteredEventArgs_get_interactor_m7672E6732DE1B972682365221985CFD026E2CD09 (void);
// 0x00000315 System.Void UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void InteractorRegisteredEventArgs_set_interactor_m18E824F81898AB4162E2AAC4CD6AF97719F3DD33 (void);
// 0x00000316 System.Void UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::.ctor()
extern void InteractorRegisteredEventArgs__ctor_m449479C1AB4804EE101B9D0FA3E620B9079E8CB2 (void);
// 0x00000317 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::get_interactable()
extern void InteractableRegisteredEventArgs_get_interactable_mD7C8057ACBBA5F72AD29B4F4F8F2F5C6563AF6F3 (void);
// 0x00000318 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void InteractableRegisteredEventArgs_set_interactable_m478BBE07FB963EFACFFF23861746783CE14DE5A9 (void);
// 0x00000319 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::.ctor()
extern void InteractableRegisteredEventArgs__ctor_m59D059C054EF27AD86321B656D34D0E4CFF00B62 (void);
// 0x0000031A UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::get_interactor()
extern void InteractorUnregisteredEventArgs_get_interactor_mECA1820CF23F4202E12DEB5DD581D942C3ECF42D (void);
// 0x0000031B System.Void UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void InteractorUnregisteredEventArgs_set_interactor_mEA454964958CA35141EA95E67FCFC0D6C458C17D (void);
// 0x0000031C System.Void UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::.ctor()
extern void InteractorUnregisteredEventArgs__ctor_mF10FC0040D2BBE5C5DE20E2360A2A2A2FA8E6498 (void);
// 0x0000031D UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::get_interactable()
extern void InteractableUnregisteredEventArgs_get_interactable_m3EF93A750D56C53A1BF9D57F8E1ABE1001CC7393 (void);
// 0x0000031E System.Void UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void InteractableUnregisteredEventArgs_set_interactable_mA1A7F69950F7BCD6AD8D25DF465BE3D137D59446 (void);
// 0x0000031F System.Void UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::.ctor()
extern void InteractableUnregisteredEventArgs__ctor_m99E54FFE0A2814C9CB0E608BCB06F16EC31DDAA8 (void);
// 0x00000320 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactorRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRInteractionManager_add_interactorRegistered_m028E5BD40AA93199943D55D64BD33857084F1A48 (void);
// 0x00000321 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactorRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRInteractionManager_remove_interactorRegistered_m9992F01E9C648A44B2986261DB5F8B0624C88593 (void);
// 0x00000322 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactorUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRInteractionManager_add_interactorUnregistered_m9BD30E6767B10E7482B2FE582A0CA246B1C86DAD (void);
// 0x00000323 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactorUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRInteractionManager_remove_interactorUnregistered_m31CD1EFC13322B2C6D866C9B21BF4BA002FFED22 (void);
// 0x00000324 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactableRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRInteractionManager_add_interactableRegistered_m46FAA4E08BCAA5777F070A85EA6A9D90B2545A60 (void);
// 0x00000325 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactableRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRInteractionManager_remove_interactableRegistered_m8573CC9BD4B53197061E6C236378EA9D2143281A (void);
// 0x00000326 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactableUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRInteractionManager_add_interactableUnregistered_m5976273A58891E10B184536C4856B4A2A1F25CBE (void);
// 0x00000327 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactableUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRInteractionManager_remove_interactableUnregistered_mD066EA86F5BA0F0435E18A841705836E7AD7D038 (void);
// 0x00000328 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::get_interactors()
extern void XRInteractionManager_get_interactors_mD18E7D1D0F8E0EB35762B8994F93053793487807 (void);
// 0x00000329 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::get_interactables()
extern void XRInteractionManager_get_interactables_m11B804403DE9F2BB1154376AEBBCDC802B4891F5 (void);
// 0x0000032A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnEnable()
extern void XRInteractionManager_OnEnable_m9FDECF903D46AE6BF074875277F02B2F9E58E658 (void);
// 0x0000032B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnDisable()
extern void XRInteractionManager_OnDisable_m8EDF8DD4141E19BF57A7E6D8E2F9D476C64555EC (void);
// 0x0000032C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::Update()
extern void XRInteractionManager_Update_mC28274BF7E3C03C69E45A05524872FB627A354D4 (void);
// 0x0000032D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::LateUpdate()
extern void XRInteractionManager_LateUpdate_m04D4A01C8F027B6AFA66A561E8909A0C10D0B51E (void);
// 0x0000032E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::FixedUpdate()
extern void XRInteractionManager_FixedUpdate_mB1DA91D4122F45254E3051F8368706FBC394E20F (void);
// 0x0000032F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnBeforeRender()
extern void XRInteractionManager_OnBeforeRender_m5A5C4B4DD7AABB3F8400AD34CA74725E5AD09A5F (void);
// 0x00000330 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractors(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRInteractionManager_ProcessInteractors_m6CDE192CAA3D672EE4D8BCC8DD4D0595C9D0E185 (void);
// 0x00000331 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractables(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRInteractionManager_ProcessInteractables_m53573237519A0688BCBB243FB537E7DD1E9B17DD (void);
// 0x00000332 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_RegisterInteractor_m57441A810CF20A9D88C3E283537E791649AA4F1B (void);
// 0x00000333 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_UnregisterInteractor_m9AE293B5FE479C9860D1AC86297E3B59A3234D5D (void);
// 0x00000334 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_RegisterInteractable_mD0342CCA15534CF70643BE99563B3ADD44D5805E (void);
// 0x00000335 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_UnregisterInteractable_m49277C2EC6634C9BBAD397696C07DD2E4BCFAD03 (void);
// 0x00000336 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractors(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor>)
extern void XRInteractionManager_GetRegisteredInteractors_m0D379B8D37C8ECA19C7B81D7CF4F065DA7FC19DD (void);
// 0x00000337 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractables(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_GetRegisteredInteractables_m91697286C20DCD7F607F2F0A30EA44E3B4A11415 (void);
// 0x00000338 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::TryGetInteractableForCollider(UnityEngine.Collider)
extern void XRInteractionManager_TryGetInteractableForCollider_m562D8877127749E4F7AA046FF66D26C43637B453 (void);
// 0x00000339 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetInteractableForCollider(UnityEngine.Collider)
extern void XRInteractionManager_GetInteractableForCollider_m5BECE120C446F3793D2610A676F53E64B8BB81A9 (void);
// 0x0000033A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetColliderToInteractableMap(System.Collections.Generic.Dictionary`2<UnityEngine.Collider,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>&)
extern void XRInteractionManager_GetColliderToInteractableMap_m62EC335B889430B8BF99B61D818C05977E9A64DC (void);
// 0x0000033B System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_GetValidTargets_m4622E94A65A4B738B58B65448CAE7A9405E6B2DE (void);
// 0x0000033C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ForceSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_ForceSelect_m82C4EA94E6CCFDDC3C666E439529E1BD50C19501 (void);
// 0x0000033D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_ClearInteractorSelection_mA6F6EA4602A14A2978EEDA285BEADE008A6B9318 (void);
// 0x0000033E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_CancelInteractorSelection_m24C3DD25878F6D9072FA8A31891197CC1739AC7A (void);
// 0x0000033F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_CancelInteractableSelection_m47BA2937242C8195F48A736C7C17E3A4024CAF3A (void);
// 0x00000340 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_ClearInteractorHover_m9C1469AD953EB7B3F621C5562033F5DD67297D94 (void);
// 0x00000341 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_CancelInteractorHover_m57431CBBB17D68421738CFAA6203DC4F64CFE74B (void);
// 0x00000342 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_CancelInteractableHover_mDEE3701E6C7B470F077F6682CF2565B742D2E93A (void);
// 0x00000343 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectEnter_m07A0B1CE6080F54C1309174B68E8A686A416B51C (void);
// 0x00000344 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectExit_m7BE6481CA3A08C4C2CAB3EE19C00D14F0A27EBB4 (void);
// 0x00000345 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectCancel(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectCancel_m11736AC32BF92590098B18E0CB2D8816101762BB (void);
// 0x00000346 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverEnter_mE0D0F6540131E548B123AC5626DE2338497904CD (void);
// 0x00000347 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverExit_m340E30FB80910036EB87DADAED8679B894E5BDBA (void);
// 0x00000348 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverCancel(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverCancel_m6668BC4C4AA510316234AA9FA912F3B260FEE0C7 (void);
// 0x00000349 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractionManager_SelectEnter_mF37CD6E998946ACA8F6033842E404ACB611E9B7B (void);
// 0x0000034A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRInteractionManager_SelectExit_mE89596A7DFBFB1D119676A7313611B5AB0CB29DA (void);
// 0x0000034B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRInteractionManager_HoverEnter_m2951929D0C14E387477E0BCC4777287DD89BAEC2 (void);
// 0x0000034C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRInteractionManager_HoverExit_mC3D977507246F5F59D64994C3BF29B4DADD481BF (void);
// 0x0000034D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorSelectValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorSelectValidTargets_m092D8536E08C5E5332CBE5303135E863EA81CC5D (void);
// 0x0000034E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorHoverValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorHoverValidTargets_mDF1F4BD6AF98AD76BBDF482D7576ED103DC32F8A (void);
// 0x0000034F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::.ctor()
extern void XRInteractionManager__ctor_mA88BB165F8110638607F2CB82CCF8F5D0203004F (void);
// 0x00000350 UnityEngine.XR.Interaction.Toolkit.LocomotionProvider UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_locomotionProvider()
extern void CharacterControllerDriver_get_locomotionProvider_mD201F16F81932BF45B82607E697FD6883F583D66 (void);
// 0x00000351 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_locomotionProvider(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_set_locomotionProvider_mCD84E7CE3B73224EE8B70D9C866E32830303821A (void);
// 0x00000352 System.Single UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_minHeight()
extern void CharacterControllerDriver_get_minHeight_m953D2494ED979FB2261B6B8D81FA47A30E097D0E (void);
// 0x00000353 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_minHeight(System.Single)
extern void CharacterControllerDriver_set_minHeight_mBA697B5D138AB4A323E80FFAEEA3288E1BC31366 (void);
// 0x00000354 System.Single UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_maxHeight()
extern void CharacterControllerDriver_get_maxHeight_m918C15CEACFCF200494B97EC1A6FB812DBAC54A7 (void);
// 0x00000355 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_maxHeight(System.Single)
extern void CharacterControllerDriver_set_maxHeight_mB9045529749D310B4AAA4121B930A7E991747109 (void);
// 0x00000356 UnityEngine.XR.Interaction.Toolkit.XRRig UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_xrRig()
extern void CharacterControllerDriver_get_xrRig_m24AFC40E3B05BD7BB70B1D704E26DABCA9E43455 (void);
// 0x00000357 UnityEngine.CharacterController UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_characterController()
extern void CharacterControllerDriver_get_characterController_mA8853F27086BB5E59DC581793137C903995EE9E5 (void);
// 0x00000358 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Awake()
extern void CharacterControllerDriver_Awake_m59F3E334507F8BDCF23A087F84E8B96768237E91 (void);
// 0x00000359 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnEnable()
extern void CharacterControllerDriver_OnEnable_m7B5E66AD1FE4FBBBE3D165D59C88036343DB9A39 (void);
// 0x0000035A System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnDisable()
extern void CharacterControllerDriver_OnDisable_m0D2A94CE7E22F81FD1715C47FF39C61606D72932 (void);
// 0x0000035B System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Start()
extern void CharacterControllerDriver_Start_m2B6CB5A0A787F657D8875C384B6298AAC36DC67D (void);
// 0x0000035C System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::UpdateCharacterController()
extern void CharacterControllerDriver_UpdateCharacterController_m1733EE9F12247CFE7F9C2204E77B2DA43F375350 (void);
// 0x0000035D System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Subscribe(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_Subscribe_mB23C7A0B5569EA3EFA55D541F7F6F647B1DA0C40 (void);
// 0x0000035E System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Unsubscribe(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_Unsubscribe_m4DA59BAE83365BF6D3F0EB9AC01E667F0702B4E9 (void);
// 0x0000035F System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::SetupCharacterController()
extern void CharacterControllerDriver_SetupCharacterController_m5EB4C8731A91E72961BB2B3841FFC3E0990EDC90 (void);
// 0x00000360 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnBeginLocomotion(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void CharacterControllerDriver_OnBeginLocomotion_mCB4A9583BC6AF9C7688C03B2CC474FB760B02FBD (void);
// 0x00000361 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnEndLocomotion(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void CharacterControllerDriver_OnEndLocomotion_m162F58337E942F72AEF998F68631E2AE0D849A75 (void);
// 0x00000362 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::.ctor()
extern void CharacterControllerDriver__ctor_m45A42CC13D2A337297B13FA6EC0733479B481D0C (void);
// 0x00000363 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::get_leftHandMoveAction()
extern void ActionBasedContinuousMoveProvider_get_leftHandMoveAction_m585B2C55F246B2A87A5ACCC0BB2C5EEC915E7BFB (void);
// 0x00000364 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::set_leftHandMoveAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_set_leftHandMoveAction_mDB3E0196C9ADAAE083233989124B1FA603A35072 (void);
// 0x00000365 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::get_rightHandMoveAction()
extern void ActionBasedContinuousMoveProvider_get_rightHandMoveAction_mF59A3C167F1BDA9402409B3B1135F2A9E32FB88C (void);
// 0x00000366 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::set_rightHandMoveAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_set_rightHandMoveAction_m70FDF807430951C58B446DBB59B362757A169921 (void);
// 0x00000367 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::OnEnable()
extern void ActionBasedContinuousMoveProvider_OnEnable_mE9CE0DA8C13777B516CA4FB998F6496BBF6B3C46 (void);
// 0x00000368 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::OnDisable()
extern void ActionBasedContinuousMoveProvider_OnDisable_m9E322025AFFB3379B3F5B5FC4BC2DFC106D4BA78 (void);
// 0x00000369 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::ReadInput()
extern void ActionBasedContinuousMoveProvider_ReadInput_mC08E030C91C46C7D1FDE15BC940388D1ECCF070F (void);
// 0x0000036A System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_SetInputActionProperty_mF3BA0FD3068AC13E17C7E6BEF2745C867010166D (void);
// 0x0000036B System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::.ctor()
extern void ActionBasedContinuousMoveProvider__ctor_m38CF25142F1C48B3EADD8239E98859588C046D45 (void);
// 0x0000036C UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::get_leftHandTurnAction()
extern void ActionBasedContinuousTurnProvider_get_leftHandTurnAction_mECA2124789B7032A0EAA63DB5FE7AEF3CC3E2CC4 (void);
// 0x0000036D System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::set_leftHandTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_set_leftHandTurnAction_m13ACF7DCCD5D6D84F09D7DCE0C0203C5430531A0 (void);
// 0x0000036E UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::get_rightHandTurnAction()
extern void ActionBasedContinuousTurnProvider_get_rightHandTurnAction_m0EEF7F6E48EADFB7F60659B62EF49E6044E12858 (void);
// 0x0000036F System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::set_rightHandTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_set_rightHandTurnAction_mFA90EBD966286D9F44256A23EE6847F5B19415A2 (void);
// 0x00000370 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::OnEnable()
extern void ActionBasedContinuousTurnProvider_OnEnable_m9156DAF675AFD3D509687D43A665C4B719FE6CD7 (void);
// 0x00000371 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::OnDisable()
extern void ActionBasedContinuousTurnProvider_OnDisable_mB78334F6C42D60AF496D3106361C38594EFC6985 (void);
// 0x00000372 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::ReadInput()
extern void ActionBasedContinuousTurnProvider_ReadInput_mDA82F08C605330A6AEEB19FE64FEF5DC3D26225A (void);
// 0x00000373 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_SetInputActionProperty_m6AAF8E97E07CD78BCABD760F9192CC59A9A51B30 (void);
// 0x00000374 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::.ctor()
extern void ActionBasedContinuousTurnProvider__ctor_m0C6ED35454030ADE9B1DB13C414D24BE13ECF8F7 (void);
// 0x00000375 System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_moveSpeed()
extern void ContinuousMoveProviderBase_get_moveSpeed_mB35DBBCA51BA43717E4FDDF0DBF244AC9F16F0FB (void);
// 0x00000376 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_moveSpeed(System.Single)
extern void ContinuousMoveProviderBase_set_moveSpeed_m6857F6935CC04747A26BC3212208B45493A44787 (void);
// 0x00000377 System.Boolean UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_enableStrafe()
extern void ContinuousMoveProviderBase_get_enableStrafe_m7F0C7FB5279860E11B2E64B50049EBFD19EDBFC0 (void);
// 0x00000378 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_enableStrafe(System.Boolean)
extern void ContinuousMoveProviderBase_set_enableStrafe_m370B15DF41B848E9B913A90F3AF82CDA5C9B408D (void);
// 0x00000379 System.Boolean UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_useGravity()
extern void ContinuousMoveProviderBase_get_useGravity_m33A2948B0CDC4385B0A65032AFFFA17AD1F9DE65 (void);
// 0x0000037A System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_useGravity(System.Boolean)
extern void ContinuousMoveProviderBase_set_useGravity_mEE6AB574B9DD4F122FF36B00CF00F33AEACFD210 (void);
// 0x0000037B UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase/GravityApplicationMode UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_gravityApplicationMode()
extern void ContinuousMoveProviderBase_get_gravityApplicationMode_m3D5074A6746EBDA71D14FB7965E92F2D84C265EF (void);
// 0x0000037C System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_gravityApplicationMode(UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase/GravityApplicationMode)
extern void ContinuousMoveProviderBase_set_gravityApplicationMode_m556D5AEB0FA0D715EE3ED26A4F92B9A900C0A9F1 (void);
// 0x0000037D UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_forwardSource()
extern void ContinuousMoveProviderBase_get_forwardSource_mBCBDBDED98D85729417FE422E11E1CC751152F1B (void);
// 0x0000037E System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_forwardSource(UnityEngine.Transform)
extern void ContinuousMoveProviderBase_set_forwardSource_mFC654F04903F2517D5AF32028B2216DEFF341BEB (void);
// 0x0000037F System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::Update()
extern void ContinuousMoveProviderBase_Update_m0898231FFDD27E5A34AAFD66365D75B9014B5482 (void);
// 0x00000380 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::ReadInput()
// 0x00000381 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::ComputeDesiredMove(UnityEngine.Vector2)
extern void ContinuousMoveProviderBase_ComputeDesiredMove_m1ED66E077EE95558BB97BE6FC237EA3B33039747 (void);
// 0x00000382 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::MoveRig(UnityEngine.Vector3)
extern void ContinuousMoveProviderBase_MoveRig_m479CFA45F3A2A7E50660EBC26B9332FD61DEA8E1 (void);
// 0x00000383 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::FindCharacterController()
extern void ContinuousMoveProviderBase_FindCharacterController_m112987766A2FDA2B3F3DEE777A3C08C232B2541F (void);
// 0x00000384 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::.ctor()
extern void ContinuousMoveProviderBase__ctor_m644DF2183D256C093F77CA7EC1B6AD1B679D2C90 (void);
// 0x00000385 System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::get_turnSpeed()
extern void ContinuousTurnProviderBase_get_turnSpeed_mF8C6211778DC7D5A89421CF9FED06D66D695C9A6 (void);
// 0x00000386 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::set_turnSpeed(System.Single)
extern void ContinuousTurnProviderBase_set_turnSpeed_m3FF87994730F28EB79AB1B9831B3FB9BFAF0D378 (void);
// 0x00000387 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::Update()
extern void ContinuousTurnProviderBase_Update_m3A0E96663B17515699224E36BFCFDE2BE454217B (void);
// 0x00000388 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::ReadInput()
// 0x00000389 System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::GetTurnAmount(UnityEngine.Vector2)
extern void ContinuousTurnProviderBase_GetTurnAmount_m3FDECC773878364A1350F781C59093010C7C6E64 (void);
// 0x0000038A System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::TurnRig(System.Single)
extern void ContinuousTurnProviderBase_TurnRig_m4F3D9FB0282AE8F658E9E1659112BAC2287A5C9D (void);
// 0x0000038B System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::.ctor()
extern void ContinuousTurnProviderBase__ctor_m1C0D394910C854391E522890A21BABEF063116AC (void);
// 0x0000038C UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_inputBinding()
extern void DeviceBasedContinuousMoveProvider_get_inputBinding_mF4B177D18A5A392F134F5813FA6CCA66D4887082 (void);
// 0x0000038D System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_inputBinding(UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider/InputAxes)
extern void DeviceBasedContinuousMoveProvider_set_inputBinding_m6070E8A8887BAB81CFBAA604F5E81800DFD7DC30 (void);
// 0x0000038E System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_controllers()
extern void DeviceBasedContinuousMoveProvider_get_controllers_mE1238E31FD47FA9878DC32F11975D32C4D189A76 (void);
// 0x0000038F System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedContinuousMoveProvider_set_controllers_m84B24F7B0EFFDFDF803778FFDD7F24AD95B899A7 (void);
// 0x00000390 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_deadzoneMin()
extern void DeviceBasedContinuousMoveProvider_get_deadzoneMin_mAF456993DCAB6F76D049CDF192000BA379A90138 (void);
// 0x00000391 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_deadzoneMin(System.Single)
extern void DeviceBasedContinuousMoveProvider_set_deadzoneMin_mB07962A31B0B1EB27824B549A3D345B4183141BA (void);
// 0x00000392 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_deadzoneMax()
extern void DeviceBasedContinuousMoveProvider_get_deadzoneMax_mC7506B5B6918A3164473C3EB35679AF270A78282 (void);
// 0x00000393 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_deadzoneMax(System.Single)
extern void DeviceBasedContinuousMoveProvider_set_deadzoneMax_mD7AA56BFE8C174E0D0C0F1E30D1E1F57748157BE (void);
// 0x00000394 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::ReadInput()
extern void DeviceBasedContinuousMoveProvider_ReadInput_m6201C30338A93716EF402F7DDB417A102A779359 (void);
// 0x00000395 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::GetDeadzoneAdjustedValue(UnityEngine.Vector2)
extern void DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_mC12A8A7C6896ECBF4FBBBC6736086A84C38D9673 (void);
// 0x00000396 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::GetDeadzoneAdjustedValue(System.Single)
extern void DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m3CB229A0AB4C5A9A3A47626A5562C6913ED417D6 (void);
// 0x00000397 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::.ctor()
extern void DeviceBasedContinuousMoveProvider__ctor_m18DEBAE9A2C792802B6396ACD664679ADE30DBD0 (void);
// 0x00000398 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::.cctor()
extern void DeviceBasedContinuousMoveProvider__cctor_m694EF72DDDA6CC1D6C27ED50EE15CED52816B709 (void);
// 0x00000399 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_inputBinding()
extern void DeviceBasedContinuousTurnProvider_get_inputBinding_mB6E7C3FE7B3F4C1C425405ED6009A688E4B3C04D (void);
// 0x0000039A System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_inputBinding(UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider/InputAxes)
extern void DeviceBasedContinuousTurnProvider_set_inputBinding_m5F67E5062D00550ABD82576614F96C484A9E371F (void);
// 0x0000039B System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_controllers()
extern void DeviceBasedContinuousTurnProvider_get_controllers_mAA9E9FAF9573955E8EE2EABEC1B6BD078B37CC12 (void);
// 0x0000039C System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedContinuousTurnProvider_set_controllers_m11F44482007F5F08730F3CF077FFF3A1FCF6CDA3 (void);
// 0x0000039D System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_deadzoneMin()
extern void DeviceBasedContinuousTurnProvider_get_deadzoneMin_mEEEB887C0736DE3CFC0AEB9EC696D159871840D1 (void);
// 0x0000039E System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_deadzoneMin(System.Single)
extern void DeviceBasedContinuousTurnProvider_set_deadzoneMin_m2EF1826AAEFE70723D0B46E15674AB88A26D982A (void);
// 0x0000039F System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_deadzoneMax()
extern void DeviceBasedContinuousTurnProvider_get_deadzoneMax_mCBA4970CAF6554084E23646F3DED00D4068B9427 (void);
// 0x000003A0 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_deadzoneMax(System.Single)
extern void DeviceBasedContinuousTurnProvider_set_deadzoneMax_m9D891997C8E208EF2904CD7884777D6F8A4921C3 (void);
// 0x000003A1 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::ReadInput()
extern void DeviceBasedContinuousTurnProvider_ReadInput_mBACBE07C39754C1731FC3B065A0399305518AD34 (void);
// 0x000003A2 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::GetDeadzoneAdjustedValue(UnityEngine.Vector2)
extern void DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m0E79D4BB0E4C55459053ED25742AA0DFC203EB5D (void);
// 0x000003A3 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::GetDeadzoneAdjustedValue(System.Single)
extern void DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m1C40C21EB01A3959BABDCDDA7CA438994BDEEDDC (void);
// 0x000003A4 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::.ctor()
extern void DeviceBasedContinuousTurnProvider__ctor_m2116020C2A06352F23EBB29878039A8E7F56D2C0 (void);
// 0x000003A5 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::.cctor()
extern void DeviceBasedContinuousTurnProvider__cctor_mA0DB9341DA18953A6C6370C6B4625966445AAE3E (void);
// 0x000003A6 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_startLocomotion_mF8FF9FC82F52A023063192BE0CB0100971035521 (void);
// 0x000003A7 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_startLocomotion_m7880E20F2705D62783AB798C485CE6A6E2CB985D (void);
// 0x000003A8 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_beginLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_beginLocomotion_mB1DCE91B13F70386CE4678E9B1215E2863F0007E (void);
// 0x000003A9 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_beginLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_beginLocomotion_m707A5CA2BD73D33C412C60D5E33523A6ACE4E563 (void);
// 0x000003AA System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_endLocomotion_mB28CF916E102064979AE16EA147986F16BD30E5E (void);
// 0x000003AB System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_endLocomotion_m42DAB46E1B5303FCCE8116B8F3048544A71132A8 (void);
// 0x000003AC UnityEngine.XR.Interaction.Toolkit.LocomotionSystem UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::get_system()
extern void LocomotionProvider_get_system_m03FA085476B700DA9942A3B6DF3B8D3C2D7D36F1 (void);
// 0x000003AD System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::set_system(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void LocomotionProvider_set_system_m0E7D1C4EB5D52947B2F9531618F9AA11422A6B5A (void);
// 0x000003AE System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::Awake()
extern void LocomotionProvider_Awake_m8C8152BA75A1C6E84378FDA7EFD28B527A81F0A5 (void);
// 0x000003AF System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::CanBeginLocomotion()
extern void LocomotionProvider_CanBeginLocomotion_m8552DB4BE5E1B705738A07340929D7EDE1FD1206 (void);
// 0x000003B0 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::BeginLocomotion()
extern void LocomotionProvider_BeginLocomotion_m74F554EA479426FF97F8A736BB0EB80CD6740624 (void);
// 0x000003B1 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::EndLocomotion()
extern void LocomotionProvider_EndLocomotion_m9A60A3BF116B5CE6B5CDD56F6FE23121C42A9E7F (void);
// 0x000003B2 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::.ctor()
extern void LocomotionProvider__ctor_m0062E45F994311909006A8B0BB3216CC4AA7CE3D (void);
// 0x000003B3 System.Single UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_timeout()
extern void LocomotionSystem_get_timeout_m492A9A01A654E00B83E5D26778F61138FB970C0F (void);
// 0x000003B4 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_timeout(System.Single)
extern void LocomotionSystem_set_timeout_m7C4398A26F09DFFBFA16AC61501CAF13C8F868C4 (void);
// 0x000003B5 UnityEngine.XR.Interaction.Toolkit.XRRig UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_xrRig()
extern void LocomotionSystem_get_xrRig_m26984B689162D0BF017A639B8E5B0FF64FCA66AD (void);
// 0x000003B6 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_xrRig(UnityEngine.XR.Interaction.Toolkit.XRRig)
extern void LocomotionSystem_set_xrRig_mEC499C8C39ECA137808C0CA5F1706B4EEDD5B5D4 (void);
// 0x000003B7 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_busy()
extern void LocomotionSystem_get_busy_mEC4146B85EEF5A9EEAC21E1ABC42CEA4D6294774 (void);
// 0x000003B8 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_Busy()
extern void LocomotionSystem_get_Busy_mE672634BA551C4C394815E29CB422A28B5465B43 (void);
// 0x000003B9 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Awake()
extern void LocomotionSystem_Awake_m7947F6DF55DB2CE711E1358DB083F2B3E4002FA7 (void);
// 0x000003BA System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Update()
extern void LocomotionSystem_Update_m6926179639E59CFE420DD791AF5F107FC42802DC (void);
// 0x000003BB UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::RequestExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_RequestExclusiveOperation_m76BBDC06D91F6601CC47079A4679CF433314DEEE (void);
// 0x000003BC System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::ResetExclusivity()
extern void LocomotionSystem_ResetExclusivity_m077697D69683C5591955EB726F98A2D9E8771E60 (void);
// 0x000003BD UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::FinishExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_FinishExclusiveOperation_mA26B93855591AD5EA05A1EE74E4FE151544F1964 (void);
// 0x000003BE System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::.ctor()
extern void LocomotionSystem__ctor_m7517AD2B471AA7C1949BB4D3DAEE33A749EEE96C (void);
// 0x000003BF UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::get_leftHandSnapTurnAction()
extern void ActionBasedSnapTurnProvider_get_leftHandSnapTurnAction_m992D03F984386EB16DAA0AFCA10C663EBE615B3A (void);
// 0x000003C0 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::set_leftHandSnapTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_set_leftHandSnapTurnAction_m096518E81762922A166F371D48E113859F7DFFCC (void);
// 0x000003C1 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::get_rightHandSnapTurnAction()
extern void ActionBasedSnapTurnProvider_get_rightHandSnapTurnAction_mD494FA951DE44A3580811E2578628344E7923CBD (void);
// 0x000003C2 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::set_rightHandSnapTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_set_rightHandSnapTurnAction_m3BFE9318BF525AE207BCF71DEA8DC549FF9F697B (void);
// 0x000003C3 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::OnEnable()
extern void ActionBasedSnapTurnProvider_OnEnable_m2236EEAA3DCEE8017A3D84DDE3E2A40857B236B2 (void);
// 0x000003C4 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::OnDisable()
extern void ActionBasedSnapTurnProvider_OnDisable_mEFBE4A56969A3BD4A7C668F6C3ACC83C46031E12 (void);
// 0x000003C5 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::ReadInput()
extern void ActionBasedSnapTurnProvider_ReadInput_mF8DB851EBB2EBD051CE15CCC75B8EC8E64FE4795 (void);
// 0x000003C6 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_SetInputActionProperty_m464E172E61770640FE2088274B9FC9087911890D (void);
// 0x000003C7 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::.ctor()
extern void ActionBasedSnapTurnProvider__ctor_m52903AE39ADC9E84C44020BCD8CFCA79AD5E1406 (void);
// 0x000003C8 UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_turnUsage()
extern void DeviceBasedSnapTurnProvider_get_turnUsage_m40896A6B2D2B46DD6B2B8D3208CD7E4C619BA708 (void);
// 0x000003C9 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_turnUsage(UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider/InputAxes)
extern void DeviceBasedSnapTurnProvider_set_turnUsage_mF067C956C887589A96C864A3948A9C9784DC8134 (void);
// 0x000003CA System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_controllers()
extern void DeviceBasedSnapTurnProvider_get_controllers_m7B042725877E406FF7BEF73F585800CBE1692900 (void);
// 0x000003CB System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedSnapTurnProvider_set_controllers_mCB6BA3079122509351693F9996888CC759C4676F (void);
// 0x000003CC System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_deadZone()
extern void DeviceBasedSnapTurnProvider_get_deadZone_mD16CDEB507AE4C08341A54F73DC45D1B1054AD60 (void);
// 0x000003CD System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_deadZone(System.Single)
extern void DeviceBasedSnapTurnProvider_set_deadZone_mF2A0C6F44A9343C0FFEBDEA841FCC003A03AB0A4 (void);
// 0x000003CE UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::ReadInput()
extern void DeviceBasedSnapTurnProvider_ReadInput_mCB5024ABD78C7D8124ADCEFAEE9C35EF07602EA5 (void);
// 0x000003CF System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::.ctor()
extern void DeviceBasedSnapTurnProvider__ctor_mC138D69CFAB5D407406ED459D97524BB5FA97E03 (void);
// 0x000003D0 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::.cctor()
extern void DeviceBasedSnapTurnProvider__cctor_mA1BFD4715D742BD90973746757A36D75856A3244 (void);
// 0x000003D1 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_turnAmount()
extern void SnapTurnProviderBase_get_turnAmount_mB934A9515106A451B2AFE216E8A6440B34F9995A (void);
// 0x000003D2 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_turnAmount(System.Single)
extern void SnapTurnProviderBase_set_turnAmount_m3AE35E140A4A064C5444BD6DCBDC3E6F4A17F6C7 (void);
// 0x000003D3 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_debounceTime()
extern void SnapTurnProviderBase_get_debounceTime_m58EF18A3C288BA99B6EE6D42ABBA481D18225CD1 (void);
// 0x000003D4 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_debounceTime(System.Single)
extern void SnapTurnProviderBase_set_debounceTime_mA3A71F981B7AB3FE4EA549700A00A31EDE0BCDCF (void);
// 0x000003D5 System.Boolean UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_enableTurnLeftRight()
extern void SnapTurnProviderBase_get_enableTurnLeftRight_mCE216102A30A809F524228B2688AE4CD69A72E8E (void);
// 0x000003D6 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_enableTurnLeftRight(System.Boolean)
extern void SnapTurnProviderBase_set_enableTurnLeftRight_mE37E00B0AEF96E72C5A725657704899C5A7A2050 (void);
// 0x000003D7 System.Boolean UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_enableTurnAround()
extern void SnapTurnProviderBase_get_enableTurnAround_mB79C94E50BC13E2B41CE7F44AD804CD4A6120F3F (void);
// 0x000003D8 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_enableTurnAround(System.Boolean)
extern void SnapTurnProviderBase_set_enableTurnAround_m1967C968578C79810E812C1430DBEED772940DA0 (void);
// 0x000003D9 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::Update()
extern void SnapTurnProviderBase_Update_mE3B3F1550F5EE35D2546D419D749C0F1E1B6D835 (void);
// 0x000003DA UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::ReadInput()
// 0x000003DB System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::GetTurnAmount(UnityEngine.Vector2)
extern void SnapTurnProviderBase_GetTurnAmount_m4C5F368F5D1DDB8CA050F871C755F749E33A8FD8 (void);
// 0x000003DC System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::StartTurn(System.Single)
extern void SnapTurnProviderBase_StartTurn_m47F3693CDD1A77D7F3F8B246A3EB560D5DEACA28 (void);
// 0x000003DD System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::FakeStartTurn(System.Boolean)
extern void SnapTurnProviderBase_FakeStartTurn_mD7EE8938E63D4DE32735CD08E64536C9B7FAB795 (void);
// 0x000003DE System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::FakeStartTurnAround()
extern void SnapTurnProviderBase_FakeStartTurnAround_mBA49D5A87D3CA3ABCB4688BF38CE504C371C860D (void);
// 0x000003DF System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::.ctor()
extern void SnapTurnProviderBase__ctor_mC7A394104AB6C51DCFEE6F009EE4A0542EAD2C3D (void);
// 0x000003E0 UnityEngine.XR.Interaction.Toolkit.TeleportationProvider UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportationProvider()
extern void BaseTeleportationInteractable_get_teleportationProvider_m7F11373094593BE6800DF0F2E1A4E07122C77D4C (void);
// 0x000003E1 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportationProvider(UnityEngine.XR.Interaction.Toolkit.TeleportationProvider)
extern void BaseTeleportationInteractable_set_teleportationProvider_m13EE75A5801ECDC6F499236678678912DCBD8EE0 (void);
// 0x000003E2 UnityEngine.XR.Interaction.Toolkit.MatchOrientation UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_matchOrientation()
extern void BaseTeleportationInteractable_get_matchOrientation_m6A3A79A9F2B8A7B9EED84965030CF572A2BA8088 (void);
// 0x000003E3 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_matchOrientation(UnityEngine.XR.Interaction.Toolkit.MatchOrientation)
extern void BaseTeleportationInteractable_set_matchOrientation_m65DE908A81D711663C0960CA47E9F572A2C57C23 (void);
// 0x000003E4 UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/TeleportTrigger UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportTrigger()
extern void BaseTeleportationInteractable_get_teleportTrigger_m9736C0E38FB52F8D788AB68D23A3924FE3350CC6 (void);
// 0x000003E5 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportTrigger(UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/TeleportTrigger)
extern void BaseTeleportationInteractable_set_teleportTrigger_m6963317C85ABB863768A08AD9BEC70A872406243 (void);
// 0x000003E6 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::Awake()
extern void BaseTeleportationInteractable_Awake_m2E45F04A714A0E3A7BA523FBD5D4E27CDA67CF8D (void);
// 0x000003E7 System.Boolean UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void BaseTeleportationInteractable_GenerateTeleportRequest_m02AC569EBA728EB910FE3172F83AFE25D912D109 (void);
// 0x000003E8 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::SendTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_SendTeleportRequest_m06966E4550BD6473B924337BB96329295F414730 (void);
// 0x000003E9 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void BaseTeleportationInteractable_OnSelectEntered_m34FEDC72505B26632A3C8B424C3893F074EFE5E6 (void);
// 0x000003EA System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void BaseTeleportationInteractable_OnSelectExited_mC0044A385D2E8094C38AAA6134A4AAFE2F8B17B3 (void);
// 0x000003EB System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
extern void BaseTeleportationInteractable_OnActivated_m1C14C70FB9573A6C539254C3C5A588677EE7FD6A (void);
// 0x000003EC System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
extern void BaseTeleportationInteractable_OnDeactivated_mB7A1EAC5E50867C549BACF9A37D6B13C139CC367 (void);
// 0x000003ED System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::.ctor()
extern void BaseTeleportationInteractable__ctor_m73D4E147FCDC9B5ADA3A990DAA59529D505358FD (void);
// 0x000003EE UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::get_teleportAnchorTransform()
extern void TeleportationAnchor_get_teleportAnchorTransform_mB649F7195B32C5938C34F037FA3C299939E1372C (void);
// 0x000003EF System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::set_teleportAnchorTransform(UnityEngine.Transform)
extern void TeleportationAnchor_set_teleportAnchorTransform_mFC13614FCC73FA077DF8221A572067A47E73C1AB (void);
// 0x000003F0 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnValidate()
extern void TeleportationAnchor_OnValidate_m236595E662A5C0FAEC63CEB42B1030802AD9E374 (void);
// 0x000003F1 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnDrawGizmos()
extern void TeleportationAnchor_OnDrawGizmos_mD5E293A0DF7EDA594BC772AECD58E3E9079DF78F (void);
// 0x000003F2 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationAnchor_GenerateTeleportRequest_m9F32F7582D779E78248D13B168B540AAD6D54AE2 (void);
// 0x000003F3 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::.ctor()
extern void TeleportationAnchor__ctor_mC91D25351178CFA93D95CCA34213B2D2FB17A3CA (void);
// 0x000003F4 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationArea::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationArea_GenerateTeleportRequest_mA4D89EF67A4C11EC1E0FCEF196F01AA2BEDCF9CF (void);
// 0x000003F5 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationArea::.ctor()
extern void TeleportationArea__ctor_m981C857E5A856A01B3A5E7002E139D8FA16A2CD1 (void);
// 0x000003F6 UnityEngine.XR.Interaction.Toolkit.TeleportRequest UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::get_currentRequest()
extern void TeleportationProvider_get_currentRequest_mAE80EC4214026855B58E95F11698934A70EF3AE0 (void);
// 0x000003F7 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::set_currentRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportationProvider_set_currentRequest_mB7A7C5C75CBDAA8E39790D872CC6A1EC7D0AEB6D (void);
// 0x000003F8 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::get_validRequest()
extern void TeleportationProvider_get_validRequest_m2AD7C84DF0321684BE2A80B9F93CC8CF496D776B (void);
// 0x000003F9 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::set_validRequest(System.Boolean)
extern void TeleportationProvider_set_validRequest_m12632B25FF5A8653A77FE6277FD440E0DFB8A4D2 (void);
// 0x000003FA System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::QueueTeleportRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportationProvider_QueueTeleportRequest_mFEA3C48C18C7BC9041C239FCB854FF258DEEA9F4 (void);
// 0x000003FB System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::Update()
extern void TeleportationProvider_Update_m558B546E4D8EBC8DFEC205185DC2D4931DBD66F8 (void);
// 0x000003FC System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::.ctor()
extern void TeleportationProvider__ctor_mA68401AFB5FC65D62C2EB35E74B573274D6B5E1D (void);
// 0x000003FD System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWirePlaneOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWirePlaneOriented_m5DA33156AB2E62F9A782B27255C036A18614CB26 (void);
// 0x000003FE System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWireCubeOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWireCubeOriented_m2D604FE35E9C6B47B7A2E443539CED3B841174CC (void);
// 0x000003FF System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawAxisArrows(UnityEngine.Transform,System.Single)
extern void GizmoHelpers_DrawAxisArrows_m59A73957FCA515A992DAF4F501141D4F79753988 (void);
// 0x00000400 System.Void UnityEngine.XR.Interaction.Toolkit.SortingHelpers::Sort(System.Collections.Generic.IList`1<T>,System.Collections.Generic.IComparer`1<T>)
// 0x00000401 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_rig()
extern void XRRig_get_rig_m9E851C240AF6392715E45FBCEB17905C81D4D067 (void);
// 0x00000402 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_rig(UnityEngine.GameObject)
extern void XRRig_set_rig_m06D3941E6FFDEB18288AF6875030F94477FCDD08 (void);
// 0x00000403 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraFloorOffsetObject()
extern void XRRig_get_cameraFloorOffsetObject_m84D130B76715FC55D84720B6EF2E61ED71236384 (void);
// 0x00000404 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraFloorOffsetObject(UnityEngine.GameObject)
extern void XRRig_set_cameraFloorOffsetObject_m2EA7E9A64EA92C9AC5F6E6210EB4535BA7B66185 (void);
// 0x00000405 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraGameObject()
extern void XRRig_get_cameraGameObject_mC07CE95931449E7335ABDA829BB64A7D24A7E254 (void);
// 0x00000406 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraGameObject(UnityEngine.GameObject)
extern void XRRig_set_cameraGameObject_mBB083AC5AEECE2291BD13079B4DFD1D14BC5B8C8 (void);
// 0x00000407 UnityEngine.XR.TrackingOriginModeFlags UnityEngine.XR.Interaction.Toolkit.XRRig::get_trackingOriginMode()
extern void XRRig_get_trackingOriginMode_mF6BA9EC5AFF0B7F770D79A28375F557D7A56F7BF (void);
// 0x00000408 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_trackingOriginMode(UnityEngine.XR.TrackingOriginModeFlags)
extern void XRRig_set_trackingOriginMode_mE7E827E41DE3A46B15D1D9E4FF50BF52B67D1DB7 (void);
// 0x00000409 UnityEngine.XR.TrackingSpaceType UnityEngine.XR.Interaction.Toolkit.XRRig::get_trackingSpace()
extern void XRRig_get_trackingSpace_m55D7131E5B68227B8B78F22ECE2EAB91406CF321 (void);
// 0x0000040A System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_trackingSpace(UnityEngine.XR.TrackingSpaceType)
extern void XRRig_set_trackingSpace_mEB17DC6C896A210B97052DA27209A4DBC21FA660 (void);
// 0x0000040B System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraYOffset()
extern void XRRig_get_cameraYOffset_mEFBA7480902AAA160131FB9814C8CF33C035B19E (void);
// 0x0000040C System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraYOffset(System.Single)
extern void XRRig_set_cameraYOffset_mD05CD10A47A6EA8CEC9A3C91C119B5E3F0E3D30E (void);
// 0x0000040D UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_rigInCameraSpacePos()
extern void XRRig_get_rigInCameraSpacePos_m46BDA6929B22BB60943929DF68C03F2D95AE30D4 (void);
// 0x0000040E UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpacePos()
extern void XRRig_get_cameraInRigSpacePos_m6C414B6DB5C5773DD6F968A0A30B9A15175C537B (void);
// 0x0000040F System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpaceHeight()
extern void XRRig_get_cameraInRigSpaceHeight_m645FBDEEF6A42A35315BF06CAC5BD50B01C96322 (void);
// 0x00000410 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnValidate()
extern void XRRig_OnValidate_m3C3C5F4CF76DA05E9E4FEE5D2EE3B4DA0436EAA5 (void);
// 0x00000411 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::Awake()
extern void XRRig_Awake_mAD97FBC51DF1F48F3825C4B8C69B465C8A8D76F9 (void);
// 0x00000412 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::Start()
extern void XRRig_Start_mF38344274D62DC649AEDCA9B5847040D0E735E88 (void);
// 0x00000413 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnDestroy()
extern void XRRig_OnDestroy_mAAABBAC2991D7FD41876C72889ED813D73C2A04A (void);
// 0x00000414 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnDrawGizmos()
extern void XRRig_OnDrawGizmos_mA5BFDAA4D5D122B126C33C51569EB117C52E3EFC (void);
// 0x00000415 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::UpgradeTrackingSpaceToTrackingOriginMode()
extern void XRRig_UpgradeTrackingSpaceToTrackingOriginMode_m2558C531D747FAD837B16B0B6F2A9CA01E7C8F02 (void);
// 0x00000416 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::TryInitializeCamera()
extern void XRRig_TryInitializeCamera_m8C4BA56E4A4FA3D2A177EF179E820463F90B5742 (void);
// 0x00000417 System.Collections.IEnumerator UnityEngine.XR.Interaction.Toolkit.XRRig::RepeatInitializeCamera()
extern void XRRig_RepeatInitializeCamera_mFFF933EDE636C322553254DDD98081E4131036F3 (void);
// 0x00000418 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCamera()
extern void XRRig_SetupCamera_m28054289B880D4DF29402ACCA09773DC501255BB (void);
// 0x00000419 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnInputSubsystemTrackingOriginUpdated(UnityEngine.XR.XRInputSubsystem)
extern void XRRig_OnInputSubsystemTrackingOriginUpdated_m85689F7869FCEA7903C699FED57083DC19EB706E (void);
// 0x0000041A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCamera(UnityEngine.XR.XRInputSubsystem)
extern void XRRig_SetupCamera_mCB7223E75C1DE2B715FD7B87F3C178C9A3648534 (void);
// 0x0000041B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCameraLegacy(UnityEngine.XR.TrackingSpaceType)
extern void XRRig_SetupCameraLegacy_mCD13F0D825E482C1550DFB935500B8C73CB56057 (void);
// 0x0000041C System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::MoveOffsetHeight()
extern void XRRig_MoveOffsetHeight_m71208C9AF0BD19610C340719D8648547DE8F55A2 (void);
// 0x0000041D System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::MoveOffsetHeight(System.Single)
extern void XRRig_MoveOffsetHeight_m8DEA1993C9C27EC13C79C2E8E2EB1AB08598C5F8 (void);
// 0x0000041E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::RotateAroundCameraUsingRigUp(System.Single)
extern void XRRig_RotateAroundCameraUsingRigUp_mB7E04DE02F255309A7FCD53EA98CAE62598923A1 (void);
// 0x0000041F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::RotateAroundCameraPosition(UnityEngine.Vector3,System.Single)
extern void XRRig_RotateAroundCameraPosition_m1ABD14C5C421C068C8DEE86EE07B3C61D3FFDBBB (void);
// 0x00000420 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUp(UnityEngine.Vector3)
extern void XRRig_MatchRigUp_m5C68647D22F132B361B37935927C92CD1B18E5D3 (void);
// 0x00000421 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpCameraForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpCameraForward_mEB1C7FF65F31A987DC2F1EA1454B04F7A9C17E26 (void);
// 0x00000422 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpRigForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpRigForward_m2C2F90C6001ED0929B481AA6B27C4E1E4940F0AC (void);
// 0x00000423 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MoveCameraToWorldLocation(UnityEngine.Vector3)
extern void XRRig_MoveCameraToWorldLocation_m4F880AD13BE30D928A549462732E285F991F6B36 (void);
// 0x00000424 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::.ctor()
extern void XRRig__ctor_m535BE59B97E32AEC098F138B616B4A0A116FADB4 (void);
// 0x00000425 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::.cctor()
extern void XRRig__cctor_m64BB40DB1C07DA7F793C19F56A50EE4E415C4F3A (void);
// 0x00000426 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::<OnValidate>g__IsModeStale|34_0()
extern void XRRig_U3COnValidateU3Eg__IsModeStaleU7C34_0_m971065ABBB177C6B81B71A9321EA501E62D6E075 (void);
// 0x00000427 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::.ctor(System.Int32)
extern void U3CRepeatInitializeCameraU3Ed__41__ctor_mC7E575C1EB31E061E1EF4768E5B950575A355D4D (void);
// 0x00000428 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::System.IDisposable.Dispose()
extern void U3CRepeatInitializeCameraU3Ed__41_System_IDisposable_Dispose_mA63AB6F487659558A0167EEAA72FF9D9F1A8B491 (void);
// 0x00000429 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::MoveNext()
extern void U3CRepeatInitializeCameraU3Ed__41_MoveNext_m3EA404B83FF0A26A088D5E9DA63F2CEB7A6BF98C (void);
// 0x0000042A System.Object UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6BB9A2E9614E547FBEA2D33CBFC8105A0CE2B75E (void);
// 0x0000042B System.Void UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::System.Collections.IEnumerator.Reset()
extern void U3CRepeatInitializeCameraU3Ed__41_System_Collections_IEnumerator_Reset_m77720BF240FD98DE95F2E9A77EB9C45DDFEBAEE5 (void);
// 0x0000042C System.Object UnityEngine.XR.Interaction.Toolkit.XRRig/<RepeatInitializeCamera>d__41::System.Collections.IEnumerator.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__41_System_Collections_IEnumerator_get_Current_m0EF5D447B24A5A59CAD41CBE418CA2C031DA01AF (void);
// 0x0000042D UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_move()
extern void JoystickModel_get_move_m70AE9CDFB7AA66AAFD351D97782ABEB641AA5530 (void);
// 0x0000042E System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_move(UnityEngine.Vector2)
extern void JoystickModel_set_move_mF7448D0EB096CAE4AA3BA600AFD9C256BDB92DEE (void);
// 0x0000042F System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDown()
extern void JoystickModel_get_submitButtonDown_m4781AB6841EF967FE735A0CBDDC8B7D2C9A824FD (void);
// 0x00000430 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDown(System.Boolean)
extern void JoystickModel_set_submitButtonDown_m9836DBA6465E2649DD252CFCE998A20560378AA3 (void);
// 0x00000431 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDelta()
extern void JoystickModel_get_submitButtonDelta_m13E6E73ED3FCDE1542C07A452F79728A22D60291 (void);
// 0x00000432 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_submitButtonDelta_mF1EEFF5C310C6BCD9524ECC014E72238F4F237D9 (void);
// 0x00000433 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDown()
extern void JoystickModel_get_cancelButtonDown_m4EA1958676D8288D201EC0B465D97A1B3FF20439 (void);
// 0x00000434 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDown(System.Boolean)
extern void JoystickModel_set_cancelButtonDown_m73092D4996A375205A17AEDA95436DE3A2F04C1C (void);
// 0x00000435 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDelta()
extern void JoystickModel_get_cancelButtonDelta_m2FF7638404C12972C68BB76D67A238D68405DDA7 (void);
// 0x00000436 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_cancelButtonDelta_m1BA93A60D4381707771AE5BB23B2A29B0F0C899B (void);
// 0x00000437 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_implementationData()
extern void JoystickModel_get_implementationData_mEE5E6D8DC8F4FFB90D22903F7550CCAA1A038E05 (void);
// 0x00000438 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_implementationData(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData)
extern void JoystickModel_set_implementationData_mF353000BE7A505F9092D70AAD885488CD1A7557B (void);
// 0x00000439 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::Reset()
extern void JoystickModel_Reset_m5450A9CD3FC27AA60735EC7A606F7642219B43FB (void);
// 0x0000043A System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::OnFrameFinished()
extern void JoystickModel_OnFrameFinished_mEB59B1809C70BC70F9ED9A7A5242FB8340622279 (void);
// 0x0000043B System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_consecutiveMoveCount()
extern void ImplementationData_get_consecutiveMoveCount_mA34C0AD68D78BF9EFEB3E99ACF6EEC725DE26340 (void);
// 0x0000043C System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_consecutiveMoveCount(System.Int32)
extern void ImplementationData_set_consecutiveMoveCount_m940C6C09D01210E8D6DBF3DFF86464B40ACA4C54 (void);
// 0x0000043D UnityEngine.EventSystems.MoveDirection UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_lastMoveDirection()
extern void ImplementationData_get_lastMoveDirection_m0F197FADF10FD88BEDFAF6570BE8A925BB606E7E (void);
// 0x0000043E System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_lastMoveDirection(UnityEngine.EventSystems.MoveDirection)
extern void ImplementationData_set_lastMoveDirection_mB59C221E12AD9B5BADCEDA075D9BDF47C5ED5080 (void);
// 0x0000043F System.Single UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_lastMoveTime()
extern void ImplementationData_get_lastMoveTime_mAE3D5AB7B9E7F6A14889824AA76455A95C0A691A (void);
// 0x00000440 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_lastMoveTime(System.Single)
extern void ImplementationData_set_lastMoveTime_m47ECDDF47D60E0A246C83E686B79A1AA3B618A4A (void);
// 0x00000441 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::Reset()
extern void ImplementationData_Reset_mC7E2D248AB737031A8D4EE9820CF3F64C412967D (void);
// 0x00000442 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_isDown()
extern void MouseButtonModel_get_isDown_m1CD763098303E22C163F3C680CCB3641E42F5356 (void);
// 0x00000443 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_isDown(System.Boolean)
extern void MouseButtonModel_set_isDown_mB524856AE27BCB72E4FA521057966A08DF908483 (void);
// 0x00000444 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_lastFrameDelta()
extern void MouseButtonModel_get_lastFrameDelta_mD9ABCE054D580DD7206A39288CE66DA6A946570B (void);
// 0x00000445 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_lastFrameDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void MouseButtonModel_set_lastFrameDelta_m92B6FEE2BCB34EB047B3CA5DF2DC9316D2C7D8F4 (void);
// 0x00000446 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::Reset()
extern void MouseButtonModel_Reset_mC058FBA77FD6DDBF8BFB5CF76EE8C50F56227C06 (void);
// 0x00000447 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::OnFrameFinished()
extern void MouseButtonModel_OnFrameFinished_mE55F730CAF06370BA6AB621D6932657637FBE2B8 (void);
// 0x00000448 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyTo_m81FB09020B8E0D0AE381CC861ED6AC2EF8B152FE (void);
// 0x00000449 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyFrom_mDE54553AD7233A14E41F9806588D6E42BA79B3B7 (void);
// 0x0000044A System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m286676B035D542856422C65A38C50CD08348200F (void);
// 0x0000044B System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m9EE85DCF9962AF0F2FF6D8A3B8DDEB33ACDEDD33 (void);
// 0x0000044C System.Single UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m236A0F23942FAD42399B859634DDBA443D3E2906 (void);
// 0x0000044D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m4C64E9BB61F646ECB6CFCFB4DAF2009709A956FE (void);
// 0x0000044E UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_mE53DCBF0B8F376FB4C9BF1FAEA13E11988495295 (void);
// 0x0000044F System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_mA4A1E5E3EABF70132CC91B8F17414E6C26C55CB5 (void);
// 0x00000450 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_mA71A6D911BC67E2877120BEC46F32127E000639D (void);
// 0x00000451 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_m07B9A00899211C2D9EFE5C7367F0D0CD92671DCD (void);
// 0x00000452 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_mC3D191EA02E9FDF466A0B0E7DB836743FE3A7E0B (void);
// 0x00000453 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m0E6E5DF7C22E6CF52D13D8D577C570C10D404D12 (void);
// 0x00000454 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_m8AAD5F8569332EB9543335E8FFE454513382E35C (void);
// 0x00000455 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m08BDACF14EB3891EB34D4BE7611A01E121218129 (void);
// 0x00000456 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mB4FDDBF950B79E25366E72F266DF02E2348ED813 (void);
// 0x00000457 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_m1F3CABB710E5AC7EE2A51E6B33446F8C343F22FA (void);
// 0x00000458 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::Reset()
extern void ImplementationData_Reset_m26650CA4925208D3CFCC484D107017CE6A8D4509 (void);
// 0x00000459 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_pointerId()
extern void MouseModel_get_pointerId_m11D2E24194A0D949D405EBB251E239E8FDACB3D1 (void);
// 0x0000045A System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_changedThisFrame()
extern void MouseModel_get_changedThisFrame_mA73BE121871FCA75556A0DB0B5AA26F24B44007A (void);
// 0x0000045B System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_changedThisFrame(System.Boolean)
extern void MouseModel_set_changedThisFrame_m5751B58646A87B9A796E0C73E670BC262696F6DD (void);
// 0x0000045C UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_position()
extern void MouseModel_get_position_m78546DD8EB343EF0FAA3B00DF5FC8E5D83CAC31E (void);
// 0x0000045D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_position(UnityEngine.Vector2)
extern void MouseModel_set_position_m32976C82E8173C43D920E417C1526D08C1848894 (void);
// 0x0000045E UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_deltaPosition()
extern void MouseModel_get_deltaPosition_mB4120B0D71243A5DCED22C2DCB41F61C752344A0 (void);
// 0x0000045F System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_deltaPosition(UnityEngine.Vector2)
extern void MouseModel_set_deltaPosition_m49E7E4D3B9976725AA516BE1DF87F41AC18718A2 (void);
// 0x00000460 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_scrollDelta()
extern void MouseModel_get_scrollDelta_m575BDC1B8981D596808C1B6D5D3BA0786F0C86FE (void);
// 0x00000461 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_scrollDelta(UnityEngine.Vector2)
extern void MouseModel_set_scrollDelta_m5063B4C4E1B2AD1BEE7146DF1591AAB2203C1942 (void);
// 0x00000462 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_leftButton()
extern void MouseModel_get_leftButton_mF2FE94CCCFC90A2602FF4161F61F20BA069CC7AF (void);
// 0x00000463 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_leftButton_mDF681AB6BF3C50A013EDEC3BA1998F84C11C5CA3 (void);
// 0x00000464 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButtonPressed(System.Boolean)
extern void MouseModel_set_leftButtonPressed_mB262B7B3E2C450A3C6FC9BEF978FF82C61B4EC05 (void);
// 0x00000465 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_rightButton()
extern void MouseModel_get_rightButton_m95C9191F32EC76F8DF8E737FC86BE69DD483DE9C (void);
// 0x00000466 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_rightButton_m0B017073C10DD745A5810A5B764FE4C38C9863B2 (void);
// 0x00000467 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButtonPressed(System.Boolean)
extern void MouseModel_set_rightButtonPressed_m3B8AA3966338CB518A1E01412AE8278B8123FA98 (void);
// 0x00000468 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_middleButton()
extern void MouseModel_get_middleButton_m7771854F89139CEFB78DB492621D8402351FC657 (void);
// 0x00000469 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_middleButton_mD42C3ECBE1B7E8709AA0C037E0CBC65E065CBC86 (void);
// 0x0000046A System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButtonPressed(System.Boolean)
extern void MouseModel_set_middleButtonPressed_m7E777E54424A123E85C19C8FBC666531045B2E2B (void);
// 0x0000046B System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::.ctor(System.Int32)
extern void MouseModel__ctor_m83A579E595CC3EA1D0B7871BEA4F7BE3F43BCF5B (void);
// 0x0000046C System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::OnFrameFinished()
extern void MouseModel_OnFrameFinished_mDFDCF666965A09EDD96DA78A378E5D8885AEA760 (void);
// 0x0000046D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyTo_m40FA373152091998C17145F41864E19AADA3F3EF (void);
// 0x0000046E System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyFrom_mCD3E50E6FD213121A15576B7F375C6C0605BAC1E (void);
// 0x0000046F System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::get_hoverTargets()
extern void InternalData_get_hoverTargets_mED5DD88CE637A33FCB133AB2A1164DBF31A153C4 (void);
// 0x00000470 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void InternalData_set_hoverTargets_m58FA8DC4B246C66F1B644FCB88657EBE790FBF45 (void);
// 0x00000471 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::get_pointerTarget()
extern void InternalData_get_pointerTarget_m23F87D3C2E745888E515AFC1B1019D67D3815ABC (void);
// 0x00000472 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::set_pointerTarget(UnityEngine.GameObject)
extern void InternalData_set_pointerTarget_mF9314EBE084E03FB7CBEDCF822FF4CA6DDDDA5C8 (void);
// 0x00000473 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::Reset()
extern void InternalData_Reset_mE88036CD76DEA4817FC9EA538A96AEC351BBFBC3 (void);
// 0x00000474 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_pointerId()
extern void TouchModel_get_pointerId_m09132E54C14049EE958701E47521DBF87AE46CAA (void);
// 0x00000475 UnityEngine.TouchPhase UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectPhase()
extern void TouchModel_get_selectPhase_mAB7BD6D97EE045B8CBA8FE6D9674AE69B8FA9764 (void);
// 0x00000476 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectPhase(UnityEngine.TouchPhase)
extern void TouchModel_set_selectPhase_mEFA5BF0498E34859A19804B53380A6A44775E7B2 (void);
// 0x00000477 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectDelta()
extern void TouchModel_get_selectDelta_m3C485FF688B2D891723D298D56B95EDDB522EF5B (void);
// 0x00000478 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TouchModel_set_selectDelta_m9D3C5D26D870867BAFAFA5ABD0A327321B442021 (void);
// 0x00000479 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_changedThisFrame()
extern void TouchModel_get_changedThisFrame_m23FD7722215391AEE0B605CF9D8E66AE909E67B8 (void);
// 0x0000047A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_changedThisFrame(System.Boolean)
extern void TouchModel_set_changedThisFrame_m561781EE6C0BFD95C120EB69B0BC84FCF6C63CB5 (void);
// 0x0000047B UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_position()
extern void TouchModel_get_position_m733738D61FF916C6754A28320A3C9E986B1FEFF9 (void);
// 0x0000047C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_position(UnityEngine.Vector2)
extern void TouchModel_set_position_m192EEBE8DC7EC01D31651052C7E6EB0594618419 (void);
// 0x0000047D UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_deltaPosition()
extern void TouchModel_get_deltaPosition_m9E35067BFB1D1BDDC3F1C79A9A00E51A7E969ECC (void);
// 0x0000047E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_deltaPosition(UnityEngine.Vector2)
extern void TouchModel_set_deltaPosition_mA92EDE6055F346698EF3484330B18FDF1479F106 (void);
// 0x0000047F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::.ctor(System.Int32)
extern void TouchModel__ctor_m2E4B407C745FD930A50FF3DF0E234396E1E9D903 (void);
// 0x00000480 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::Reset()
extern void TouchModel_Reset_mF62A73478E369AD0FB97C38E11BF8F704206F7F0 (void);
// 0x00000481 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::OnFrameFinished()
extern void TouchModel_OnFrameFinished_m07CDE88E34A987019751A05CE638F6A08E17EFA0 (void);
// 0x00000482 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyTo_mDD7D97D3A60CBB3F6C342E12546F02D551EC16E8 (void);
// 0x00000483 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyFrom_m97D1D1FC51032EB8EA514CC3D32CB82D23577FE9 (void);
// 0x00000484 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_m712167711F5E065EF75C3593498EB5682F02524B (void);
// 0x00000485 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_m535B94D1E4CE496E48B6CFC3CD0FEBD8F5D0BFE7 (void);
// 0x00000486 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_m99391EE2BB2C1566C578C8366FAA3A33F3A10197 (void);
// 0x00000487 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_m9A1690C598287B3ED3BD9752BD92EBC6BFCFBE1E (void);
// 0x00000488 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m1D754410DC0DF37DF9AA39C04E7A488E82D958EE (void);
// 0x00000489 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m2DBCC77F6E037B90B04E8B22198E776A9E6CCF92 (void);
// 0x0000048A System.Single UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_mDD847C787AC675CFE647E4216ADCE857A0F5C47F (void);
// 0x0000048B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m2998A794D01109054102594B68C5876CB19B07AF (void);
// 0x0000048C UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_m5218B58A65B1252DEF55E1E70A2CD93FBDDAF97B (void);
// 0x0000048D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m29A8C216BA3FD177E9A443678FADB09D3BAC3169 (void);
// 0x0000048E UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_mFF0FD2531D8FAD7DC4F9F2847837F0E85726C65A (void);
// 0x0000048F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_m05F79A6CC57D04E4DDA51136390484B5EC4294E2 (void);
// 0x00000490 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m77E3E5A1AC94C35A10A5CE3F6B4A4849D9E31297 (void);
// 0x00000491 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m085ED8ADB34B7E733689A41969C08E49CEC510A1 (void);
// 0x00000492 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_m5241D8F233E573A0D6A5D95E8D366989CB99A9D3 (void);
// 0x00000493 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_mB8BB6FA60ABC1583206435291ED0A063CF55E34F (void);
// 0x00000494 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mA29B766C2B3421C6A6126A032EC06998E6049A2B (void);
// 0x00000495 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_m9CF28E709931F5E9C64B8E1A2C04BE428E6389D6 (void);
// 0x00000496 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::Reset()
extern void ImplementationData_Reset_mA1A9200248AE4DE55F23C8248FC71D19D1297896 (void);
// 0x00000497 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void TrackedDeviceEventData__ctor_m9BFD5A55C43B5A58601D06115C03CE4051918D95 (void);
// 0x00000498 System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayPoints()
extern void TrackedDeviceEventData_get_rayPoints_mA9FBBE93DC03B69F011B80202670D247859C6804 (void);
// 0x00000499 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceEventData_set_rayPoints_m538512D7DF7AB490E2790704CE82D8A967983258 (void);
// 0x0000049A System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayHitIndex()
extern void TrackedDeviceEventData_get_rayHitIndex_m8953BA1EB97C9DAECF82D522389112154272639C (void);
// 0x0000049B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayHitIndex(System.Int32)
extern void TrackedDeviceEventData_set_rayHitIndex_mC2E51FF9F570EF9B76DF485444295DE228E0612A (void);
// 0x0000049C UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_layerMask()
extern void TrackedDeviceEventData_get_layerMask_mFD08C45D5450B44F9029B91A8DB5E8CE293DCA0B (void);
// 0x0000049D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_layerMask(UnityEngine.LayerMask)
extern void TrackedDeviceEventData_set_layerMask_m765FDC4C0A6821E43539F06DACB13BCDD04004C2 (void);
// 0x0000049E UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_interactor()
extern void TrackedDeviceEventData_get_interactor_mA00E13242D00AE5C04C1035158B8BC796D4A8A30 (void);
// 0x0000049F System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_ignoreReversedGraphics()
extern void TrackedDeviceGraphicRaycaster_get_ignoreReversedGraphics_m6993D2E5318D6583C7DA17FD80782DB725C78E3D (void);
// 0x000004A0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_ignoreReversedGraphics(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_ignoreReversedGraphics_m0161DB6A8C3E83B6DE293FCDD729DF6D14EF73D0 (void);
// 0x000004A1 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_checkFor2DOcclusion()
extern void TrackedDeviceGraphicRaycaster_get_checkFor2DOcclusion_m36139C25B14C7E5F877EDE5B28A8DC17E0639CA7 (void);
// 0x000004A2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_checkFor2DOcclusion(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_checkFor2DOcclusion_m9734AF8E12A0B58B290DBA60131A25752806BECF (void);
// 0x000004A3 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_checkFor3DOcclusion()
extern void TrackedDeviceGraphicRaycaster_get_checkFor3DOcclusion_m158267D5C6CC36324F3E0909B4B6CD80255D744C (void);
// 0x000004A4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_checkFor3DOcclusion(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_checkFor3DOcclusion_m1AB8A6330DA062FF8FFC1058F7A4A02A270E61FA (void);
// 0x000004A5 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_blockingMask()
extern void TrackedDeviceGraphicRaycaster_get_blockingMask_m9D6A9012CD2C55EC70A7649BA1BAEBE38BFA5AFD (void);
// 0x000004A6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_blockingMask(UnityEngine.LayerMask)
extern void TrackedDeviceGraphicRaycaster_set_blockingMask_mE8AE475D17143EF140431FAF485535E86BEDE517 (void);
// 0x000004A7 UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_raycastTriggerInteraction()
extern void TrackedDeviceGraphicRaycaster_get_raycastTriggerInteraction_mD8699AC8629259E139A3FAF8854011E92F8B744C (void);
// 0x000004A8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void TrackedDeviceGraphicRaycaster_set_raycastTriggerInteraction_m1B8383E3CE6C89428E5FA7FE06DEE08ED85780B5 (void);
// 0x000004A9 UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_eventCamera()
extern void TrackedDeviceGraphicRaycaster_get_eventCamera_m3EFCF67C039BCEF356D5521BAD8DB1DF00FB92EF (void);
// 0x000004AA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_Raycast_m6ADB184895B59C1FAC0DED7ADA1BDAF58C881480 (void);
// 0x000004AB UnityEngine.Canvas UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_canvas()
extern void TrackedDeviceGraphicRaycaster_get_canvas_m5E641EB589123E2A1599B28E1DCA3488ACE9AADB (void);
// 0x000004AC UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_mA27555583B00234BFA12B3A617117CEEDB065BB1 (void);
// 0x000004AD UnityEngine.RaycastHit2D UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit2D[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_m8B68F4307253C769057EF035101A28C14F0CB4FC (void);
// 0x000004AE System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycasts(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycasts_m128D132A0C91EE78BA1D67D6B4FC0EE358DF3774 (void);
// 0x000004AF System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycast(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.LayerMask,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycast_m1E02BA87EB404F71BDAEE51046112543FC8C3255 (void);
// 0x000004B0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::SortedRaycastGraphics(UnityEngine.Canvas,UnityEngine.Ray,System.Single,UnityEngine.LayerMask,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData>)
extern void TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_m0412421DF25AF5FD6241A3AC33F24BE046A18910 (void);
// 0x000004B1 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::RayIntersectsRectTransform(UnityEngine.RectTransform,UnityEngine.Ray,UnityEngine.Vector3&,System.Single&)
extern void TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_m270E40985BAA694F09B5646C48AAF1E6A3FB26C5 (void);
// 0x000004B2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.ctor()
extern void TrackedDeviceGraphicRaycaster__ctor_mA408EA45E5ED282A1219A52DF77C1BCA432B9D0F (void);
// 0x000004B3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.cctor()
extern void TrackedDeviceGraphicRaycaster__cctor_m5D870686FDAE444EFE752BA7770B20AC211398B6 (void);
// 0x000004B4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::.ctor(UnityEngine.UI.Graphic,UnityEngine.Vector3,UnityEngine.Vector2,System.Single,System.Int32)
extern void RaycastHitData__ctor_mA3105F92D1D16D531B60FACB7453F972D13D9249 (void);
// 0x000004B5 UnityEngine.UI.Graphic UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_graphic()
extern void RaycastHitData_get_graphic_mF244823E64AB76542BED4C51A8BCF45ACC81144B (void);
// 0x000004B6 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_worldHitPosition()
extern void RaycastHitData_get_worldHitPosition_m399EAA366E322BE0BD61E56368F737FC29F85E28 (void);
// 0x000004B7 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_screenPosition()
extern void RaycastHitData_get_screenPosition_m812ADB2AA30A26B4AB1B5AFBC8F06979131AE08A (void);
// 0x000004B8 System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_distance()
extern void RaycastHitData_get_distance_m5F6671106F1D00C942F5402BD17D9F27BFB2C22C (void);
// 0x000004B9 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_displayIndex()
extern void RaycastHitData_get_displayIndex_m32F8946542D364F916BE8D04CB8B61C150B99198 (void);
// 0x000004BA System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitComparer::Compare(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData)
extern void RaycastHitComparer_Compare_m7B6425F530A627AE2E4907917EE8F16A7F1BD8D1 (void);
// 0x000004BB System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_mF6293EBA83713B48EA1D35CBB1A40BA53A8D3CD3 (void);
// 0x000004BC UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_implementationData()
extern void TrackedDeviceModel_get_implementationData_mADCDA47D3AD499318CDE0BBEA2BE132689DE2EE5 (void);
// 0x000004BD System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_pointerId()
extern void TrackedDeviceModel_get_pointerId_mD80CE625A75CA576B28A9C8ACB63D571A6606B67 (void);
// 0x000004BE System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_maxRaycastDistance()
extern void TrackedDeviceModel_get_maxRaycastDistance_m3A722F116890557E9C451E7966830DB91325C1D0 (void);
// 0x000004BF System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_maxRaycastDistance(System.Single)
extern void TrackedDeviceModel_set_maxRaycastDistance_m5A2BDC35BAE802154CA48F0141EB1B68A327124E (void);
// 0x000004C0 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_select()
extern void TrackedDeviceModel_get_select_m5BA61464B02AB3202ACE442320C0BE21B4CE44F0 (void);
// 0x000004C1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_select(System.Boolean)
extern void TrackedDeviceModel_set_select_m9B5835627C8C86095E53A520F355EB2AEB99E2FF (void);
// 0x000004C2 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_selectDelta()
extern void TrackedDeviceModel_get_selectDelta_mE75B1DD26F07531FC8FB387802D4FF37F1FD6A0A (void);
// 0x000004C3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TrackedDeviceModel_set_selectDelta_mB827DB0A535918C47D1855DE994092A2C3DA6DFE (void);
// 0x000004C4 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_changedThisFrame()
extern void TrackedDeviceModel_get_changedThisFrame_m68B82453470231A4F6679AD1254FA69B298893CD (void);
// 0x000004C5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_changedThisFrame(System.Boolean)
extern void TrackedDeviceModel_set_changedThisFrame_m54AAB4E033B8D5FB021C9941D2F0535C9AF03B52 (void);
// 0x000004C6 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_position()
extern void TrackedDeviceModel_get_position_m00C189C1464672F36AB30D8D5D27B530F9DFD1A8 (void);
// 0x000004C7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_position(UnityEngine.Vector3)
extern void TrackedDeviceModel_set_position_mB7F655655F284799CA203C3050100717371A71B2 (void);
// 0x000004C8 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_orientation()
extern void TrackedDeviceModel_get_orientation_m1ADE24778B2D6A1B54C1A9276AE2D9DF4A558AE9 (void);
// 0x000004C9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_orientation(UnityEngine.Quaternion)
extern void TrackedDeviceModel_set_orientation_m84FA015204514B424CFC408A4B0E5C9C6476BDB0 (void);
// 0x000004CA System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastPoints()
extern void TrackedDeviceModel_get_raycastPoints_mAC3EB88F58248C61A9574674B1BEC617D2673E30 (void);
// 0x000004CB System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceModel_set_raycastPoints_m8A427DE3C9C4405E6C1CFDB1D32FF48ECAD45514 (void);
// 0x000004CC UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_currentRaycast()
extern void TrackedDeviceModel_get_currentRaycast_m73EFCB5A66AE403012FF9FEC6B439D31C2E5266B (void);
// 0x000004CD System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_currentRaycast(UnityEngine.EventSystems.RaycastResult)
extern void TrackedDeviceModel_set_currentRaycast_m8E73593D06B1606AB02B03467243094884F5CD12 (void);
// 0x000004CE System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_currentRaycastEndpointIndex()
extern void TrackedDeviceModel_get_currentRaycastEndpointIndex_m925CFAC84DCE305E31D381EC25B88C5D86D4E805 (void);
// 0x000004CF System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_currentRaycastEndpointIndex(System.Int32)
extern void TrackedDeviceModel_set_currentRaycastEndpointIndex_mA4ABAD82D6BF7784AC287AD89F453D5D7AF9A041 (void);
// 0x000004D0 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastLayerMask()
extern void TrackedDeviceModel_get_raycastLayerMask_m026CBA559DE2753C8E0BFDC0C61A86540480AE45 (void);
// 0x000004D1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastLayerMask(UnityEngine.LayerMask)
extern void TrackedDeviceModel_set_raycastLayerMask_mF035862C9351DAE42ECFE530D2CC4E5EE6AA8779 (void);
// 0x000004D2 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_scrollDelta()
extern void TrackedDeviceModel_get_scrollDelta_m98E3C008CE34CA7698FBB522240054675857C201 (void);
// 0x000004D3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_scrollDelta(UnityEngine.Vector2)
extern void TrackedDeviceModel_set_scrollDelta_m3044CFFEB48920A17459E320098354EAFD140A41 (void);
// 0x000004D4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::.ctor(System.Int32)
extern void TrackedDeviceModel__ctor_mAE27577B157ECE28CF94FFACE80975BC194E0EC1 (void);
// 0x000004D5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::Reset(System.Boolean)
extern void TrackedDeviceModel_Reset_mBABBE929D784F92680CFC66E4BD26DC7F9EA15ED (void);
// 0x000004D6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::OnFrameFinished()
extern void TrackedDeviceModel_OnFrameFinished_m32FC34175809DBB3A1BBC26699D6D9FB40A7C480 (void);
// 0x000004D7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyTo(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyTo_mC2DC5C1F6ADF2CBF06B7D8288964DAB339E7D692 (void);
// 0x000004D8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyFrom(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyFrom_mE187E9E91E324AA0ABD3D1E8CD30DD793BFA0C39 (void);
// 0x000004D9 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_m41E773C53C151D97E9492E8F45ED8FB4E96A59A7 (void);
// 0x000004DA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_m19F1CB02F7A7692C5D20A89947DFABFD92CAB455 (void);
// 0x000004DB UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_m4B202866FF1FA91937343DCCB013B74DC114FE60 (void);
// 0x000004DC System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_mFB25C58ADE397F423F6E9C022BBB41B0553B740E (void);
// 0x000004DD System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m46C5339146DD29A9F8F17820C6EF44A3E7BEAF6C (void);
// 0x000004DE System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m456D482B7022A4F5920ADFC3CC40B9A9AD8E3757 (void);
// 0x000004DF System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m5CCBBBA87FDEBC3EA7EEEA060BE5D75D869AF5EF (void);
// 0x000004E0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m29F68A8DB6BAF909CDFCD88FD5F5A319059AEE90 (void);
// 0x000004E1 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_position()
extern void ImplementationData_get_position_m956AC6C7FB1ADEC574061B12EA47FED7780AC498 (void);
// 0x000004E2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_position(UnityEngine.Vector2)
extern void ImplementationData_set_position_m8E4DD90017F1D25E85A7C3C81B1DE163E30DB7DB (void);
// 0x000004E3 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_mCABB186BED5B1D8518709A46FE359DB489EF86C1 (void);
// 0x000004E4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m0A20F9AB3E05608A87702FC7D9AEB11BCA833726 (void);
// 0x000004E5 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_m1E35327FB13E41C71374DBB7B117D0DE32C337F0 (void);
// 0x000004E6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_m088EA8CF851F035A6E05B7AAD0DD4DFAE9504745 (void);
// 0x000004E7 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m1A17AB48043129AEB2EBEA6946AA699E0C8BD61C (void);
// 0x000004E8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m3D05029ED302431CAE9346C26F4CC2BBF4A3E066 (void);
// 0x000004E9 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_mCC3398E95B1DBBB0A3A63AB307E76ACD390BF72F (void);
// 0x000004EA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m9925CC40E6A24D23784861334482B1E10B493D43 (void);
// 0x000004EB UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mA1BB6E49C20D8AF62693ED0023261303286D2C3B (void);
// 0x000004EC System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_mA2E82652C8A181F5EFDFD1CEBDFF655F07D895F3 (void);
// 0x000004ED System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::Reset()
extern void ImplementationData_Reset_mAB96D4826DF6DD8D1A45E408B3771A340B70CC50 (void);
// 0x000004EE System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_clickSpeed()
extern void UIInputModule_get_clickSpeed_mED8269543BF6E7B9D6F29767103FA1BFDDDBABD1 (void);
// 0x000004EF System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_clickSpeed(System.Single)
extern void UIInputModule_set_clickSpeed_m5FAF42247EA9E935740DF515DF3662D87724AE91 (void);
// 0x000004F0 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_moveDeadzone()
extern void UIInputModule_get_moveDeadzone_m5FC1449527025B0AEE65FE6701A6930A284326A3 (void);
// 0x000004F1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_moveDeadzone(System.Single)
extern void UIInputModule_set_moveDeadzone_m4985AD362CF90600168BFE20A3A79F2A7F0F6A5C (void);
// 0x000004F2 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_repeatDelay()
extern void UIInputModule_get_repeatDelay_m4C2807BEED1855AA63863ECC5D930EF5730E41EF (void);
// 0x000004F3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_repeatDelay(System.Single)
extern void UIInputModule_set_repeatDelay_mE62431ED050B2ED75776A4782EFF661F74E87665 (void);
// 0x000004F4 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_repeatRate()
extern void UIInputModule_get_repeatRate_m264B9272E73D3FF3393F99B5BE0DDD7EE470A829 (void);
// 0x000004F5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_repeatRate(System.Single)
extern void UIInputModule_set_repeatRate_m2E9C993F77FA13817BAFCC0D53E9B7B947741324 (void);
// 0x000004F6 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_trackedDeviceDragThresholdMultiplier()
extern void UIInputModule_get_trackedDeviceDragThresholdMultiplier_mC88BCECF2840B6C883B81D46902AE26BD96F9925 (void);
// 0x000004F7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_trackedDeviceDragThresholdMultiplier(System.Single)
extern void UIInputModule_set_trackedDeviceDragThresholdMultiplier_m244A9F1DB957B27F7F759A6DB7C41473AA76C40C (void);
// 0x000004F8 UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_uiCamera()
extern void UIInputModule_get_uiCamera_m70A1AAB50856078AFC1FEFF561B03A80443F243F (void);
// 0x000004F9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_uiCamera(UnityEngine.Camera)
extern void UIInputModule_set_uiCamera_m53AED31E29BD6BA148C4E8B33BDCDCAAB5A1D1EA (void);
// 0x000004FA System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::Update()
extern void UIInputModule_Update_mEC7D21BA91C671CAFED3DC41175BD912C6BF55CD (void);
// 0x000004FB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::DoProcess()
extern void UIInputModule_DoProcess_m77427B9BD29BEA5E3201BB93386BCF5388D1FEDA (void);
// 0x000004FC System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::Process()
extern void UIInputModule_Process_mCA4F1691A7B55CBD58FC6A51D5F1F6FC66E610A6 (void);
// 0x000004FD System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::SendUpdateEventToSelectedObject()
extern void UIInputModule_SendUpdateEventToSelectedObject_m8031016F1A2FE893D81357CAF45D187F524DA3B5 (void);
// 0x000004FE UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::PerformRaycast(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_PerformRaycast_m252CDEE5EA783493953231E7CE8DB1DE65BCEFCD (void);
// 0x000004FF System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouse(UnityEngine.XR.Interaction.Toolkit.UI.MouseModel&)
extern void UIInputModule_ProcessMouse_m55F4E0D3E1292EC33136205250F961F41E84BA47 (void);
// 0x00000500 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseMovement(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseMovement_m7115515A5AD98BD9240950BCB704BF814D73CE56 (void);
// 0x00000501 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButton(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState,UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseButton_m93741FDFD381DA1C36E41A223916AEA9502A65FC (void);
// 0x00000502 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButtonDrag(UnityEngine.EventSystems.PointerEventData,System.Single)
extern void UIInputModule_ProcessMouseButtonDrag_mB5381110D311AB1CAA00F4A457539883D6F84902 (void);
// 0x00000503 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseScroll(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseScroll_m451578BEFC8A77118B213F77894BC0C1E2EC321F (void);
// 0x00000504 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTouch(UnityEngine.XR.Interaction.Toolkit.UI.TouchModel&)
extern void UIInputModule_ProcessTouch_m5906227FF084CE3D00977BD7F11EEF65FA068549 (void);
// 0x00000505 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTrackedDevice(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&,System.Boolean)
extern void UIInputModule_ProcessTrackedDevice_mD5B96B2E4A90048260B92532B7D6B821197A49EC (void);
// 0x00000506 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessJoystick(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel&)
extern void UIInputModule_ProcessJoystick_mF08E9C4D6B2456EF2BD5CB6E6416619CC4166639 (void);
// 0x00000507 UnityEngine.EventSystems.PointerEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedPointerEvent()
extern void UIInputModule_GetOrCreateCachedPointerEvent_m6EC7DEB510FE1B554CC61FADD6B4DD33DD7E0321 (void);
// 0x00000508 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedTrackedDeviceEvent()
extern void UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m4105AF887118BBA58060308881098FDD69E40D8B (void);
// 0x00000509 UnityEngine.EventSystems.AxisEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedAxisEvent()
extern void UIInputModule_GetOrCreateCachedAxisEvent_m4B7D4DC52E215F2A17F441FD2C1F1CBA457A61A8 (void);
// 0x0000050A System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::.ctor()
extern void UIInputModule__ctor_mF46715D3F1B896D7C6C99A15B00545866FBD0FD4 (void);
// 0x0000050B System.Void UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x0000050C System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x0000050D System.Single UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_maxRaycastDistance()
extern void XRUIInputModule_get_maxRaycastDistance_m7EFD446560D43460B3F42AB48E029E7C6471DFE1 (void);
// 0x0000050E System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_maxRaycastDistance(System.Single)
extern void XRUIInputModule_set_maxRaycastDistance_mA92538AC86945632CB6434D64A10702D7E7EBFC9 (void);
// 0x0000050F System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableXRInput()
extern void XRUIInputModule_get_enableXRInput_mCB0B36DF3D3958107FC3294ACF3B48B0E0BD68D3 (void);
// 0x00000510 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableXRInput(System.Boolean)
extern void XRUIInputModule_set_enableXRInput_m543057C13560D5308529DD63D042F09AD7F9DA62 (void);
// 0x00000511 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableMouseInput()
extern void XRUIInputModule_get_enableMouseInput_m850A66D3DDA974FB48C329184164490C85BC0D7C (void);
// 0x00000512 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableMouseInput(System.Boolean)
extern void XRUIInputModule_set_enableMouseInput_m97B0DA3F625FD8AA84A686443C5E0BDE5104C5D2 (void);
// 0x00000513 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableTouchInput()
extern void XRUIInputModule_get_enableTouchInput_m765DDE7A7703A1F7690819C2838196026591B525 (void);
// 0x00000514 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableTouchInput(System.Boolean)
extern void XRUIInputModule_set_enableTouchInput_mEB65C6C52B8E36896706998F19A37E1E072DB36C (void);
// 0x00000515 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::OnEnable()
extern void XRUIInputModule_OnEnable_m1C141B8400BDB078017CEC570C4B1F8854CA5059 (void);
// 0x00000516 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor)
extern void XRUIInputModule_RegisterInteractor_m374CF9E0F84B50B6D62DF650A6EF8C8A54604FD2 (void);
// 0x00000517 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor)
extern void XRUIInputModule_UnregisterInteractor_m31D9300477B62C22339EF1223BAB161058BA9F00 (void);
// 0x00000518 UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::GetInteractor(System.Int32)
extern void XRUIInputModule_GetInteractor_m26CAC08CC8AE4331B2039C3C407455FA790E430A (void);
// 0x00000519 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::GetTrackedDeviceModel(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRUIInputModule_GetTrackedDeviceModel_m0974947125B5DB8C3DCBCDA9D17F676E5412A3BD (void);
// 0x0000051A System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::DoProcess()
extern void XRUIInputModule_DoProcess_m9F19917E52D74623EE80FF69CC43F5F110567375 (void);
// 0x0000051B System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessMouse()
extern void XRUIInputModule_ProcessMouse_m86E2C9637324C799E35E77C4A94ECF3DD6864092 (void);
// 0x0000051C System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessTouches()
extern void XRUIInputModule_ProcessTouches_m2AE05974DFAEC594CB8AC172AF65C1BAC0B2A68E (void);
// 0x0000051D System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::.ctor()
extern void XRUIInputModule__ctor_m49BDF588B681FBB6C14DFE6BCE0BA1B2F94B0583 (void);
// 0x0000051E System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule/RegisteredInteractor::.ctor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor,System.Int32)
extern void RegisteredInteractor__ctor_m599746C9D0CEC3BC8EE3848164F5CD99611FC30C (void);
// 0x0000051F System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule/RegisteredTouch::.ctor(UnityEngine.Touch,System.Int32)
extern void RegisteredTouch__ctor_m6464420D1DFD3E6F407C3582184963173CFBF959 (void);
// 0x00000520 UnityEngine.XR.Interaction.Toolkit.Inputs.Cardinal UnityEngine.XR.Interaction.Toolkit.Inputs.CardinalUtility::GetNearestCardinal(UnityEngine.Vector2)
extern void CardinalUtility_GetNearestCardinal_mD0D5EEA123C0B684D20BE8DBF98B1954BB134B28 (void);
// 0x00000521 System.Collections.Generic.List`1<UnityEngine.InputSystem.InputActionAsset> UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::get_actionAssets()
extern void InputActionManager_get_actionAssets_mCC3D35605B78EAEEAAFF33EEAB4AF59121DEE92D (void);
// 0x00000522 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::set_actionAssets(System.Collections.Generic.List`1<UnityEngine.InputSystem.InputActionAsset>)
extern void InputActionManager_set_actionAssets_mE83FBC4F082307875665DF9CD857FBE4D0735921 (void);
// 0x00000523 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::OnEnable()
extern void InputActionManager_OnEnable_mB35FEF9B4B3A734E29A7DF1CF220C5E31ADB4BBD (void);
// 0x00000524 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::OnDisable()
extern void InputActionManager_OnDisable_mB49CFBC312F2F49804F42E5D15DC433AF425CEDF (void);
// 0x00000525 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::EnableInput()
extern void InputActionManager_EnableInput_m23B975D861464777A37EBEB3D797127ED9C5F300 (void);
// 0x00000526 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::DisableInput()
extern void InputActionManager_DisableInput_mC9ADD2BC09F5858C875FB8BA3F215BC91D04FF49 (void);
// 0x00000527 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::.ctor()
extern void InputActionManager__ctor_m5B4FC1A3708BF9C4C2CD0E6981BE9A0766221CAF (void);
// 0x00000528 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionPropertyExtensions::EnableDirectAction(UnityEngine.InputSystem.InputActionProperty)
extern void InputActionPropertyExtensions_EnableDirectAction_mA61CA2DCFB497E459F53938F1DA9B117C8653CC7 (void);
// 0x00000529 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionPropertyExtensions::DisableDirectAction(UnityEngine.InputSystem.InputActionProperty)
extern void InputActionPropertyExtensions_DisableDirectAction_m2F8AB32FD2D98F072682A770301BF66829658DD4 (void);
// 0x0000052A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::.cctor()
extern void SimulatedInputLayoutLoader__cctor_m3D22CCF524A29655239041B7A009527A7DF234E9 (void);
// 0x0000052B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::Initialize()
extern void SimulatedInputLayoutLoader_Initialize_mA8D3A8DED86CC5D6DD0CF667B4F9567FD588923A (void);
// 0x0000052C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::RegisterInputLayouts()
extern void SimulatedInputLayoutLoader_RegisterInputLayouts_m6438013D44910B5E51E0CAD32DFB7980FFA0A0EC (void);
// 0x0000052D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardXTranslateAction()
extern void XRDeviceSimulator_get_keyboardXTranslateAction_mAEC857837C3AD47E6756817C17490B91306E556E (void);
// 0x0000052E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardXTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardXTranslateAction_m14EC02ECE9BB46857ACCAA0E166EDC281C99DD9F (void);
// 0x0000052F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardYTranslateAction()
extern void XRDeviceSimulator_get_keyboardYTranslateAction_mDF1A80117C3F9FB22D2742E2E9254385F07CC1E4 (void);
// 0x00000530 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardYTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardYTranslateAction_m63709C1276410510ED6ED3D9FDB3C770BE56358C (void);
// 0x00000531 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardZTranslateAction()
extern void XRDeviceSimulator_get_keyboardZTranslateAction_m995C15288E5FE69E97648F31DEE60FF216DAF527 (void);
// 0x00000532 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardZTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardZTranslateAction_m9FEA64151745175A92B2E8ECCC8B4A27E8E4ADD7 (void);
// 0x00000533 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateLeftAction()
extern void XRDeviceSimulator_get_manipulateLeftAction_mA85B27C1880AC1DE15975D2C7C1B89934922125A (void);
// 0x00000534 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateLeftAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateLeftAction_mF11CD458504C68947EBB0AD53FD7CFA47AFF0342 (void);
// 0x00000535 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateRightAction()
extern void XRDeviceSimulator_get_manipulateRightAction_mF0363E1B3F89E964284CAB88EC8A375BA22F02CA (void);
// 0x00000536 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateRightAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateRightAction_m7DFF0258BF3CB30963F464BB62AACC6826FFF790 (void);
// 0x00000537 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleManipulateLeftAction()
extern void XRDeviceSimulator_get_toggleManipulateLeftAction_mA7BCE1A7F1B06B0A86DCD4EF807BA5C7971536D0 (void);
// 0x00000538 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleManipulateLeftAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleManipulateLeftAction_m607071E6465FF4DF40CBB2A370824182BF6F5501 (void);
// 0x00000539 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleManipulateRightAction()
extern void XRDeviceSimulator_get_toggleManipulateRightAction_mB1D68E47D156979F8933A1880B1B6266A7DFD743 (void);
// 0x0000053A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleManipulateRightAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleManipulateRightAction_m1A1DCBF5F4F31471DAD2C64EBA55DA892B81BDFC (void);
// 0x0000053B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateHeadAction()
extern void XRDeviceSimulator_get_manipulateHeadAction_m1650DFE59F8873E51FA31DE5B7D21B58BCAE1F83 (void);
// 0x0000053C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateHeadAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateHeadAction_mDF6DEC50297F7BB491903468B66E6041A742B91E (void);
// 0x0000053D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseDeltaAction()
extern void XRDeviceSimulator_get_mouseDeltaAction_m065F754881E23CF189B73D92FA55E9F3FA6C4898 (void);
// 0x0000053E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseDeltaAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_mouseDeltaAction_mE2BF32E0F48E4DC3815C1AB1DF8870C1880DEDF7 (void);
// 0x0000053F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollAction()
extern void XRDeviceSimulator_get_mouseScrollAction_m8E2D28871F31EFC91ABBBC0AF23373542589863B (void);
// 0x00000540 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_mouseScrollAction_mF887890C9E5BD5D4035EA9E4F98284A1C2BC428A (void);
// 0x00000541 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_rotateModeOverrideAction()
extern void XRDeviceSimulator_get_rotateModeOverrideAction_m52C0F7D6F6B8CB65FC53D8BE9E902321BB047928 (void);
// 0x00000542 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_rotateModeOverrideAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_rotateModeOverrideAction_m9CF7EB921CBACE13DA840DED5171AAC8C2865EA4 (void);
// 0x00000543 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleMouseTransformationModeAction()
extern void XRDeviceSimulator_get_toggleMouseTransformationModeAction_mBE870DC9239163FEB958CC68A77954F83043C43C (void);
// 0x00000544 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleMouseTransformationModeAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleMouseTransformationModeAction_m4AAA05D30ECED5C6FE39D38BFEE39A3755F48789 (void);
// 0x00000545 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_negateModeAction()
extern void XRDeviceSimulator_get_negateModeAction_mD3F492596539B2E94D374B0A3BD6B67A2E1A5705 (void);
// 0x00000546 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_negateModeAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_negateModeAction_mF939E46C69911339E0D7F75FB59297F495595AB9 (void);
// 0x00000547 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_xConstraintAction()
extern void XRDeviceSimulator_get_xConstraintAction_m0BBF93C6665FCD2B01B0D188CA02D3533AC1EE83 (void);
// 0x00000548 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_xConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_xConstraintAction_m26CB0C3DBA2D8EC2C816428C3097BDBC0B936B82 (void);
// 0x00000549 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_yConstraintAction()
extern void XRDeviceSimulator_get_yConstraintAction_m88E3F22740F8D1D8BCB91B0E018B8543B1E43B64 (void);
// 0x0000054A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_yConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_yConstraintAction_m419D7ECB9726D11B94EF13188C94712514FB4E5D (void);
// 0x0000054B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_zConstraintAction()
extern void XRDeviceSimulator_get_zConstraintAction_mB70DB1E733D48E968566AFF7B991071277147FA3 (void);
// 0x0000054C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_zConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_zConstraintAction_mAA5C4E3451548EEB1A6D3D37DAA8853A44BEB368 (void);
// 0x0000054D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_resetAction()
extern void XRDeviceSimulator_get_resetAction_mF5B360BF55BF43892AE586E8BBA718FF4DFE9AD6 (void);
// 0x0000054E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_resetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_resetAction_m38CB0732FC6B85BDE2F8A46007B33F79BF3C391D (void);
// 0x0000054F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleCursorLockAction()
extern void XRDeviceSimulator_get_toggleCursorLockAction_m7445BA478DFE51BABDE53525E3EF915A0BC25D36 (void);
// 0x00000550 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleCursorLockAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleCursorLockAction_m925FA2348E18E841B157DE750E0C49D19C84B2EC (void);
// 0x00000551 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleDevicePositionTargetAction()
extern void XRDeviceSimulator_get_toggleDevicePositionTargetAction_m8A96CE958D4808BEFAF135DB74CA285623A54461 (void);
// 0x00000552 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleDevicePositionTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleDevicePositionTargetAction_m03962215EE0113F70021A0A8325DD27301A3CAED (void);
// 0x00000553 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_togglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_get_togglePrimary2DAxisTargetAction_mD7F64B00E8C105AF42762F3E16BC40A176A52D64 (void);
// 0x00000554 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_togglePrimary2DAxisTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_togglePrimary2DAxisTargetAction_m089E9ACA27A858CD2B1B0BDAB7924D0CCFF02093 (void);
// 0x00000555 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_get_toggleSecondary2DAxisTargetAction_m9FC15DBC134C76FC8A175D52DC3D8E2632AD8B2F (void);
// 0x00000556 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleSecondary2DAxisTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleSecondary2DAxisTargetAction_mD354D81F6C13CC58EBB441E73D37DAE11FBE1FEF (void);
// 0x00000557 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_axis2DAction()
extern void XRDeviceSimulator_get_axis2DAction_m16CD23D63EC0719B98D0F13F576F4C48F8ED4A56 (void);
// 0x00000558 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_axis2DAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_axis2DAction_m694E81502DACE237BF3979B0556036D958A09DE6 (void);
// 0x00000559 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_restingHandAxis2DAction()
extern void XRDeviceSimulator_get_restingHandAxis2DAction_m8956462E6DC1E539DC94DDFC08635D060C8A8D04 (void);
// 0x0000055A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_restingHandAxis2DAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_restingHandAxis2DAction_m4F434D67CAFD4BE291829883E14C9674BC603D5B (void);
// 0x0000055B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_gripAction()
extern void XRDeviceSimulator_get_gripAction_m0B8C8D5371D10914A69BD1635F2FF649BDBD4EF0 (void);
// 0x0000055C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_gripAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_gripAction_m2559D8F1FCA153D2917C7D15AC7A7B658018047E (void);
// 0x0000055D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_triggerAction()
extern void XRDeviceSimulator_get_triggerAction_m308DC7EBA6FE05360C9A9FD56B9C4A1CADC3DCAB (void);
// 0x0000055E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_triggerAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_triggerAction_m7318C2B689FAA3E0FE1EA23A3B159CBB4790C127 (void);
// 0x0000055F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primaryButtonAction()
extern void XRDeviceSimulator_get_primaryButtonAction_m26B030CEC4D2A1B3D5E44AF69413699E43AEDC68 (void);
// 0x00000560 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primaryButtonAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primaryButtonAction_m3E8CDCBBDE435FBE7616D09D96C3399F38490679 (void);
// 0x00000561 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondaryButtonAction()
extern void XRDeviceSimulator_get_secondaryButtonAction_m89F1E90EC5406039C46BD6BB200CA8E3E8CA89CB (void);
// 0x00000562 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondaryButtonAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondaryButtonAction_mF1AA502AB807073F8D1CF2C30748FCE17A6C5BDF (void);
// 0x00000563 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_menuAction()
extern void XRDeviceSimulator_get_menuAction_mB112D9FD60BC25CB5AA100F1DE501EAFF1F07021 (void);
// 0x00000564 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_menuAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_menuAction_m9C30DA78848B09E419095389CF576BC5014A49DE (void);
// 0x00000565 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primary2DAxisClickAction()
extern void XRDeviceSimulator_get_primary2DAxisClickAction_m5B25D0CDD29382E2CA7E6AC2BF874EB3911BE872 (void);
// 0x00000566 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primary2DAxisClickAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primary2DAxisClickAction_mBFDC086582382D82B0187886F1D4A7E4DE395A61 (void);
// 0x00000567 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondary2DAxisClickAction()
extern void XRDeviceSimulator_get_secondary2DAxisClickAction_m99BAB0619C7B06594E1C5F92BB9D5A6FCF293908 (void);
// 0x00000568 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondary2DAxisClickAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondary2DAxisClickAction_mB4083F206D165F5CCB3C8DE9519585C0774C260A (void);
// 0x00000569 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primary2DAxisTouchAction()
extern void XRDeviceSimulator_get_primary2DAxisTouchAction_m1C4E79B47D994E0FBC0790C2750869CCF6FACE7D (void);
// 0x0000056A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primary2DAxisTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primary2DAxisTouchAction_m4AD4B650F940CED900B6B700E03441DB164E7099 (void);
// 0x0000056B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondary2DAxisTouchAction()
extern void XRDeviceSimulator_get_secondary2DAxisTouchAction_mAEAAE4D34F3453E0FD2A553A0A4FB7879C6EF43C (void);
// 0x0000056C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondary2DAxisTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondary2DAxisTouchAction_m39EB08C1CE99B146186401F0398EBB1DCBEF73FF (void);
// 0x0000056D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primaryTouchAction()
extern void XRDeviceSimulator_get_primaryTouchAction_mEC658D2FF7E8367AF1EA1F8B79B916F7504CA3DF (void);
// 0x0000056E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primaryTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primaryTouchAction_m3D5A0C9051548EF940FAA2859F545D8B5559F823 (void);
// 0x0000056F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondaryTouchAction()
extern void XRDeviceSimulator_get_secondaryTouchAction_m8E40B1403A5818E40F91DDB46F7C45CEE497AD93 (void);
// 0x00000570 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondaryTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondaryTouchAction_m83D111D1C1BE4330D136E725BC412A58DD1DB820 (void);
// 0x00000571 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_cameraTransform()
extern void XRDeviceSimulator_get_cameraTransform_m5E26EF97718C2531462C1C747310F0257C9B65EE (void);
// 0x00000572 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_cameraTransform(UnityEngine.Transform)
extern void XRDeviceSimulator_set_cameraTransform_m4CE32DC6AF026A8F90139D3B5027153FF0FFF496 (void);
// 0x00000573 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardTranslateSpace()
extern void XRDeviceSimulator_get_keyboardTranslateSpace_mA7581591050894F335DBC74DCDDC4FE7066C9DA6 (void);
// 0x00000574 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardTranslateSpace(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space)
extern void XRDeviceSimulator_set_keyboardTranslateSpace_mC4B14614B9DA1B3B570ADFA4C49DAC10E91D7684 (void);
// 0x00000575 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseTranslateSpace()
extern void XRDeviceSimulator_get_mouseTranslateSpace_m3CEB5444AFA0C96BA3F0A4377525520FA743DBBE (void);
// 0x00000576 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseTranslateSpace(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space)
extern void XRDeviceSimulator_set_mouseTranslateSpace_m60E5A51DF00057F58B02CE4A2D2D6EA8F8A90F11 (void);
// 0x00000577 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardXTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardXTranslateSpeed_m34D631E53F390CE9DAA933F93F3A094B53ECA7A1 (void);
// 0x00000578 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardXTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardXTranslateSpeed_m233FB1BE01843CE795024CAB9765FE5318F90E87 (void);
// 0x00000579 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardYTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardYTranslateSpeed_mF416AC06A8E033D360E290CD69F9329CC4005000 (void);
// 0x0000057A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardYTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardYTranslateSpeed_m7436D89A2EA6EE5FD4DF71A0046D562ED05E883D (void);
// 0x0000057B System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardZTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardZTranslateSpeed_m824737FE57562AFB74B84662DDB76C93B6215F8D (void);
// 0x0000057C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardZTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardZTranslateSpeed_m05B9955C3FBE81E1A5A25A151494549BA61CA257 (void);
// 0x0000057D System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseXTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseXTranslateSensitivity_mEF1AC7C4C47A5B36B190E61A05C4A5958016F1B7 (void);
// 0x0000057E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseXTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseXTranslateSensitivity_m216B7D285E468FC3F4B7CE0E8780A9A85D9FEF82 (void);
// 0x0000057F System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseYTranslateSensitivity_m13D10E49A258BD10D22E9F8758B36D52FA54F70F (void);
// 0x00000580 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseYTranslateSensitivity_mCBFFCA92FB5D7F82B5257BDCA997AE3E715DA257 (void);
// 0x00000581 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseScrollTranslateSensitivity_m7C0AFB651FE881FF12AA8465CB1A3099CF3E8F30 (void);
// 0x00000582 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseScrollTranslateSensitivity_m8177BD424F661EEDF75CAD618EC2E85191976FEF (void);
// 0x00000583 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseXRotateSensitivity()
extern void XRDeviceSimulator_get_mouseXRotateSensitivity_mF22D03037E2CD4C19686035824E6B96FF758931D (void);
// 0x00000584 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseXRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseXRotateSensitivity_mD84B0488D9172D04A7D9DACCB4311F395E108C16 (void);
// 0x00000585 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYRotateSensitivity()
extern void XRDeviceSimulator_get_mouseYRotateSensitivity_mB2CA87C42C3DE9621A741372E37E66035EB34A47 (void);
// 0x00000586 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseYRotateSensitivity_m010D3B1F052848EC5CEE995260FADCF05B12E126 (void);
// 0x00000587 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollRotateSensitivity()
extern void XRDeviceSimulator_get_mouseScrollRotateSensitivity_m01BCDF76CD5CC4970700DD2E63934F1B75CD5FE8 (void);
// 0x00000588 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseScrollRotateSensitivity_m5F89AC4B8DB0DB525259CCC3DDF8D586C4F1FFBF (void);
// 0x00000589 System.Boolean UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYRotateInvert()
extern void XRDeviceSimulator_get_mouseYRotateInvert_m346B6297579E45C8FA6875482CA0D22E1A734784 (void);
// 0x0000058A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYRotateInvert(System.Boolean)
extern void XRDeviceSimulator_set_mouseYRotateInvert_m656BDA7CE8337D4FD40877241E7106ACFACDF551 (void);
// 0x0000058B UnityEngine.CursorLockMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_desiredCursorLockMode()
extern void XRDeviceSimulator_get_desiredCursorLockMode_m991469ACF251962DF3CA09ECAFA3592BD91614BF (void);
// 0x0000058C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_desiredCursorLockMode(UnityEngine.CursorLockMode)
extern void XRDeviceSimulator_set_desiredCursorLockMode_m65D95EB9007710D62193A6BFD164FC1B9D20E7C3 (void);
// 0x0000058D UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseTransformationMode()
extern void XRDeviceSimulator_get_mouseTransformationMode_m8BD4DE8F0E31B845095DCD38FFB84A294DA067B7 (void);
// 0x0000058E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseTransformationMode(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode)
extern void XRDeviceSimulator_set_mouseTransformationMode_mE5FC60CA32B7CDE857D77B03BCFC6F7FD9707DD6 (void);
// 0x0000058F UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Axis2DTargets UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_axis2DTargets()
extern void XRDeviceSimulator_get_axis2DTargets_m68C47B011246DC08BB9611A418F78BAC47DCEFF7 (void);
// 0x00000590 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_axis2DTargets(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Axis2DTargets)
extern void XRDeviceSimulator_set_axis2DTargets_m5CFC74095D9951134A840A5749C61D1F8D0FAC71 (void);
// 0x00000591 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Awake()
extern void XRDeviceSimulator_Awake_mDBFC043E3D0959B6FCFC9B0827EC10FAEF9A12BF (void);
// 0x00000592 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnEnable()
extern void XRDeviceSimulator_OnEnable_m5A55CA99DEFF70FCFA7224EDE01079E41D7A136E (void);
// 0x00000593 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnDisable()
extern void XRDeviceSimulator_OnDisable_m6CF9E25E75DD2A57F7B1EB82AFF8A16B6A2F3BC3 (void);
// 0x00000594 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Update()
extern void XRDeviceSimulator_Update_m112C3A2F264E3DFCEA0761EAB9F4E3C7876F2027 (void);
// 0x00000595 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessPoseInput()
extern void XRDeviceSimulator_ProcessPoseInput_mEE5099FB14FD82F27B725339783B2E71945BAF6D (void);
// 0x00000596 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessControlInput()
extern void XRDeviceSimulator_ProcessControlInput_m9D55B442803730177CB77B6EC35E6EA92ACBAC52 (void);
// 0x00000597 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessAxis2DControlInput()
extern void XRDeviceSimulator_ProcessAxis2DControlInput_m5A022CEF566854D71D1DDB07BDAE259F78158B95 (void);
// 0x00000598 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessButtonControlInput(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState&)
extern void XRDeviceSimulator_ProcessButtonControlInput_m7A0601E20685FB8052F808192BC28689E9D49410 (void);
// 0x00000599 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::AddDevices()
extern void XRDeviceSimulator_AddDevices_m1D2D79EB8D14AFEEF34A3D7027CBA69C9BB61790 (void);
// 0x0000059A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::RemoveDevices()
extern void XRDeviceSimulator_RemoveDevices_m8E53C56EE87606F4DEAA9CED64DFE622C3128716 (void);
// 0x0000059B UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetResetScale()
extern void XRDeviceSimulator_GetResetScale_m974B3F9007BC2E6A3B382CF9376E93DD28C57F76 (void);
// 0x0000059C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetAxes(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRDeviceSimulator_GetAxes_m33C5790A6707C2B9E1613D1A4744B96BE6D5751B (void);
// 0x0000059D UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetDeltaRotation(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState&,UnityEngine.Quaternion&)
extern void XRDeviceSimulator_GetDeltaRotation_m37171322FF139EE6C8211923E0D893AC48C64AE9 (void);
// 0x0000059E UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetDeltaRotation(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState&,UnityEngine.Quaternion&)
extern void XRDeviceSimulator_GetDeltaRotation_mAD9A8D40BA4F68C019757BAF887FA1FB14E56F55 (void);
// 0x0000059F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Subscribe(UnityEngine.InputSystem.InputActionReference,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>)
extern void XRDeviceSimulator_Subscribe_m6023F8721D7CBAD7F197C237A4A4EC9EF8686B27 (void);
// 0x000005A0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Unsubscribe(UnityEngine.InputSystem.InputActionReference,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>)
extern void XRDeviceSimulator_Unsubscribe_m13A8C3E7B350425869BF70C573F9961D75886E58 (void);
// 0x000005A1 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Negate(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode)
extern void XRDeviceSimulator_Negate_mDC1562BE50A1F941B079D79850F48A58FF267B22 (void);
// 0x000005A2 UnityEngine.CursorLockMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Negate(UnityEngine.CursorLockMode)
extern void XRDeviceSimulator_Negate_m71147EF32467ECE0FFAC7204E909944F375F4B4D (void);
// 0x000005A3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardXTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardXTranslateAction_m6A981141F7DE6B0F503CE24005CBFB84BD34F816 (void);
// 0x000005A4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardXTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardXTranslateAction_mD06F002A3C7F6DE6A523268FA16C64A711783762 (void);
// 0x000005A5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardYTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardYTranslateAction_m57AB1C72BD66A290068437C7FF63B490EF01768B (void);
// 0x000005A6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardYTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardYTranslateAction_mB50D21E194002F0C2B9B636F45C256BE9228382E (void);
// 0x000005A7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardZTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardZTranslateAction_mC7873AD4DE21F216B37C2BB4907783345C093768 (void);
// 0x000005A8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardZTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardZTranslateAction_mB421A42AE7476E8451067FBFA9745F83ECF4A403 (void);
// 0x000005A9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateLeftAction()
extern void XRDeviceSimulator_SubscribeManipulateLeftAction_m26BAE17735BA8D7534E821A34E062F14C9A18ABD (void);
// 0x000005AA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateLeftAction()
extern void XRDeviceSimulator_UnsubscribeManipulateLeftAction_mE66D82A44D9E829CE9E521E1B85444F17CE12437 (void);
// 0x000005AB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateRightAction()
extern void XRDeviceSimulator_SubscribeManipulateRightAction_m4514A8B2CE274FDF4C983D1FE0DD0B4E48E185FB (void);
// 0x000005AC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateRightAction()
extern void XRDeviceSimulator_UnsubscribeManipulateRightAction_m69E6AD489547565D436DA74E795CDBA5D612F3FF (void);
// 0x000005AD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleManipulateLeftAction()
extern void XRDeviceSimulator_SubscribeToggleManipulateLeftAction_m59F59D6BB2D082DE361ACF3F6560A3062FA05BA4 (void);
// 0x000005AE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleManipulateLeftAction()
extern void XRDeviceSimulator_UnsubscribeToggleManipulateLeftAction_mC1D54164D14273C7FB74C7FE46849C4B221CA16E (void);
// 0x000005AF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleManipulateRightAction()
extern void XRDeviceSimulator_SubscribeToggleManipulateRightAction_mBBC73942B18FE3900A4DA0D467316BD77543E9DA (void);
// 0x000005B0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleManipulateRightAction()
extern void XRDeviceSimulator_UnsubscribeToggleManipulateRightAction_mDA6F51559FB94E780BABB80814D97D3F9E425072 (void);
// 0x000005B1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateHeadAction()
extern void XRDeviceSimulator_SubscribeManipulateHeadAction_m50F771079632C738C674A274D41303F3B85D0107 (void);
// 0x000005B2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateHeadAction()
extern void XRDeviceSimulator_UnsubscribeManipulateHeadAction_mEA96DB7DE4C30F4B8279F4523CA289B6639A0653 (void);
// 0x000005B3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMouseDeltaAction()
extern void XRDeviceSimulator_SubscribeMouseDeltaAction_mC6ABEFE67947F1DDBBA1A4D6B8CDBDE19D588F7F (void);
// 0x000005B4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMouseDeltaAction()
extern void XRDeviceSimulator_UnsubscribeMouseDeltaAction_mE59CAC816FDC3FB64F778EA45875610BDC5C5327 (void);
// 0x000005B5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMouseScrollAction()
extern void XRDeviceSimulator_SubscribeMouseScrollAction_mD5D0833C607F4FAF7D104B917A768D8D4AC407FD (void);
// 0x000005B6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMouseScrollAction()
extern void XRDeviceSimulator_UnsubscribeMouseScrollAction_m4CCC73F3075BE954B49132FBC224FD0E7F962D07 (void);
// 0x000005B7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeRotateModeOverrideAction()
extern void XRDeviceSimulator_SubscribeRotateModeOverrideAction_m40CB1843B4C14EB183CD5973296862C6BEA2B727 (void);
// 0x000005B8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeRotateModeOverrideAction()
extern void XRDeviceSimulator_UnsubscribeRotateModeOverrideAction_mD8D3CE7A2B19CEBA539524142A667F1691C96C9A (void);
// 0x000005B9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleMouseTransformationModeAction()
extern void XRDeviceSimulator_SubscribeToggleMouseTransformationModeAction_m9708A297228953DD9B1BFF208225AD5994E7A22F (void);
// 0x000005BA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleMouseTransformationModeAction()
extern void XRDeviceSimulator_UnsubscribeToggleMouseTransformationModeAction_m3C3753A2134B75B226C455DD22EBF9FFBDE881F5 (void);
// 0x000005BB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeNegateModeAction()
extern void XRDeviceSimulator_SubscribeNegateModeAction_m4469FE7F3AEE7DF9EC8C9EA84691DD2808492344 (void);
// 0x000005BC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeNegateModeAction()
extern void XRDeviceSimulator_UnsubscribeNegateModeAction_m5D818930F3FDA653C95C3AB1478E4FEA2809BDCA (void);
// 0x000005BD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeXConstraintAction()
extern void XRDeviceSimulator_SubscribeXConstraintAction_mBE5B5EA0C1E72D034597BB8FF1D2195E8C89E513 (void);
// 0x000005BE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeXConstraintAction()
extern void XRDeviceSimulator_UnsubscribeXConstraintAction_mB252DDCE49BD71228D08235869AF423039670065 (void);
// 0x000005BF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeYConstraintAction()
extern void XRDeviceSimulator_SubscribeYConstraintAction_m7766A0EC7E6330AF41B41B86ADAF7E61915C896E (void);
// 0x000005C0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeYConstraintAction()
extern void XRDeviceSimulator_UnsubscribeYConstraintAction_mE46D21B812BC6FC4EE73AF7B8A870C817EAB9A7A (void);
// 0x000005C1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeZConstraintAction()
extern void XRDeviceSimulator_SubscribeZConstraintAction_m8BDE69B132DD19F2C11DC7B2235694E06F396910 (void);
// 0x000005C2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeZConstraintAction()
extern void XRDeviceSimulator_UnsubscribeZConstraintAction_mF02E2FE56EB101E9DBC57D021DA9745EEECC97CF (void);
// 0x000005C3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeResetAction()
extern void XRDeviceSimulator_SubscribeResetAction_m1B18DD654BFF817ACF5C639CC28B5F8844093D57 (void);
// 0x000005C4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeResetAction()
extern void XRDeviceSimulator_UnsubscribeResetAction_mA14B2EA33DC090346DE3A291CD8947F173C554A5 (void);
// 0x000005C5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleCursorLockAction()
extern void XRDeviceSimulator_SubscribeToggleCursorLockAction_m66626DBA5BC3D51851DC302E5D05619DD6D8949F (void);
// 0x000005C6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleCursorLockAction()
extern void XRDeviceSimulator_UnsubscribeToggleCursorLockAction_mB073C2CBEA2991D5579B336B08ACD0AE1BA2EA50 (void);
// 0x000005C7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleDevicePositionTargetAction()
extern void XRDeviceSimulator_SubscribeToggleDevicePositionTargetAction_m9C5AFC5528BCAEF28E457C93B29B4F11DB482DF4 (void);
// 0x000005C8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleDevicePositionTargetAction()
extern void XRDeviceSimulator_UnsubscribeToggleDevicePositionTargetAction_m6E463B0563EF4428A37E8B903C11275A0ABF0C21 (void);
// 0x000005C9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeTogglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_SubscribeTogglePrimary2DAxisTargetAction_m8188CA681130F539B2D6F819200249FEF3E1696D (void);
// 0x000005CA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeTogglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_UnsubscribeTogglePrimary2DAxisTargetAction_mA66448125CA11AA7A6C138A81953A87AA1818B03 (void);
// 0x000005CB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_SubscribeToggleSecondary2DAxisTargetAction_m3CC5D4623FD75EE2E428483543DD4AE1D2031DA2 (void);
// 0x000005CC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_UnsubscribeToggleSecondary2DAxisTargetAction_m1CCD6C28C46BF9C27B15401A1355C8C5E2E26438 (void);
// 0x000005CD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeAxis2DAction()
extern void XRDeviceSimulator_SubscribeAxis2DAction_mEE8886128181FBFBE8D5E8D3FECD7113C6948E65 (void);
// 0x000005CE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeAxis2DAction()
extern void XRDeviceSimulator_UnsubscribeAxis2DAction_mB2BDDB6B635540B39042D50D88A7C4C5A4655881 (void);
// 0x000005CF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeRestingHandAxis2DAction()
extern void XRDeviceSimulator_SubscribeRestingHandAxis2DAction_m2DA465BEB5D3BC636A0763A67074AFC5B49C035C (void);
// 0x000005D0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeRestingHandAxis2DAction()
extern void XRDeviceSimulator_UnsubscribeRestingHandAxis2DAction_m049D9B71FC3F41F73A483FB1FC13B2FBE13CC71F (void);
// 0x000005D1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeGripAction()
extern void XRDeviceSimulator_SubscribeGripAction_m773AECCB7C7087A87FED8FE5ACC189C56A0DE1F1 (void);
// 0x000005D2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeGripAction()
extern void XRDeviceSimulator_UnsubscribeGripAction_mA7C1B8224432C0CC38C7F7C4608D12FB8CD39B55 (void);
// 0x000005D3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeTriggerAction()
extern void XRDeviceSimulator_SubscribeTriggerAction_mD4FFFD0B4430797981D289C9CCB8640D458D4E67 (void);
// 0x000005D4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeTriggerAction()
extern void XRDeviceSimulator_UnsubscribeTriggerAction_mDCCDCC52FA565A48D46E1E825E402B1689C317B5 (void);
// 0x000005D5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimaryButtonAction()
extern void XRDeviceSimulator_SubscribePrimaryButtonAction_m737222A31E00B58AB25C9D66A43094221EF34E63 (void);
// 0x000005D6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimaryButtonAction()
extern void XRDeviceSimulator_UnsubscribePrimaryButtonAction_m0F1F148088CA510E47BEBF7625A904CACE959C76 (void);
// 0x000005D7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondaryButtonAction()
extern void XRDeviceSimulator_SubscribeSecondaryButtonAction_m442B2AD6E5F329CD28A0E570CB7C0101945F81CD (void);
// 0x000005D8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondaryButtonAction()
extern void XRDeviceSimulator_UnsubscribeSecondaryButtonAction_m9B5B23C64ACA719403B3B882637878286D955B95 (void);
// 0x000005D9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMenuAction()
extern void XRDeviceSimulator_SubscribeMenuAction_m3EEF1010C6EED412197B1466FB1D72FBA0E6C674 (void);
// 0x000005DA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMenuAction()
extern void XRDeviceSimulator_UnsubscribeMenuAction_m30A656E00AF44A7911608FEEF38A74A898B66748 (void);
// 0x000005DB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimary2DAxisClickAction()
extern void XRDeviceSimulator_SubscribePrimary2DAxisClickAction_m73C15F34F2E665BFD5AFB5A3F925C4F4665BE4BA (void);
// 0x000005DC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimary2DAxisClickAction()
extern void XRDeviceSimulator_UnsubscribePrimary2DAxisClickAction_m5A00374DB38D3DFDD92A68A66981492ECBC03977 (void);
// 0x000005DD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondary2DAxisClickAction()
extern void XRDeviceSimulator_SubscribeSecondary2DAxisClickAction_mAB5934DACF09F037E4CC2619FE5066F3CDAB3064 (void);
// 0x000005DE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondary2DAxisClickAction()
extern void XRDeviceSimulator_UnsubscribeSecondary2DAxisClickAction_m6CAA519997ABEF342FF74F558BD6E4B82314A1D5 (void);
// 0x000005DF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimary2DAxisTouchAction()
extern void XRDeviceSimulator_SubscribePrimary2DAxisTouchAction_m3EA13486E47B0828641D9D732811B23C7AEA185F (void);
// 0x000005E0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimary2DAxisTouchAction()
extern void XRDeviceSimulator_UnsubscribePrimary2DAxisTouchAction_m26F2A35ADB7A6394FE2F471ED0FC609994D23638 (void);
// 0x000005E1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondary2DAxisTouchAction()
extern void XRDeviceSimulator_SubscribeSecondary2DAxisTouchAction_m0A7ECAD84ADC2A59BDD0973301D18B6E750F706A (void);
// 0x000005E2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondary2DAxisTouchAction()
extern void XRDeviceSimulator_UnsubscribeSecondary2DAxisTouchAction_m7A4A35BC2507747E49F663B2B2DC316907E0AF06 (void);
// 0x000005E3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimaryTouchAction()
extern void XRDeviceSimulator_SubscribePrimaryTouchAction_m180904DB9DBECD51EE7F7BA000A219F824958A8D (void);
// 0x000005E4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimaryTouchAction()
extern void XRDeviceSimulator_UnsubscribePrimaryTouchAction_m77AB572F4913323761FAC52E5E27CC0D23CAF31C (void);
// 0x000005E5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondaryTouchAction()
extern void XRDeviceSimulator_SubscribeSecondaryTouchAction_mE6BCF08D72F50509E2B598FD76D5E5B2ED3941C2 (void);
// 0x000005E6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondaryTouchAction()
extern void XRDeviceSimulator_UnsubscribeSecondaryTouchAction_mCB2EDC912046BC4D6AA6F665D78D93BDE12B4E2B (void);
// 0x000005E7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardXTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardXTranslatePerformed_m67D9C81C79322E88AAB39CE84C37FAAB7C91F80A (void);
// 0x000005E8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardXTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardXTranslateCanceled_m9D3DEEA004C755F7EB437C73FC0F1C93C2C5CE2A (void);
// 0x000005E9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardYTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardYTranslatePerformed_m3C16C270EE32CF28406AD517DCDD12CCFA923779 (void);
// 0x000005EA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardYTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardYTranslateCanceled_mB7E662108181FA0EF68D552AB64A72E8D0E7B807 (void);
// 0x000005EB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardZTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardZTranslatePerformed_m31B9D2B07CB305046B816D52FBD7A9BC840C07A2 (void);
// 0x000005EC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardZTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardZTranslateCanceled_m10F647E991EEE77F776A8788F96E7DC382F23AED (void);
// 0x000005ED System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateLeftPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateLeftPerformed_m3F5E6822F34708EFAD23751B58722EEE6DDD26B1 (void);
// 0x000005EE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateLeftCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateLeftCanceled_mD53A7A680C685A7F047A3F7DB78D49DCF930A212 (void);
// 0x000005EF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateRightPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateRightPerformed_m162F4EDB2B1A864153EC1CFACDF4B17F1E62A062 (void);
// 0x000005F0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateRightCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateRightCanceled_mA285F03C11962E9ED786294DEADD6E27EBF0E526 (void);
// 0x000005F1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleManipulateLeftPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleManipulateLeftPerformed_m472E7851F37DF7DA7D06695217A0925D431AF029 (void);
// 0x000005F2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleManipulateRightPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleManipulateRightPerformed_m600CBEB0CD83C7A78622BD681EE9442050210961 (void);
// 0x000005F3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateHeadPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateHeadPerformed_mE3CDEB5905751F0DAA2BC8813DDFE12411A5173B (void);
// 0x000005F4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateHeadCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateHeadCanceled_m123048DD036F30B8FEB3FE3FDBA0201F245522A1 (void);
// 0x000005F5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseDeltaPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseDeltaPerformed_mA0D337A02CEECFAEC4B8E92F6B8987FE9AA58991 (void);
// 0x000005F6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseDeltaCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseDeltaCanceled_m6B92B3B296A3F4D9DA6685B648FE94FE0D26AD33 (void);
// 0x000005F7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseScrollPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseScrollPerformed_m4341955EE336EE6BD8405E7250259E1EA80C6371 (void);
// 0x000005F8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseScrollCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseScrollCanceled_m7DB823B684CA455943B87407CD2EB800D546FB95 (void);
// 0x000005F9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRotateModeOverridePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRotateModeOverridePerformed_m4DD6A28D80710853E0097DE1F3909BB053E19F07 (void);
// 0x000005FA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRotateModeOverrideCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRotateModeOverrideCanceled_m75BEAEB4D125418AE7393765262251BEA29D4605 (void);
// 0x000005FB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleMouseTransformationModePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleMouseTransformationModePerformed_m62CC1589FEF4D4D2931E28CED20AD419F7673594 (void);
// 0x000005FC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnNegateModePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnNegateModePerformed_mF5A3FC1E7834584441A53DEF77D7A0A5B138C36B (void);
// 0x000005FD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnNegateModeCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnNegateModeCanceled_mF056E71CFCC8B0F48042B8A5522BA063DBCE2DBB (void);
// 0x000005FE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnXConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnXConstraintPerformed_mDDAE59658180A383E2BDCC8A429DC4EE620BB262 (void);
// 0x000005FF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnXConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnXConstraintCanceled_mF01C0548845D2119A9CAC33F8EB339E48E6BFCE0 (void);
// 0x00000600 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnYConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnYConstraintPerformed_m0173CD7EC54D58A438FFA16807AB2772EFB35853 (void);
// 0x00000601 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnYConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnYConstraintCanceled_m427318933BC81323C0AFDEE8C71B6F3B9BBB37B4 (void);
// 0x00000602 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnZConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnZConstraintPerformed_m4ED22AD9BBAB1AF16415EF0946B159F65A6C0CA4 (void);
// 0x00000603 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnZConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnZConstraintCanceled_m684DCF1B8E317BCCC6CE0CE4935D71FC5F50F289 (void);
// 0x00000604 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnResetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnResetPerformed_m9D12641FB8502A5B91E1B27339B0E7EE063B67F3 (void);
// 0x00000605 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnResetCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnResetCanceled_m1E37719FF57FDC428E2AFACEF4A20B14A3C2BF7A (void);
// 0x00000606 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleCursorLockPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleCursorLockPerformed_m8A1D0929190187D7B1CBF20FA5D4488DFD4ED011 (void);
// 0x00000607 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleDevicePositionTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleDevicePositionTargetPerformed_mCCFCF515D5BB98ADDF4E53CC9114399D9C082EFE (void);
// 0x00000608 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTogglePrimary2DAxisTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTogglePrimary2DAxisTargetPerformed_m62DFCC38E4E98931C3E8DF1712DA44467F833F83 (void);
// 0x00000609 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleSecondary2DAxisTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleSecondary2DAxisTargetPerformed_mE8CEB9D921E05D1BE58648DA93CD6C08F66805CE (void);
// 0x0000060A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnAxis2DPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnAxis2DPerformed_m0F66BD565DCFBC421C3BB74FB186A96107CD9252 (void);
// 0x0000060B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnAxis2DCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnAxis2DCanceled_mD1EC2441F41AAFB2895CA3A95E24971DE45EA5CB (void);
// 0x0000060C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRestingHandAxis2DPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRestingHandAxis2DPerformed_mA2E9B677E765ACA748E9A68BB96877A9C0FDB10F (void);
// 0x0000060D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRestingHandAxis2DCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRestingHandAxis2DCanceled_m93109CCE09FA2CAE73993D9E1A65365F0237AFD1 (void);
// 0x0000060E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnGripPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnGripPerformed_m45555D39BD72B048474024A7A7C7E9FB72F48AAE (void);
// 0x0000060F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnGripCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnGripCanceled_m6520B48935110A8C7F25B7A543575977A630C655 (void);
// 0x00000610 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTriggerPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTriggerPerformed_m6F547E9B665D0964E31965D8AD2716A78A6DC907 (void);
// 0x00000611 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTriggerCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTriggerCanceled_m283F4544B37B56773DACC9DD92DCF44CC0DF1EB3 (void);
// 0x00000612 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryButtonPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryButtonPerformed_m124F6723F67F2CACD4D1783DFA8273934404A1CB (void);
// 0x00000613 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryButtonCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryButtonCanceled_m95B43E0F3B270432403188607A54C6061EA1D794 (void);
// 0x00000614 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryButtonPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryButtonPerformed_m1B8DFE13115DB786568FB589127E3B9A01D2B4C9 (void);
// 0x00000615 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryButtonCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryButtonCanceled_m425BAA1805DBF8B055BB325F5B70A23762DAD197 (void);
// 0x00000616 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMenuPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMenuPerformed_mD1D644DFD0606C5BE4F51B67B1C915A5C262691F (void);
// 0x00000617 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMenuCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMenuCanceled_mC5FFC84ACA43297D3C309F5F601B2E3EE83AB20E (void);
// 0x00000618 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisClickPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisClickPerformed_m7CC2E6E040AA141EE326B11C109ECB28F730B30D (void);
// 0x00000619 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisClickCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisClickCanceled_m1010C0CC454EF35FBE04E2D7A93641FD32B493A6 (void);
// 0x0000061A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisClickPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisClickPerformed_m28CF38854844D89E2D46F7C4F1D258773C8FCA91 (void);
// 0x0000061B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisClickCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisClickCanceled_mF8567A7DC54E0C7FB585C1D05BD97920D2133A96 (void);
// 0x0000061C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisTouchPerformed_m56D605B3EB1ACF04F73A08E390BE24C8F0D56909 (void);
// 0x0000061D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisTouchCanceled_mBCC70F3EF5FADFCC4360CF9FD8B53597CD002748 (void);
// 0x0000061E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisTouchPerformed_mF91A7CE7A57BE193F3AA424D2AEC86C4A507E7FD (void);
// 0x0000061F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisTouchCanceled_mA9B90963F3E6F51981D0463D8E22FD2FA77E5EE1 (void);
// 0x00000620 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryTouchPerformed_mB2CEBD175DE3FF771A7553C85A562487B989606E (void);
// 0x00000621 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryTouchCanceled_m31AA5DACEDD6C2B97FB0F5086707C63D7779C82B (void);
// 0x00000622 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryTouchPerformed_m036545C71E058E00D72B1096497A772338C432FF (void);
// 0x00000623 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryTouchCanceled_m5707F4CBCEBD7C40AE36AB14DC2B01367A8FC61A (void);
// 0x00000624 UnityEngine.InputSystem.InputAction UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetInputAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_GetInputAction_m6A41B50DBE3CC7A7159E84D3A158C36560BB4AD8 (void);
// 0x00000625 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::.ctor()
extern void XRDeviceSimulator__ctor_m52F5FF6A90EBE423D0C4207CBEEEA28E00F01F50 (void);
// 0x00000626 UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxis()
extern void XRSimulatedController_get_primary2DAxis_m323C25A3929D29AFBF8D986CA6B39090B0908103 (void);
// 0x00000627 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxis(UnityEngine.InputSystem.Controls.Vector2Control)
extern void XRSimulatedController_set_primary2DAxis_m8E4DAC62428C65DAC69F41536D095ABC5CDC2F75 (void);
// 0x00000628 UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_trigger()
extern void XRSimulatedController_get_trigger_m6C857ADA82B60913A8AD0DF98DCF4F8E6181E087 (void);
// 0x00000629 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_trigger(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_trigger_m5147740FA56F49CAF973F53498D174346E824CF0 (void);
// 0x0000062A UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_grip()
extern void XRSimulatedController_get_grip_m49D414921BB9186AABE3BFD7337F539ADFD99379 (void);
// 0x0000062B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_grip(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_grip_m816763A0BC7ADF3E557635A0BEC4C3559889718C (void);
// 0x0000062C UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxis()
extern void XRSimulatedController_get_secondary2DAxis_m782E667D776EAC2A6AD8FD81F5FCD967B927E890 (void);
// 0x0000062D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxis(UnityEngine.InputSystem.Controls.Vector2Control)
extern void XRSimulatedController_set_secondary2DAxis_mC211E0FED3C0A7CD0E622CF4582811ED1AAB0397 (void);
// 0x0000062E UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primaryButton()
extern void XRSimulatedController_get_primaryButton_mBF42EE5D6CE008CB35B3C745A177F50906D44EFB (void);
// 0x0000062F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primaryButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primaryButton_m24B4C9D45B4CBD8AC1BAE51DAA81AAB1CBD3AC8B (void);
// 0x00000630 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primaryTouch()
extern void XRSimulatedController_get_primaryTouch_mD02E6C05E7172688D8CF560802F28A4AE8F336BA (void);
// 0x00000631 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primaryTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primaryTouch_m10B9B6B82FD96AF73C3C02B5246E1A678D393FFD (void);
// 0x00000632 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondaryButton()
extern void XRSimulatedController_get_secondaryButton_mEC8A3128207D76F501CAAB4D51E00449B3FF06B3 (void);
// 0x00000633 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondaryButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondaryButton_m00AD5FAD1FA7B3919F7D176896C7B206BE052E40 (void);
// 0x00000634 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondaryTouch()
extern void XRSimulatedController_get_secondaryTouch_mA58DDFCAF1B7F59632CBF3DAF3C86BDAAC04625A (void);
// 0x00000635 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondaryTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondaryTouch_m062383677858ADB61358AC650344FBA07F08CEA2 (void);
// 0x00000636 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_gripButton()
extern void XRSimulatedController_get_gripButton_m455A8F80FEBC9B529B5C0EC1CDA91E47C19684BF (void);
// 0x00000637 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_gripButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_gripButton_mBDE3A20238B93A3615C50CEBEB339E3E7D440093 (void);
// 0x00000638 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_triggerButton()
extern void XRSimulatedController_get_triggerButton_m9528934FB7246F09CD565040974B5A30EBAC64CE (void);
// 0x00000639 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_triggerButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_triggerButton_m47FEB0AC89CEFA97D7527A2213FCAA7193FC2EF1 (void);
// 0x0000063A UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_menuButton()
extern void XRSimulatedController_get_menuButton_mDC50D9A568D267AC711415D2CDBC0A59224D4E49 (void);
// 0x0000063B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_menuButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_menuButton_m732B18585FE0BA10717DCE82FCBEC7E05A403069 (void);
// 0x0000063C UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxisClick()
extern void XRSimulatedController_get_primary2DAxisClick_m444F8F703D81E6413A023D5CB12E393B36D83D23 (void);
// 0x0000063D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxisClick(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primary2DAxisClick_m42B7BA9549D375EAE2ADC395DA06C7AF1ED0B839 (void);
// 0x0000063E UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxisTouch()
extern void XRSimulatedController_get_primary2DAxisTouch_m1F472FC37AE6CC0055414447E6ADAA21AD735A9F (void);
// 0x0000063F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxisTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primary2DAxisTouch_mA9BEEE51984E1995812A1BA0402EEBA3EACE490A (void);
// 0x00000640 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxisClick()
extern void XRSimulatedController_get_secondary2DAxisClick_m5FF8AB05F3DFEF4B1711F525A04D749A6F09C731 (void);
// 0x00000641 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxisClick(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondary2DAxisClick_m20FD0ADE245DEF6B0C97CACC7B09FA89CF68D464 (void);
// 0x00000642 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxisTouch()
extern void XRSimulatedController_get_secondary2DAxisTouch_m53965D0BC06C819C456315D25533E351825C1A46 (void);
// 0x00000643 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxisTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondary2DAxisTouch_m47F79E33622C064FA49423AECE66E22E5BDECF82 (void);
// 0x00000644 UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_batteryLevel()
extern void XRSimulatedController_get_batteryLevel_mAA0601728C444A0AEE5490035B1512F54D9630FE (void);
// 0x00000645 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_batteryLevel(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_batteryLevel_m428ADCAB02761E7FCF0732A51672B9B7ED1B3F88 (void);
// 0x00000646 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_userPresence()
extern void XRSimulatedController_get_userPresence_m3FF21CACBBF62F3D231CC583629A70A7EC0EDE4E (void);
// 0x00000647 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_userPresence(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_userPresence_mB31695E2AC927F2AC1E4501ADF8148A81F253900 (void);
// 0x00000648 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::FinishSetup()
extern void XRSimulatedController_FinishSetup_m3FF9228BA9B5BD9506F824E708D8A088EFB45D2A (void);
// 0x00000649 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::.ctor()
extern void XRSimulatedController__ctor_m832C2B3ACDA212CABE445F8248960849A7CF2C58 (void);
// 0x0000064A UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::get_formatId()
extern void XRSimulatedControllerState_get_formatId_mE026B646A8286F1AB49928BA2121BA41E41E22AC (void);
// 0x0000064B UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::get_format()
extern void XRSimulatedControllerState_get_format_mBC60834E041568E9DDE493F77DAC0BFFF9CEADE3 (void);
// 0x0000064C UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::WithButton(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.ControllerButton,System.Boolean)
extern void XRSimulatedControllerState_WithButton_m1B3D8EB3C81BABA0BCE4DC52632F43C8617AE6CF (void);
// 0x0000064D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::Reset()
extern void XRSimulatedControllerState_Reset_m524D26C8145A95198ABEFBCE125E5681436FB793 (void);
// 0x0000064E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMD::.ctor()
extern void XRSimulatedHMD__ctor_m5A6C1A3D704B28FDB61A81A83BC05159C17EE9B9 (void);
// 0x0000064F UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::get_formatId()
extern void XRSimulatedHMDState_get_formatId_m9618D28EDCDB79B05B864195329B666C5D617E49 (void);
// 0x00000650 UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::get_format()
extern void XRSimulatedHMDState_get_format_mE598AF3AD93850E9C42AEB5BE7DC82BBDDF14844 (void);
// 0x00000651 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::Reset()
extern void XRSimulatedHMDState_Reset_mD47104BCF5DBB055F673EA4F7889819079B94406 (void);
// 0x00000652 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::get_pressPointOrDefault()
extern void SectorInteraction_get_pressPointOrDefault_mC48A3C5FEF778359655233D9CB76B99707DBD9E8 (void);
// 0x00000653 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::get_defaultPressPoint()
extern void SectorInteraction_get_defaultPressPoint_mC8BA99741478D69AC5AD20C53A2563B269A50703 (void);
// 0x00000654 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::set_defaultPressPoint(System.Single)
extern void SectorInteraction_set_defaultPressPoint_mE149D21B50B09B456919B022D214762DF1E738B9 (void);
// 0x00000655 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Process(UnityEngine.InputSystem.InputInteractionContext&)
extern void SectorInteraction_Process_mC8FC7CDD31ADE884395B0F2CCE3445B83E04DCD2 (void);
// 0x00000656 System.Boolean UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::IsValidDirection(UnityEngine.InputSystem.InputInteractionContext&)
extern void SectorInteraction_IsValidDirection_m216A8C540C569A703F921ACB6E62B56C75C271DD (void);
// 0x00000657 UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction/Directions UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::GetNearestDirection(UnityEngine.XR.Interaction.Toolkit.Inputs.Cardinal)
extern void SectorInteraction_GetNearestDirection_m33380BA3A20657BFA06F0CA7FB32EE15D48BE9FC (void);
// 0x00000658 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Reset()
extern void SectorInteraction_Reset_m19D8A80BE1E89AEE8C7BF9F16B4B44BB13424D99 (void);
// 0x00000659 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::.cctor()
extern void SectorInteraction__cctor_mE52D92B20C725EF6ED77927E99C5C28F6C50D6B9 (void);
// 0x0000065A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Initialize()
extern void SectorInteraction_Initialize_mE02B33790B23EABF1D52D8C95E422CD033C90EDE (void);
// 0x0000065B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::.ctor()
extern void SectorInteraction__ctor_m96B44EF9FE2E61A02C49FEBE2127771D40538BB1 (void);
// 0x0000065C System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotationInteractable::.ctor()
extern void ARAnnotationInteractable__ctor_m42B79205F4D0AB0C8CDA30E59428F8E3D820CE51 (void);
// 0x0000065D System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::.ctor()
extern void ARBaseGestureInteractable__ctor_mD923A2DF3AA56F3060B2C96084B123A51DFE5164 (void);
// 0x0000065E System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::.ctor()
extern void ARPlacementInteractable__ctor_mBD9DBE1093318B6E8A3D673361774C0396B93805 (void);
// 0x0000065F System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::.ctor()
extern void ARRotationInteractable__ctor_m161C23C6C6E9AB51E26694B1CDD374D38492145F (void);
// 0x00000660 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::.ctor()
extern void ARScaleInteractable__ctor_mF7019A322AB2FB8C2DD91DAE3F59A02FC92CB228 (void);
// 0x00000661 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::.ctor()
extern void ARSelectionInteractable__ctor_mD263DD55CC459C55DA650F4B8DCCA90F15854D21 (void);
// 0x00000662 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::.ctor()
extern void ARTranslationInteractable__ctor_m1B370E054C8F454B3B7A3931F044CCFB8DA29709 (void);
// 0x00000663 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::.ctor()
extern void ARGestureInteractor__ctor_m1A489A1BD7E5DCBAE1409FB59E479620257CDA1E (void);
static Il2CppMethodPointer s_methodPointers[1635] = 
{
	EmbeddedAttribute__ctor_mAC9C3449B2C8D4A1D89A8CD60B6B4EBB909A549E,
	IsReadOnlyAttribute__ctor_m8B9BA0350D77FDDE0896361AA2369B9EA7707B80,
	InputHelpers_IsPressed_mB00997B52B6344649223F8EADB92DDEDB538C756,
	InputHelpers__cctor_m548375FA7CA8F39D5314E887BFFBE3235274F7F2,
	ButtonInfo__ctor_m3CD43D1CD1FBA164B697DC217C9E21B157386DE3,
	ActionBasedController_get_positionAction_m0AADCA1A0CF65DC7C9A1F61D70E6B42EE356DEA3,
	ActionBasedController_set_positionAction_m3DD4181DF028697C4E759CE2AA43CE3ADA29D414,
	ActionBasedController_get_rotationAction_mB57BAAEDBC922F5FC8D6B8D4C2713F64988FDC25,
	ActionBasedController_set_rotationAction_m3152E9F30F4B13D7093A0F61A5A8C9552558B37B,
	ActionBasedController_get_selectAction_m6ADEA0B73AE3166CF6B02388146ECC1F81A1682E,
	ActionBasedController_set_selectAction_m4E612329CD70CC6362F3B016B90B5FCF4BECDB35,
	ActionBasedController_get_activateAction_m200FF238E6977609B538D02C91BD99745948BD65,
	ActionBasedController_set_activateAction_mE7BD4D80E6E3F59A377528DECBDCFE330E78BF40,
	ActionBasedController_get_uiPressAction_mD20BCF7C349822D5AFEA00ACB8B7DB262541E6AC,
	ActionBasedController_set_uiPressAction_mEFA630BEFEFFDA66C597D6F8A18D9BF019626B79,
	ActionBasedController_get_hapticDeviceAction_mC7F3DCF6C1252AFDBD3E79CF6BFAE2521DB6BE36,
	ActionBasedController_set_hapticDeviceAction_m18609366C2182371B1129EE6760EF120BF4923E1,
	ActionBasedController_get_rotateAnchorAction_m734CD5E7AD3A576AA923AD4BBD6F33D0D9860BFD,
	ActionBasedController_set_rotateAnchorAction_mD34C2A5E9330D248ECF49DE278EA165A78236FBE,
	ActionBasedController_get_translateAnchorAction_m0BF8F391A2E284BD8D9C394B6A779B2959AD822E,
	ActionBasedController_set_translateAnchorAction_m0DA2728F63003878AD450F04198F3DD925FA18D8,
	ActionBasedController_get_buttonPressPoint_mD9B5EFC9425E80B5F0D791F0CE53C931B4091C84,
	ActionBasedController_set_buttonPressPoint_mE1A59AEF71617036B254A944EC891770B835F9F8,
	ActionBasedController_OnEnable_m6C33FC4A4969963F02A25EBB371A222281FDDB99,
	ActionBasedController_OnDisable_m069B9518CAC115BB8E238E9B70054A5A4A1D28D8,
	ActionBasedController_UpdateTrackingInput_m568B22E088E8F01F7BFC85B7976833A9297856B8,
	ActionBasedController_UpdateInput_m0B3DDE7A00DE36ADCF14E08D29F62F78A2FEF82B,
	ActionBasedController_SendHapticImpulse_m9F724BBED89194C5CAE2732B193A118BD1D762A9,
	ActionBasedController_EnableAllDirectActions_m8C9F714E9D9C9DBE082A4D88D6DE707ABBAE3441,
	ActionBasedController_DisableAllDirectActions_m1EBA07E5B1414C9D2493D21C5996E2DFC05E587D,
	ActionBasedController_SetInputActionProperty_m98D4EFE06FF96DBA4068B7E020270C2A35D231A4,
	ActionBasedController_ComputeInteractionActionStates_m6B8D5FE7B0DFF2E69916825EBD28145DFF95C01B,
	ActionBasedController_IsDisabledReferenceAction_mCF9D764FF310B57381355CA4FF2E30480AA20449,
	ActionBasedController__ctor_m0C9570FA19BF70B4A388ACA2CAA279E6AC263B1D,
	ActionBasedController_U3CUpdateInputU3Eg__IsPressedU7C41_0_m4C6B3A82BE1DB5BBC3BA0677F86EA30EAE4B120F,
	XRBaseController_get_updateTrackingType_m5617506ED652752BB55754ABA4DE8C2E894C14C4,
	XRBaseController_set_updateTrackingType_mB6BCA78BFDE129C3F9D2CA469D4BB764C5CACF55,
	XRBaseController_get_enableInputTracking_mF608E1C27CF0A0910FB841F7158E1867DD1599AD,
	XRBaseController_set_enableInputTracking_m89ED425F3D4A6831A52999D5FC1E4948E0A4F5C9,
	XRBaseController_get_enableInputActions_mF6250B1868B5D622924B6CDF8BA3596C1068FDC2,
	XRBaseController_set_enableInputActions_mDA19367438E10EF377988F45C871F22E38D737D8,
	XRBaseController_get_modelPrefab_m87435DFA1E0F3B408894381BDDDC1F5C484BB1E2,
	XRBaseController_set_modelPrefab_mDE3FFA7597E30C78EF0E2F6231F2BE66A40E859E,
	XRBaseController_get_modelTransform_m58AD96452188704A96861A17491678489CF3F523,
	XRBaseController_set_modelTransform_m820A35F61B577A9D344E07DA5CD64B1B0A134467,
	XRBaseController_get_animateModel_m5F530843D2729A625443EED53D8099E4C15742BE,
	XRBaseController_set_animateModel_m3B2EEAC7737A4526ED3631644DA2E796DBD60A06,
	XRBaseController_get_modelSelectTransition_m13743153B2E41C5AC23F7FC47B140C25C55F1824,
	XRBaseController_set_modelSelectTransition_m20BD140741F5672C0827EA2CDBAB99BAC863CDE3,
	XRBaseController_get_modelDeSelectTransition_m17385AD0220F07F344061A9F7B0753A3E7401DA1,
	XRBaseController_set_modelDeSelectTransition_m2A32CD331F3268D4AACC295F0E201E7DE947C5A7,
	XRBaseController_get_anchorControlDeadzone_m9F9DBCEC323C94B24516AE0FF52E40A1E627F4C7,
	XRBaseController_set_anchorControlDeadzone_m41337A9B4A24CAFE99F9690F34A6612D895221D3,
	XRBaseController_get_anchorControlOffAxisDeadzone_mC1893C2994AFFF6BD8AA4C5826C2D4BEF811BAD7,
	XRBaseController_set_anchorControlOffAxisDeadzone_mB1363FD2B8EC8080427D152610508FE63BE33495,
	XRBaseController_get_selectInteractionState_mBDF090DC9419A5EF00CFA30A2EC986DCEEDF739E,
	XRBaseController_get_activateInteractionState_m9AFCE26B34A251949B7D74148DA864067F01F9CB,
	XRBaseController_get_uiPressInteractionState_mC7F202067BF61FA31D26D27874EE3BB4F3958620,
	XRBaseController_get_hideControllerModel_m8AD5F3E01DC84FB16CE4D6026B706320723AF0E4,
	XRBaseController_set_hideControllerModel_m26D1BC994A9855F0B3C1A25BC999FEF71E557AC8,
	XRBaseController_Awake_m8B420246FD368F0B65C7D8C98F70954802F495E2,
	XRBaseController_OnEnable_m02CFDA51FD8E7690CA0086BAE7FA2D12E61674AB,
	XRBaseController_OnDisable_mA62B8654196C51B7738936EA29FB839F2C3E1DA8,
	XRBaseController_Update_m358201A21E9EB4CC20F928066F0BDBB6C56CFE0E,
	XRBaseController_PerformSetup_m31B932595CFD9A5F21F8B97CEB9519D1A303F2CD,
	XRBaseController_SetupModel_m0585E51D87E28C6A808E15ADFF8EFCDE99BBF457,
	XRBaseController_UpdateController_mF301729BB5049513E7C212730AA649C72FD25AE4,
	XRBaseController_OnBeforeRender_m1ADEAF2008D945D2DDC07C0A03CB52F54F257722,
	XRBaseController_GetControllerState_m45F78F6C3292FC3293300D622AF88618FA7712B2,
	XRBaseController_SetControllerState_m2AF4981ECD219E50C89BFD37D1E95E40811DE0C9,
	XRBaseController_ApplyControllerState_m1EA076044D7E7D03D520B54D4A67C4B2AF7B8A9C,
	XRBaseController_UpdateTrackingInput_m1F8E54931C67A201C3E0A08BA742C5FD11FE844C,
	XRBaseController_UpdateInputInternal_m57AE52F3C07E29C2FFE882773F0E2A6E0202F0BB,
	XRBaseController_UpdateInput_mCC315B351B14AB1B3D9D16B41FECEFE4FE0903B6,
	XRBaseController_UpdateControllerModelAnimation_m3490A339D3385CC306C28A9E94A8B2C0D5CD9CF4,
	XRBaseController_UpdateControllerPose_m69E9DC66E14A7400335E32BC2E22F5762F1711DD,
	XRBaseController_SendHapticImpulse_m01B5416F7A4FD009E2D1D75B9891F0E8F20FDFDF,
	XRBaseController__ctor_m038B0CE7FE2B33C2127099D7F4D22749F83FE8D3,
	InteractionState_get_active_mEB70F6F01B332BF518B3F7D0048614DF3D11416D,
	InteractionState_set_active_m4D33BA01AC08B427995FB81C61AADE55059E5D8E,
	InteractionState_get_activatedThisFrame_m3805CFB50DE51865E8B0CF64EAD512E6535F5990,
	InteractionState_set_activatedThisFrame_mC09EBD51CFF932E8EF2D2234D98F6F4A68220C04,
	InteractionState_get_deactivatedThisFrame_m33159255C5B5A45C78F331152CAD09878CDBECC5,
	InteractionState_set_deactivatedThisFrame_m6463CD864EB7142897A97F8C32485016A6282369,
	InteractionState_get_deActivatedThisFrame_m77D75E7C5865BE2C111506E4CC5F090AE7F813DB,
	InteractionState_set_deActivatedThisFrame_m739E5BF6021D03E5C2D9BA5AD6902AD1D2AA6156,
	InteractionState_ResetFrameDependent_m81E03E441EFBB763DC1DB870345606C2CFB85996,
	InteractionState_Reset_m7144B5C32B6E7118DA7048CC9A5FE9B3A30E3656,
	XRControllerState__ctor_m614CC3405B369D91A759FF9A4972B96EC7B997D7,
	XRControllerState__ctor_mE65319B73768784FCDB2B637AE4F3DFA410F593D,
	XRControllerState__ctor_mDA85D68054385D4727F140A8E1CD38953573F18D,
	XRControllerState_SimulateInteractionState_mD9BD85F6531A81B8F01FA1232076872754CFBDDB,
	XRControllerState_ResetFrameDependentStates_mFA9DF9BFA158AD761B225BCA93D76D81111487BE,
	XRControllerState_ResetInputs_m7EAB3D35A24CAD36078397F16352407C516D1441,
	XRControllerState_ToString_mA21AA8A881F229A4607F46B88AA145D1CD47F57A,
	XRController_get_controllerNode_m54C0C4162BB973DB887DD1ECF3A7A0E56655BA46,
	XRController_set_controllerNode_m13905CA96B3F68C853691AD1E38BEF45ECA859BB,
	XRController_get_selectUsage_m7FD077238F16FEC9A1CF4B4B9C0CD50021A8CB25,
	XRController_set_selectUsage_mD6848C9CBB851F850B85A636FD6438B92380451E,
	XRController_get_activateUsage_m2FB0740C8E4F85ACC3842BFC97B34DCABAC816F3,
	XRController_set_activateUsage_m0B417D2EC47E06F546D35E329544587349D91BFA,
	XRController_get_uiPressUsage_mB0EE585B594A385F1A3296DC30FFA4B22639B335,
	XRController_set_uiPressUsage_m6BEB77B69F61E2A5D5E7FD174F4F048AA53DC88B,
	XRController_get_axisToPressThreshold_m65C5EA04847A1D5F41BFCC3D6ABF90EA310CC571,
	XRController_set_axisToPressThreshold_m865B390F6B0CEE1E850760BE2900A0021290C973,
	XRController_get_rotateObjectLeft_m28EBEE652169242B46BD46EDAC6C15547E786633,
	XRController_set_rotateObjectLeft_m5713AAF2B3F7058207C486299173189F6075846F,
	XRController_get_rotateObjectRight_mF5F44ECAF1C5D48483549C1950F0F222B58B16B1,
	XRController_set_rotateObjectRight_mB7E16FA470B26434C01C9674D56AD094BA7D8F57,
	XRController_get_moveObjectIn_m0E91BDC51941009816B19343CEDE21AA32D6611E,
	XRController_set_moveObjectIn_m6A51FB0FB29FA121A92B693CAA40B11C8217E299,
	XRController_get_moveObjectOut_m9CB4766D0202BFE57668C449121551DF09B24714,
	XRController_set_moveObjectOut_m2F816B3C99BCE961C233FE216A534CE5142AFA07,
	XRController_get_poseProvider_m80650DFEEDD4A1151248C71081FFAEA20C5D05D3,
	XRController_set_poseProvider_mE40E2D1BAA62CD70BC69081C052AF6FCF572938F,
	XRController_get_inputDevice_m4CC8E85AD90CF53E7620EF97C4A96E7C925C622A,
	XRController_UpdateTrackingInput_m8E43C8418966B0FE73EAEF9F190D97B7A1589A39,
	XRController_UpdateInput_mEED730BC2C5E30789F0C2254FCC317EB1F2F9B15,
	XRController_HandleInteractionAction_mEEDCEF64135CD4F98C84D452490D67E65F57CA13,
	XRController_SendHapticImpulse_m9C734D7336276A6C455E6BE93F4D5178209A7598,
	XRController__ctor_m88DB4C4C3D0C68CB314F15CA017C275FD6FB46B3,
	XRControllerRecorder_get_playOnStart_mBA5F968462B33ECC485445E339A4295739E1409D,
	XRControllerRecorder_set_playOnStart_m1F34C285B92D68751506B22056753C141B9A75A3,
	XRControllerRecorder_get_recording_mBB8CD5A9A982F39C1C7B68F2E1FC93C48C1DEE2C,
	XRControllerRecorder_set_recording_m4542D06A9AFFB6B7D9B963FF72B81B016045772E,
	XRControllerRecorder_get_xrController_mE9F25207F8F79CA5A85A0A0BF87D423B92A269BE,
	XRControllerRecorder_set_xrController_mA877E3E528387AD4BDF5A2206C4D1BFD9802A30D,
	XRControllerRecorder_get_isRecording_m0B796286A9F90713BBEE260AEF189402A11E569D,
	XRControllerRecorder_set_isRecording_mAF60918F432FA46245466ADC744B15BEA313AF64,
	XRControllerRecorder_get_isPlaying_m9DEEF9C2ACC9A9CEEF86BECD315EC315DFF07E18,
	XRControllerRecorder_set_isPlaying_m68BEFD3E2655B3C95D62555B4AF9C48D740A8627,
	XRControllerRecorder_get_currentTime_m1B27ABF4F274AD624F1BF0F6EE2C5021B77E333F,
	XRControllerRecorder_get_duration_m239BA50A898ECE55544CFA3D820B653A49CB5EEC,
	XRControllerRecorder_get_recordingStartTime_m1AE42301A5D3E07A69EFEFC685AEAEBA1CB08ED1,
	XRControllerRecorder_set_recordingStartTime_mC65BE1B8434FADD1F9C4C1082F0D92EABA3174B8,
	XRControllerRecorder_Awake_m7162AACDD8D0A635DD964D591160CA87BAE2D921,
	XRControllerRecorder_Update_mA6E3D2E4212BFECAA0DCF8F7CBDE127A8D19E41B,
	XRControllerRecorder_OnDestroy_m05EAB4CB3182F4CEE71EA3D5A1D26D7465459AE7,
	XRControllerRecorder_ResetPlayback_m6861367E8F0B1FC50BDFDA33C33C32E8F5F65F6B,
	XRControllerRecorder_UpdatePlaybackTime_mEC0D9F0AE8C6D578C544BFB20E90A6FA6C077CDA,
	XRControllerRecorder_GetControllerState_m93FB8795A7424522C5F4FE53D9A2C92CFE33502A,
	XRControllerRecorder__ctor_mD93981DBDE451E33495328CC4A769CA0F9EE0D4A,
	XRControllerRecording_get_frames_m06617405971DCF6D72348E90FF67B4D0619CCAA3,
	XRControllerRecording_get_duration_m1D8A6A96023DE4C3C4831A84C0F90005F507AB8F,
	XRControllerRecording_AddRecordingFrame_mBD57B7658FEB9AE284C37B5D0FDFBA64A0EB3FBA,
	XRControllerRecording_AddRecordingFrame_mB502408F2B591C1F15E886821703DC20F9F67BD8,
	XRControllerRecording_InitRecording_mA96B431A3D692EA4FBE899E6EAC5BE4F51E80488,
	XRControllerRecording_SaveRecording_mF6C7E8B317AECEE8993ABEB9E39BDE2F2373689E,
	XRControllerRecording__ctor_m4BDF7F9C31E84DC26B6348A9F93CE7A3A133B682,
	XRTintInteractableVisual_get_tintColor_mF4CFC0CD22080D5F34611CFAC029AEFDEED98F6D,
	XRTintInteractableVisual_set_tintColor_m4DA3C1E2DE29E73DC64ABCE44994B6B7EF69EBEC,
	XRTintInteractableVisual_get_tintOnHover_m581859C1FD7E763BBE1BA8B8F5414A7F7C4A5C1F,
	XRTintInteractableVisual_set_tintOnHover_m6FF161A29E321C3C4F609E3ACDF4EA2DA0033A3A,
	XRTintInteractableVisual_get_tintOnSelection_m711A01F086697C23C9B833C4B3A31A3E76767556,
	XRTintInteractableVisual_set_tintOnSelection_m80091389BD85C3896B397443D1AE43CB6ADFFFCA,
	XRTintInteractableVisual_get_tintRenderers_m9F1B0E0FC957ECFEA30D3E7DD19F0F9E74567232,
	XRTintInteractableVisual_set_tintRenderers_m1B47C2A8E5559448730415A816EF14B0FA6D8570,
	XRTintInteractableVisual_Awake_m21662E7AD0A9674B11DF6999B2A02FFBBBAC7F3A,
	XRTintInteractableVisual_OnDestroy_m7EAD174B82B295D281F9F1E1E1CA41D91602D58C,
	XRTintInteractableVisual_SetTint_m387BF4E8F18AF3DE52CCDCFC1FB187934DF7549F,
	XRTintInteractableVisual_GetEmissionEnabled_m5B7E90A1193C870C5744FFA3A4B47CD25CBC880C,
	XRTintInteractableVisual_OnFirstHoverEntered_m5B02D3FFD8CB35FDFABF9D4CF9A5B9469363EDFF,
	XRTintInteractableVisual_OnLastHoverExited_mA54347833D6CB963BA0CAD89D9AE3072BE61F2BE,
	XRTintInteractableVisual_OnSelectEntered_m0AB2BE5502FBB496CC36DD03D2AABB7BCD4C4784,
	XRTintInteractableVisual_OnSelectExited_mC389F628E075BBB25472D02EBD03D1F01AFCC1DD,
	XRTintInteractableVisual__ctor_mFFFDF785AE0E373B77DB4BD0E36431E15A09169A,
	XRTintInteractableVisual__cctor_mDF7CC141CF345A7C85A288849F8ECA50C053A2A7,
	ShaderPropertyLookup__cctor_mC12D9753B4F99040B1CD7196F89DAACD44FD460D,
	XRBaseInteractable_add_registered_m405585D459AD7261614D4137F18098F556495F8E,
	XRBaseInteractable_remove_registered_mB63ADB2C904C6550CB5A7C05A1400DB286264743,
	XRBaseInteractable_add_unregistered_m02354E663718C7E4E659433ABFBA57DFEEEDD838,
	XRBaseInteractable_remove_unregistered_m21193D4582EB0FE2FB93A889D0EE345D8066136B,
	XRBaseInteractable_get_interactionManager_m640673C7B55F3D01578509FB8966184EEA80EAAD,
	XRBaseInteractable_set_interactionManager_m7526D2E6F075DA81E69E857360A867410EFDEC57,
	XRBaseInteractable_get_colliders_m51A75DA8027253CB43306DADB8B17EE79A3EEF15,
	XRBaseInteractable_get_interactionLayerMask_m7F9D3EB36FAB586EA1C137010E3045226792BB9C,
	XRBaseInteractable_set_interactionLayerMask_m12FC8F91CB48383130353651110260B6D81240D3,
	XRBaseInteractable_get_customReticle_m254DEFD1CA160078C4A5B1890DCD97E14B202F70,
	XRBaseInteractable_set_customReticle_mE89A29C0E89957256AE35E9C81547B6E86204A88,
	XRBaseInteractable_get_firstHoverEntered_mA96938C6F42F633333D11B5767AA4FDF1DAE2CCC,
	XRBaseInteractable_set_firstHoverEntered_mAEB12A94B8A960A6796CB32F9ED509FD379060FE,
	XRBaseInteractable_get_lastHoverExited_m85254089D36C6F3C70096DE0F86F1F89E0C921F8,
	XRBaseInteractable_set_lastHoverExited_m5C1DCB0DAAEFEFBC445A3617A954131F2EF2EA38,
	XRBaseInteractable_get_hoverEntered_m9DE6B043E318823EC079966C1A3D47913011BE9B,
	XRBaseInteractable_set_hoverEntered_m6010B718168EF27561C85B168E0BEEEB0A799D7F,
	XRBaseInteractable_get_hoverExited_m19E497FF5E045CF29001BCA1BEC6C9722B7240A5,
	XRBaseInteractable_set_hoverExited_m359D425550007641982634A126C7C5B264D5C51F,
	XRBaseInteractable_get_selectEntered_mD07C4B7FF65C8DAACC8423411E57CC189A3B0055,
	XRBaseInteractable_set_selectEntered_m4E4622236FF91421D485D055FA579BD49759A903,
	XRBaseInteractable_get_selectExited_m1AE52740D4FB9B1D8BF94EFA5D65EA528574507F,
	XRBaseInteractable_set_selectExited_mF9F8780FC4098116CFE274A45F91768612998394,
	XRBaseInteractable_get_activated_mFBD1EB00DB391C3AA0EE5F1EFE6F8D7C33D28CFB,
	XRBaseInteractable_set_activated_m238C4CE2FC3C9FAA676A94F6E991C00C6F4B5293,
	XRBaseInteractable_get_deactivated_m4F3972C715EAD95AD9F0F3EEA7E223627D28357A,
	XRBaseInteractable_set_deactivated_m225ED5AA5CE8E4FB321AFDA74E3016AEE4C5BAA5,
	XRBaseInteractable_get_hoveringInteractors_m85B57133A957A0D23C49CACCA8B1291FE52AAE88,
	XRBaseInteractable_get_selectingInteractor_mBE9C84329FE5F872F9CC6652C6B8920F8EE538A7,
	XRBaseInteractable_set_selectingInteractor_m2E9E65FEB53E58D546B63D4B869D8EF3B66EB943,
	XRBaseInteractable_get_isHovered_m24852D564014E7068242CD43AB2393E0615D7FC6,
	XRBaseInteractable_set_isHovered_m50F19A45B41FDC5D6880D6554A05AFE6AC2F249E,
	XRBaseInteractable_get_isSelected_mB1CAAE9B24246EC0384C7ADF7C7716FAD729E4BD,
	XRBaseInteractable_set_isSelected_mFBB8634E77DA109306374B2F558C80700CA2E1D4,
	XRBaseInteractable_Reset_m66A78118F8165035FFC43ED016346F29D2074B49,
	XRBaseInteractable_Awake_mB55C0806771AD6C28848884D1787ABA4585BC79B,
	XRBaseInteractable_OnEnable_m956A8781750EF3EC35191B236F6D38F0E95E5D01,
	XRBaseInteractable_OnDisable_m3FB9E8412F412817BFAAE674E8CC946C8BCD7B72,
	XRBaseInteractable_OnDestroy_m780A3BA2640F5F6B52371DC5BB073D7B3581B478,
	XRBaseInteractable_FindCreateInteractionManager_mD4F04B3358C3B4A81516F04FD04665948FD43AFF,
	XRBaseInteractable_RegisterWithInteractionManager_mB086602EBFCC5972BEDA2F9CC49A4D43B42D5117,
	XRBaseInteractable_UnregisterWithInteractionManager_m040C9A4EC028908F81579E72AEBE566D96F43524,
	XRBaseInteractable_GetDistanceSqrToInteractor_m81DC0ECC9DD8C54BE8DAB4A52D8A8969C204E5A9,
	XRBaseInteractable_IsOnValidLayerMask_m54CF5103B30EC1A00669D6D86E9B75AB47658114,
	XRBaseInteractable_IsHoverableBy_m7CAE7F8BB3C31B880C0D7F8EB565801E4607AC30,
	XRBaseInteractable_IsSelectableBy_m2F3DDCB18B173222EC4152A3D948D896CA38556B,
	XRBaseInteractable_AttachCustomReticle_m696031810F15523598A081E29033396CB7671141,
	XRBaseInteractable_RemoveCustomReticle_m859DB0BE59BB130EE396D16C7913375ADB764668,
	XRBaseInteractable_ProcessInteractable_m8AF5B2051D82B42877967B45DE15DEBEB691125A,
	XRBaseInteractable_OnRegistered_mAF5DEA11FB57458DC26B9BA8692CF64A02252CE8,
	XRBaseInteractable_OnUnregistered_m77864664BC2E7CC3F8F92C89AE414BAD1FD0C0F8,
	XRBaseInteractable_OnHoverEntering_m5AC1A2CD2C69249D37F5922C6779CED67AABE99C,
	XRBaseInteractable_OnHoverEntered_m1DF5B7F9A891305A02E699C68E6A4D55CD074451,
	XRBaseInteractable_OnHoverExiting_m55E4C9FAEDD0C0B0C92DA20D8BCBA3D5F3D13F46,
	XRBaseInteractable_OnHoverExited_m4F245DAAE60CEBA1BA3C0D89EFA4CE0A9594633C,
	XRBaseInteractable_OnSelectEntering_mC0E59B356CA5FE4C6D908B94A1E76D8DB7FBAED7,
	XRBaseInteractable_OnSelectEntered_mC35925CA537E42534CC448ED295E997596C9FC27,
	XRBaseInteractable_OnSelectExiting_m21B9BDC19835790F7E4A5E247B061DC55639327B,
	XRBaseInteractable_OnSelectExited_m4F6ACED938C04F1AA99885D185AAB87D34C055AA,
	XRBaseInteractable_OnActivated_m9F38EB7FF264C451CD234E66BF957B998AA5CAF0,
	XRBaseInteractable_OnDeactivated_m122AF324746EF55FE98C9255FC6DEDB273CF1F2F,
	XRBaseInteractable_get_onFirstHoverEntered_mE9BC88ACDE186EC6AE93ECADE09EC7586E4EC14A,
	XRBaseInteractable_set_onFirstHoverEntered_m2AF37DBC7BC51270C8CEA3FF15C23FC8C230EC94,
	XRBaseInteractable_get_onLastHoverExited_m7F454EEB1CFB13B656C2730977091E78CB9088CF,
	XRBaseInteractable_set_onLastHoverExited_m3DBB6A6E92400C1285302AD612D84A3DDB1006F7,
	XRBaseInteractable_get_onHoverEntered_mBCAEB17B75AB1E1FF63D244E98C24D10396E14F0,
	XRBaseInteractable_set_onHoverEntered_mDE2D3D71FB700C220437012BE6DCFE76D1BDA3C3,
	XRBaseInteractable_get_onHoverExited_m7124A867CDEBF2D2DCEA09FF53DB1431AE7E6D4C,
	XRBaseInteractable_set_onHoverExited_m5C09C610896F32D5FFB99CFDDAE7EE25F8BF5F73,
	XRBaseInteractable_get_onSelectEntered_m505C109ACF65671CF86EF5491A439626F7377C95,
	XRBaseInteractable_set_onSelectEntered_mB97E680610149DD02EB476810EE72158D64C30F8,
	XRBaseInteractable_get_onSelectExited_m12A0F58B60CA091BB209F769C6F4A97C6AD52DC6,
	XRBaseInteractable_set_onSelectExited_m895693F67B6902E63596EAB4187E3A4CD645C5E4,
	XRBaseInteractable_get_onSelectCanceled_mC45E3F544D34B9E2E7F9345BE074DF0C8036F32F,
	XRBaseInteractable_set_onSelectCanceled_mD182B405C4B8FBEA94E3437853EF532BEF97B9D7,
	XRBaseInteractable_get_onActivate_m9504CF7605613F890AEC8329E14E8F33D6853C01,
	XRBaseInteractable_set_onActivate_mB94D4DA7F35314D1D9BED43CF29B4F8C52D808CA,
	XRBaseInteractable_get_onDeactivate_m283A38AA07BC69AF140537FD548D038CC88F48CD,
	XRBaseInteractable_set_onDeactivate_mDA096E9F7ACAF2DBEC630D9E146D8C47B2B9ECC7,
	XRBaseInteractable_get_onFirstHoverEnter_m4291CD3E502724E909AD87A056FFCD7F39C640EF,
	XRBaseInteractable_get_onHoverEnter_mDC7E5C0BD57D83841A2F43D2D44D1D98BCABB0A9,
	XRBaseInteractable_get_onHoverExit_m1FAA6CE01CCA1D235586C98D5153E3992AC40469,
	XRBaseInteractable_get_onLastHoverExit_mA5AC01568346EBE0A9F77F11EC8F4724C1D88126,
	XRBaseInteractable_get_onSelectEnter_m02091456C0663A61F506F273E73703AECC2E3B35,
	XRBaseInteractable_get_onSelectExit_m3BD12DAB18901906BBA106472CC82749C592D693,
	XRBaseInteractable_get_onSelectCancel_m4CD2EB174EA26F7907F34BC99DD707225B311124,
	XRBaseInteractable_OnHoverEntering_m588E25A00CF1DCA119F223C6BEADDD3B59D9AB1B,
	XRBaseInteractable_OnHoverEntered_m412FB9342515A3A22FE92CA30A0F170EE2EF2853,
	XRBaseInteractable_OnHoverExiting_m589A6A23AF8ED178D75C0936ADC2758462AEE019,
	XRBaseInteractable_OnHoverExited_m9915A3C9B8E9BF9C2FB3C72E166F9AFC13F180B6,
	XRBaseInteractable_OnSelectEntering_m897698ADCBABB2893944F19AB9B75BA289E09F9E,
	XRBaseInteractable_OnSelectEntered_m92C88883CAABC0299A9C8F76086E77DEC37BFA0D,
	XRBaseInteractable_OnSelectExiting_m14F2025DF6CDE08CEFC32CBC0DFD05B322386265,
	XRBaseInteractable_OnSelectExited_mEB5BA537E00FF5A6E78C231668A2C5150AB49239,
	XRBaseInteractable_OnSelectCanceling_m52437F3B08279B8F50252F2BB3B95E970C2324C8,
	XRBaseInteractable_OnSelectCanceled_m4543868A2D75DFF30C44BB177118D536C95F1457,
	XRBaseInteractable_OnActivate_m2AD33C7A74CE6181F174853627F10C809F604303,
	XRBaseInteractable_OnDeactivate_m33F1A2AD3F147334702A4972FEE33C98AE7F3335,
	XRBaseInteractable__ctor_mDF809A206563ADCC895A710AA04677E2643E523B,
	XRGrabInteractable_get_attachTransform_mCFEED1B9F7BED3005EF66CD725F2B54C8E385662,
	XRGrabInteractable_set_attachTransform_mBDEAABEC1FBDB9C8DE9A6BC57F5C269B74DC594E,
	XRGrabInteractable_get_attachEaseInTime_m1ADEC0485E9494533DFCB76DC58B245A74932538,
	XRGrabInteractable_set_attachEaseInTime_m2F1D75DB03563723A037A9BC473C27297766687F,
	XRGrabInteractable_get_movementType_m5336B231E28E90E4BEC58627DD65E825960B6E16,
	XRGrabInteractable_set_movementType_m23145D15E650595B7A3684901A551A48D007E563,
	XRGrabInteractable_get_velocityDamping_mC45991DF3D1F8A65BBAF9BE0964904CC0B75964D,
	XRGrabInteractable_set_velocityDamping_m4653C1A619B3519C8B93DB8DF1E0786E24B28699,
	XRGrabInteractable_get_velocityScale_mACA3EFE62399701C768E12DFCA1A7B4F86B4410A,
	XRGrabInteractable_set_velocityScale_mBFF3F95337B68FB43A1FC7558EE9D2CDC7AF1C90,
	XRGrabInteractable_get_angularVelocityDamping_m1EB0412F4AB85880E9A25E42B4CB97944E005DFB,
	XRGrabInteractable_set_angularVelocityDamping_m4A51A86F6CA6F933795E52362AC70FABAC334843,
	XRGrabInteractable_get_angularVelocityScale_m67144C00D787AA3E981F0B49B6C0F5C164147EF5,
	XRGrabInteractable_set_angularVelocityScale_mECF85D0A7F3AAFB2870D90C0BD407EB7BA73E581,
	XRGrabInteractable_get_trackPosition_mFAFF6F0139571549C6DA1A2E393697A614839514,
	XRGrabInteractable_set_trackPosition_m588E2349E2135A9FD8AFD651BB88E0E5B33DFCB4,
	XRGrabInteractable_get_smoothPosition_m9E1C79DE378EC3BAFE7CAB8AA6C9F11CDC1FF9D2,
	XRGrabInteractable_set_smoothPosition_m2DAB04DD912FD109A710BE4CD1F1E0085D69814E,
	XRGrabInteractable_get_smoothPositionAmount_mB53562269982B3870532799C6A20D81C5D73E541,
	XRGrabInteractable_set_smoothPositionAmount_m39F5B69A68503EE8C142CFE7D0D5EF463D0C8321,
	XRGrabInteractable_get_tightenPosition_mB6C11F873870015814C2559ECCFFC4DEF3B21F61,
	XRGrabInteractable_set_tightenPosition_mACB34AE0650D7B0EBAAB559B18099502DBF1CC32,
	XRGrabInteractable_get_trackRotation_mC594D923EB5F01E79249DB9DE57296512968D7B9,
	XRGrabInteractable_set_trackRotation_m2EF07501B37C171377E269FD015668D2659D199A,
	XRGrabInteractable_get_smoothRotation_mD0F9582301A1F41A98EC87E6AFD88B5827A133CF,
	XRGrabInteractable_set_smoothRotation_m96191A71676A90F01CD4C661E19BD6C927C8FAE3,
	XRGrabInteractable_get_smoothRotationAmount_m98B0B68F49FCC228141059C133999632D7D55E0A,
	XRGrabInteractable_set_smoothRotationAmount_mCACF2B56019831A1311E54D12A9FE325520A7444,
	XRGrabInteractable_get_tightenRotation_m11681E043ECA567163F95EFD74F8EED52643D649,
	XRGrabInteractable_set_tightenRotation_m01DEB304B70C2A105C9AA00D2914106F47673B8E,
	XRGrabInteractable_get_throwOnDetach_m4E6B3395E082D656F160F25555F018407CDD4395,
	XRGrabInteractable_set_throwOnDetach_m9245D3707FCCD624D0A8B1828CD9EEDE7801840D,
	XRGrabInteractable_get_throwSmoothingDuration_m295093BA950E8E1ADF0F912C9DAA8E81E86E4684,
	XRGrabInteractable_set_throwSmoothingDuration_m63B2F31FD388EB12B8E0766086F908EFFE7CEC93,
	XRGrabInteractable_get_throwSmoothingCurve_mFB8C99F7A201983789F2F08282A45DB71F399EE4,
	XRGrabInteractable_set_throwSmoothingCurve_m15F19E4A0E2902C77F96903E74B8A2EAD0F87F13,
	XRGrabInteractable_get_throwVelocityScale_m7F183D3754A5FD353B63508511E522F9E003DEA9,
	XRGrabInteractable_set_throwVelocityScale_m9290B8C247785BD1A2B3DB7E5D931FDBD4C9480F,
	XRGrabInteractable_get_throwAngularVelocityScale_m923593F0D5F82DC1E28896EEB58C31A97DBD0E97,
	XRGrabInteractable_set_throwAngularVelocityScale_m07ACE9E817DFD81C93A587FED4C2E7D97D294618,
	XRGrabInteractable_get_forceGravityOnDetach_m4FEAFC00B60688A66291297C086278286AE2635C,
	XRGrabInteractable_set_forceGravityOnDetach_m1B2D30772BEE2919AF67178138D66D16A6B89F66,
	XRGrabInteractable_get_gravityOnDetach_mCDB9A3BF3C089057D4AF53570C81BA7E3B618FB1,
	XRGrabInteractable_set_gravityOnDetach_mD96B1445F40246A77045E73124A42E5B45987CE3,
	XRGrabInteractable_get_retainTransformParent_m317451259253BBE1D90FBF305103B8FBF4E6C7F9,
	XRGrabInteractable_set_retainTransformParent_m2A8CB82E4DBD7678529368B91C7610A4C544817A,
	XRGrabInteractable_Awake_m6A3973C982B38E9C8656B60E201DA3DEC1D5F6B6,
	XRGrabInteractable_ProcessInteractable_m5CBB4BC09224BC549919E50AF61096A607780D9B,
	XRGrabInteractable_GetWorldAttachPosition_mB51F5D79BF1F2D486C7B6B817405D53A5FC90D6B,
	XRGrabInteractable_GetWorldAttachRotation_mEEA750341259E9A98C3AADA59F1B4315E68B0987,
	XRGrabInteractable_UpdateTarget_m65DFB9528AC6373329CD0106C444920D08405609,
	XRGrabInteractable_PerformInstantaneousUpdate_m319A1EDD10F8C7D530080E1FE375CFBD19A58775,
	XRGrabInteractable_PerformKinematicUpdate_m653F5F5987CC234B8031E1620DF0D393B07593FE,
	XRGrabInteractable_PerformVelocityTrackingUpdate_m40F49A6922A04C36872C9573B7D74F0B105F8289,
	XRGrabInteractable_UpdateInteractorLocalPose_mC2C9A7FFDD809A2B8FBD07531458BD07BB02F5A8,
	XRGrabInteractable_OnSelectEntering_m35C0E7642A44DFE4395F8714910A826A8C9AD558,
	XRGrabInteractable_OnSelectExiting_m29DB52D4EEBD6694AD216CC1A89423527B358451,
	XRGrabInteractable_Grab_mC60AEB14AE55DBB446EFE7B3E8C7F4957D8AD71B,
	XRGrabInteractable_Drop_mC831156FD7C1A840A5626DBFFB0FE354E17BEC0E,
	XRGrabInteractable_Detach_mBDDBEBD3C4104BF0BFCAF22F5EA17F07C7B15641,
	XRGrabInteractable_SetupRigidbodyGrab_m0FBB2455BA6001AF5422A40458185D528AE0D31A,
	XRGrabInteractable_SetupRigidbodyDrop_m97C5E90449A546142A823596B6EB8C94EA6DCB5F,
	XRGrabInteractable_SmoothVelocityStart_m467C56A03D741840C08A29E62053FE41ABA99530,
	XRGrabInteractable_SmoothVelocityEnd_mE3E18D53F3184FD88E9BFBF5E14F2418F5C81069,
	XRGrabInteractable_SmoothVelocityUpdate_mF23E340AFEA898D1EA7EE07069D854115678C17B,
	XRGrabInteractable_GetSmoothedVelocityValue_m06973B9DE4F19E11F149D5AFB0D55E7858CC1695,
	XRGrabInteractable__ctor_m73CCE84E4C6F31D6A132742A416C9F8EE8B1D2CE,
	XRSimpleInteractable__ctor_m1C9CE017DFB92D8830865DB23E005E5DAD8C26B9,
	NULL,
	NULL,
	NULL,
	NULL,
	XRInteractorLineVisual_get_lineWidth_m96F69834A319911566BA6C6EA391FE1CE525098F,
	XRInteractorLineVisual_set_lineWidth_m8D462CDF8C3E7AC1EEB6E78A3D2AC9945D968C79,
	XRInteractorLineVisual_get_overrideInteractorLineLength_m4F61A9339BFE1ABB4D85ED99472CF3CC6A32C1C6,
	XRInteractorLineVisual_set_overrideInteractorLineLength_m43A0D9FAF8C58359E6B1F3D0067C3CDBADBCC4FC,
	XRInteractorLineVisual_get_lineLength_mC83680A06C8249E27FA406D689A04D53D3529B81,
	XRInteractorLineVisual_set_lineLength_m3DF95007ADBEC21EA4DA41A4280E6C23DA9147C3,
	XRInteractorLineVisual_get_widthCurve_mF804C47DA68A1027E03E3028CFCA531178A44B17,
	XRInteractorLineVisual_set_widthCurve_m4C2F1F0D65A7B5AB0933DF76C9C214D2D5D92B92,
	XRInteractorLineVisual_get_validColorGradient_m1942AE896FACCC12B00FA17ABBC41A8FBB9EA80E,
	XRInteractorLineVisual_set_validColorGradient_m0671AAC1AD10F554D1D26B388AF118D2AC85BCB8,
	XRInteractorLineVisual_get_invalidColorGradient_m677F7427379394B54F1E3E838D5B45D4714C6245,
	XRInteractorLineVisual_set_invalidColorGradient_m101018631A998BF4AD272D091FFB22B80770B843,
	XRInteractorLineVisual_get_smoothMovement_m57D41D24159058B8A6A418D4FAFBA3ACB0F362CA,
	XRInteractorLineVisual_set_smoothMovement_mBC06B064251D4E7F0DC77BB3DF5AA46846CFB78C,
	XRInteractorLineVisual_get_followTightness_mDF82AC5DE6AA47E72B2CBCFF21F578AD0F360CE6,
	XRInteractorLineVisual_set_followTightness_m49C4452709A84E3A35D99FA02C533FBCDDA47589,
	XRInteractorLineVisual_get_snapThresholdDistance_mCDFE5584EC55099D19657124395EC0BB5DE07697,
	XRInteractorLineVisual_set_snapThresholdDistance_m937662B2F9F69BDE5DC1EBFBAE920A94B60478E5,
	XRInteractorLineVisual_get_reticle_mC2D9F4B3880B5402F6A5D46DC2A78440CD73DEC7,
	XRInteractorLineVisual_set_reticle_m44FEEF3BEA4325256C3982922AC6166DCA1ACCF6,
	XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m6611D67930B530767533378E788F82D38998F508,
	XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m63991065E359CEDD74739C8B4D012E3190E0E1EF,
	XRInteractorLineVisual_Reset_m67A0585521324F156C781BA92F934230B52B2A4B,
	XRInteractorLineVisual_OnValidate_mFED6AB0B0E9430A250806AA066EFF5CC9DAF673C,
	XRInteractorLineVisual_Awake_mC445AE47F6A85EE78747A26C19DDEF3327D6879A,
	XRInteractorLineVisual_OnEnable_m455984A1E3DD708A5D5DE7A58439B4427FA3738E,
	XRInteractorLineVisual_OnDisable_m8E5223F3219AB4F58866A93EE6A449C8D3AA8096,
	XRInteractorLineVisual_ClearLineRenderer_m57218609C8FEA820DB02F352B9243634464CE51C,
	XRInteractorLineVisual_OnBeforeRenderLineVisual_mC41BB0EA7A5E1652634D180F145C5E9C167F734D,
	XRInteractorLineVisual_UpdateLineVisual_m296B3CBA8AA7648594D544D6363F3ACDF2C31A3B,
	XRInteractorLineVisual_UpdateSettings_mEB1476ABF7670809FB934D27E32DEFC9D2B3BB7E,
	XRInteractorLineVisual_TryFindLineRenderer_mB36EF9B9C2806849CBD8AB3CAB04C4161030CC08,
	XRInteractorLineVisual_AttachCustomReticle_mC8EC6F97C16D8BF41A9B78934AA0A50A9535587B,
	XRInteractorLineVisual_RemoveCustomReticle_mEA4749C68830C9D8F3EB366E83A6B74DBEDE4B32,
	XRInteractorLineVisual__ctor_mE32646D14194660D4F4635BB6801E78684288B69,
	XRInteractorReticleVisual_get_maxRaycastDistance_m5D0656EA4D259FF477324974AB897FBE1124C65A,
	XRInteractorReticleVisual_set_maxRaycastDistance_mCBA0DEA0865FF45CC43AE2F65EB5CF56E5AF9A32,
	XRInteractorReticleVisual_get_reticlePrefab_m3D4FC0E27D10392B5CB8AB6358ADA40504C38FA6,
	XRInteractorReticleVisual_set_reticlePrefab_m28D662BB77B70F49738F267067D5E1D7BF0D2CA2,
	XRInteractorReticleVisual_get_prefabScalingFactor_m6062599B315F28A063AC4FB49AA826DCCAE64939,
	XRInteractorReticleVisual_set_prefabScalingFactor_m6E59EBA702C6D5A77FD0EBD7ACC31D8BF82ADAB9,
	XRInteractorReticleVisual_get_undoDistanceScaling_mA841A28F57F526B2C0A73B32155B0185CEF34B43,
	XRInteractorReticleVisual_set_undoDistanceScaling_mCA75AD5FEFC2C184C73515D301CA862ED44AAC14,
	XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_m1A9A614A9C71EA40059A3483B730EBA008354FDB,
	XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_mE97E04F0153A85D2A244ACE7B6C2DF1B7F5AB3B8,
	XRInteractorReticleVisual_get_endpointSmoothingTime_mEEE5AF6B0734098FA3C421B8A053045062973DFB,
	XRInteractorReticleVisual_set_endpointSmoothingTime_m20ECF8503C3A6D521206B971512508F785537874,
	XRInteractorReticleVisual_get_drawWhileSelecting_m477F2BFBC936257D7AB6DF513B31F4C2097938E9,
	XRInteractorReticleVisual_set_drawWhileSelecting_m6382A849853A1D89A56E85C2A0A87C3689598E21,
	XRInteractorReticleVisual_get_raycastMask_mFE2021B73CBDF71F66ABC700CD29C8AECB274D30,
	XRInteractorReticleVisual_set_raycastMask_m48E875278ABCD7CE9785BCA53DEE9A3D93790186,
	XRInteractorReticleVisual_get_reticleActive_m8B672179381DB7C6F6C37CBFF71812D2656BB44C,
	XRInteractorReticleVisual_set_reticleActive_m0CF10850536624150F369012C157A05D12955917,
	XRInteractorReticleVisual_Awake_m91DBF982CECFD91ED7C25CCFED7CD843015BF21E,
	XRInteractorReticleVisual_Update_m76C76FA19939699C2612463789190DA57B10EE3C,
	XRInteractorReticleVisual_OnDestroy_m2A083EF5B41662AB6E7EE5526FF08FDECCCC29A6,
	XRInteractorReticleVisual_SetupReticlePrefab_mB2034615F130AB7CC65C6CB763871D4B13F075AB,
	XRInteractorReticleVisual_FindClosestHit_m7DAAF993CD38DD7C3BF877D130350A00E43022F4,
	XRInteractorReticleVisual_TryGetRaycastPoint_m7603C50426032F46D99419A3E14C862364D8B9C3,
	XRInteractorReticleVisual_UpdateReticleTarget_m982FA1B4BD60EEEF9504200B6E3B4B3F78051237,
	XRInteractorReticleVisual_ActivateReticleAtTarget_mD7236C5B94F1F6B08C8CC015C336D18C325C3D18,
	XRInteractorReticleVisual_OnSelectEntered_mB681FC8AD5FB5B691F8A67E2C222453CF4CA6BE2,
	XRInteractorReticleVisual_OnSelectExited_m913728EDDE7D0DAF8E860EBC8D4FF83BB36B5D28,
	XRInteractorReticleVisual__ctor_mFD83E499E0FA07F10EABBEE23FD64E49B2E36242,
	XRBaseControllerInteractor_get_selectActionTrigger_mEB3F19A8FAF90DFBE213816D80877BB422531872,
	XRBaseControllerInteractor_set_selectActionTrigger_m4C36C53409C73DE7D2953A1398281E40CFC8A2B8,
	XRBaseControllerInteractor_get_hideControllerOnSelect_mDF23B89216D3A760F0B8D0CBE14E346021A4DA42,
	XRBaseControllerInteractor_set_hideControllerOnSelect_m3658DFD475416E84FD25A7B61B86AB1C9AF0882B,
	XRBaseControllerInteractor_get_playAudioClipOnSelectEntered_mD283375EF9251B0CA334854C89E1EC9FA266A228,
	XRBaseControllerInteractor_set_playAudioClipOnSelectEntered_mBD1C058768A84ED6EC9F314E37F4592AF1FD1F4D,
	XRBaseControllerInteractor_get_audioClipForOnSelectEntered_m9C9FF63AC7A1C8D91D11348A0D31E6074ED24049,
	XRBaseControllerInteractor_set_audioClipForOnSelectEntered_m473038F69E9D7F786BCAB27E9E552A5269271A1A,
	XRBaseControllerInteractor_get_playAudioClipOnSelectExited_m08658F645DC323C76B6B8E21AFE6241FBB759364,
	XRBaseControllerInteractor_set_playAudioClipOnSelectExited_m335EC8ACA5A77DB98C06C7771BC5CA3547DEEA8B,
	XRBaseControllerInteractor_get_audioClipForOnSelectExited_mEFF33393BF04B828AC59CF7732438074D0C7C623,
	XRBaseControllerInteractor_set_audioClipForOnSelectExited_m4504F9A5426F547679B4AF306AF5AABDD6A1762A,
	XRBaseControllerInteractor_get_playAudioClipOnSelectCanceled_m87290C6673A2379E6F821133C9F56BBB6A38AEB0,
	XRBaseControllerInteractor_set_playAudioClipOnSelectCanceled_m9EB7D464A0B7AE48251953FD0C27A20F2A9FE842,
	XRBaseControllerInteractor_get_audioClipForOnSelectCanceled_m4C3EC5CBE13D843E0F70502453DA6E440594EEA7,
	XRBaseControllerInteractor_set_audioClipForOnSelectCanceled_mD1418B6C8C7D9BE930B61065A0B4426BB4DC2142,
	XRBaseControllerInteractor_get_playAudioClipOnHoverEntered_mC16557975B7ED2B7EB9BEAA7F9773C1977E40EFD,
	XRBaseControllerInteractor_set_playAudioClipOnHoverEntered_m8D391B6A3E43EDA651E4F6B8A2E98F41E7929F4B,
	XRBaseControllerInteractor_get_audioClipForOnHoverEntered_mC5F687C936BE25BBEF1F98F018DBBAE9D6CAA4B9,
	XRBaseControllerInteractor_set_audioClipForOnHoverEntered_m5D97BC75543001C1A6761F3E79D0DEED45E6002B,
	XRBaseControllerInteractor_get_playAudioClipOnHoverExited_m1059950C6BBA35508C69953A47A22E2CAEBB1FF2,
	XRBaseControllerInteractor_set_playAudioClipOnHoverExited_mFFA05FF99316D3D2061B5E161957C12D8295A3F4,
	XRBaseControllerInteractor_get_audioClipForOnHoverExited_mDB0AA5F79BF2780B18A1C34F21591B2C02F13BF8,
	XRBaseControllerInteractor_set_audioClipForOnHoverExited_mF81EF5D32D07A2A409669469E3A97D5A987E6CE9,
	XRBaseControllerInteractor_get_playAudioClipOnHoverCanceled_mEC0540AA2F83B04F65D0DA7A42631E6DA292AC39,
	XRBaseControllerInteractor_set_playAudioClipOnHoverCanceled_m14EC235BE3C0B901FF33CAFA16D2759A2EF5CB56,
	XRBaseControllerInteractor_get_audioClipForOnHoverCanceled_mD0D9C079B9C92FD38D4B1A482EA742D3B5925AF8,
	XRBaseControllerInteractor_set_audioClipForOnHoverCanceled_m7DB50A112B6BBAB000143ACB89D23000D173E20E,
	XRBaseControllerInteractor_get_playHapticsOnSelectEntered_mF2BB6170CFA6508A4ED9BB929BAA83E615C557AB,
	XRBaseControllerInteractor_set_playHapticsOnSelectEntered_mCADF142EC70C0C0F3631B2678F3A5043BE2AC146,
	XRBaseControllerInteractor_get_hapticSelectEnterIntensity_m5F736B8319F66BBA84625A6D75ADCBA873CA7473,
	XRBaseControllerInteractor_set_hapticSelectEnterIntensity_m4EB02CAF14353FBFCEAFFA2BDE85D8C681CD4490,
	XRBaseControllerInteractor_get_hapticSelectEnterDuration_m35CD2EB4663BBE4BB2BB88C5A16814AE64508169,
	XRBaseControllerInteractor_set_hapticSelectEnterDuration_m8467B6E79882E4634E0D2D03C3019E4E1387CEE8,
	XRBaseControllerInteractor_get_playHapticsOnSelectExited_mCFA009625873489354775C5F0A7C189BEACB06BB,
	XRBaseControllerInteractor_set_playHapticsOnSelectExited_m1B2B37CDBB81E9CC06D660FB789A56AE997DB1F1,
	XRBaseControllerInteractor_get_hapticSelectExitIntensity_m8B308438949D301C73193A18A0C418F7DE6CB43E,
	XRBaseControllerInteractor_set_hapticSelectExitIntensity_m9480569A24FE04DEF370071C331052527EF91EB5,
	XRBaseControllerInteractor_get_hapticSelectExitDuration_mF95447258248FD7C1EFFAFE5AA44465F4C925174,
	XRBaseControllerInteractor_set_hapticSelectExitDuration_m9CDAA15FB96BC535F8A2C9306F1801DFBF09F731,
	XRBaseControllerInteractor_get_playHapticsOnSelectCanceled_mB61136F04A77A69C974AD2C6613C843B96FD446B,
	XRBaseControllerInteractor_set_playHapticsOnSelectCanceled_m2768F130380A8B453605886FAEB5D4A217DAF514,
	XRBaseControllerInteractor_get_hapticSelectCancelIntensity_mC44B6CF2D6E2383295A885AC4782B53B84F5E609,
	XRBaseControllerInteractor_set_hapticSelectCancelIntensity_m3DDF5CDF9D8239AF079790851E3D5BC34A5A89A0,
	XRBaseControllerInteractor_get_hapticSelectCancelDuration_m34DE8956EA0A74344706BE49FBAAA168E5941F53,
	XRBaseControllerInteractor_set_hapticSelectCancelDuration_m283CFEB61814CFBD127E6D8ACE726E61EFC3ACBB,
	XRBaseControllerInteractor_get_playHapticsOnHoverEntered_m93D2390D87F047CCBB0F119DF15C115D1F076926,
	XRBaseControllerInteractor_set_playHapticsOnHoverEntered_mA90AC1C3FA080363C0B73EEE75F3A158889942D7,
	XRBaseControllerInteractor_get_hapticHoverEnterIntensity_m40C3EEE7C7F370148E53839507A83D6139E7ADC8,
	XRBaseControllerInteractor_set_hapticHoverEnterIntensity_m5A991BFABB8D84600AE577E20DED548563ECFCDF,
	XRBaseControllerInteractor_get_hapticHoverEnterDuration_m52B5409E6D2753C2A08DBCD5D1C9FC41E0F14FE7,
	XRBaseControllerInteractor_set_hapticHoverEnterDuration_m8788CB468B533D8D732828EB5026E93BAC139006,
	XRBaseControllerInteractor_get_playHapticsOnHoverExited_mA339F20F0CF89A50E5368147578CA292356F3C36,
	XRBaseControllerInteractor_set_playHapticsOnHoverExited_mF31BE0F7E52E53D04582C45F0A21A5534663949E,
	XRBaseControllerInteractor_get_hapticHoverExitIntensity_m8721A715EC3A9536DA76AD710C20774DEB4E2DBE,
	XRBaseControllerInteractor_set_hapticHoverExitIntensity_m63B54A4CC033C27C08B27DD470E7457415500435,
	XRBaseControllerInteractor_get_hapticHoverExitDuration_m2BBCA730DED74BCAAA3B7FE7AD561B0EE74C22CF,
	XRBaseControllerInteractor_set_hapticHoverExitDuration_mCBEDDF666434D1BE8B41CA4C46CC311206F037FC,
	XRBaseControllerInteractor_get_playHapticsOnHoverCanceled_mA4B3774B49FFB5A33A98F02A29170C8FC1DF83E8,
	XRBaseControllerInteractor_set_playHapticsOnHoverCanceled_m1DBDAEF87815F4EC72B40FDF277F69216180F53C,
	XRBaseControllerInteractor_get_hapticHoverCancelIntensity_m7F8FA26D95AC57C6D540FE557306FA23BFECF9E6,
	XRBaseControllerInteractor_set_hapticHoverCancelIntensity_mDFEBCBB209E0B58DD5987151572075FC46043CCF,
	XRBaseControllerInteractor_get_hapticHoverCancelDuration_m98D8EA0FA49739D52C9E90581A7F0A51F14420AD,
	XRBaseControllerInteractor_set_hapticHoverCancelDuration_mD924C78944E3ABA1A78367D497ADED5230799FC1,
	XRBaseControllerInteractor_get_xrController_mD5F553C6509F366C42DBCBE094C88C8E4911F30C,
	XRBaseControllerInteractor_set_xrController_m6976CFA96A0AB2C0A16670FB353706777B698BB2,
	NULL,
	XRBaseControllerInteractor_Awake_m5928A93A57F57571124F8165E9FB5A78F03D6C1E,
	XRBaseControllerInteractor_ProcessInteractor_m48B7F4340BFD8B4F7E6C0AB5F7D0478916A18E3D,
	XRBaseControllerInteractor_get_isSelectActive_m07495FDEC77FF5660F1E4F0EAA30740BF80D0D8C,
	XRBaseControllerInteractor_get_isUISelectActive_mF377D3864A70E34C5ADACF00AAF3C344DB8275EB,
	XRBaseControllerInteractor_OnSelectEntering_mE03EEB44AAA35297AA1ABEB45167ABCD7C1B318F,
	XRBaseControllerInteractor_OnSelectExiting_mF0482C8368115E0F15EC7805DE569C0A5585631D,
	XRBaseControllerInteractor_OnHoverEntering_m9683A9F31AEB67A0842F4BA8693372C4743735E7,
	XRBaseControllerInteractor_OnHoverExiting_m2137AF8DA95FD98EABC55DE3A16CE8BA15422667,
	XRBaseControllerInteractor_SendHapticImpulse_mD4DD3CB4B43725EF55994A8B79B00F05D16076BA,
	XRBaseControllerInteractor_PlayAudio_m46DA65BC88916FC5BF839AC76352803ED96F185D,
	XRBaseControllerInteractor_CreateEffectsAudioSource_mC46CFB8149442289C6CBDA01B6BD69FF7DAC0B30,
	XRBaseControllerInteractor_HandleSelecting_mA0AD415937149F3D40FECD2414D6B93126DF717B,
	XRBaseControllerInteractor_HandleDeselecting_mC0A8A94F47655F67981524052CBFDBAC584983E3,
	XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_mD4A2D6672AC00E0ABCA375C25B3E5F91FD0B3B0C,
	XRBaseControllerInteractor_get_audioClipForOnSelectEnter_m542ED00D22426B9F2720A006CC4A8A9AC1F1CEC9,
	XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m36BB85ADCEDE964ECFD978109BCDC6CC02832A94,
	XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m6E7A0E1DC45B2B35CD2FB049991C8FC5C19E8679,
	XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m62CBE6A8A87E25AFB9FD14A7557B9898141F5FA2,
	XRBaseControllerInteractor_get_audioClipForOnSelectExit_mB89C17FB92E542CE40AB3CEE65D200FAF6DDF40E,
	XRBaseControllerInteractor_get_AudioClipForOnSelectExit_m1B854FD0BA8D624F29980EB7371B0A2869883CB5,
	XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mC6B39D83157978775708C8FF97BE7D9D5E84C111,
	XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_mF3A6DE58ED5E608605A0C57B8A58E40EDE32F288,
	XRBaseControllerInteractor_get_audioClipForOnHoverEnter_m3579C9FDB8E9A3EAE90DC9A7D59C8EC6C01FA1C2,
	XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_m298AC1C585EBC7399C93BEE1D0E789950C2A4620,
	XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_m58478657E548BE914881AD2E1ED9A5607198D5F2,
	XRBaseControllerInteractor_get_playAudioClipOnHoverExit_mE0440D9008F7396FE6A385C91213A52A0DDBDFD0,
	XRBaseControllerInteractor_get_audioClipForOnHoverExit_mD3F78A869E279EC2CD04E0B9275A05AE6CB51458,
	XRBaseControllerInteractor_get_AudioClipForOnHoverExit_mA08B482833C2793EC0983C63F631AABB483DBA1C,
	XRBaseControllerInteractor_set_AudioClipForOnHoverExit_mA233E5410865DE254706F4A6420ED125C1D7D638,
	XRBaseControllerInteractor_get_playHapticsOnSelectEnter_mBE869139D32D2FCB4A7A1E625D4BB8270CDEC5CD,
	XRBaseControllerInteractor_get_playHapticsOnSelectExit_m2B565B8BDC73161C9164FDE54C16CEE59FEC0789,
	XRBaseControllerInteractor_get_playHapticsOnHoverEnter_mCCE460E3803E34602FC18E580ADFE42AED145F6E,
	XRBaseControllerInteractor__ctor_m9DFBF006FE6B69171E8913BFCE74D2E9000EF2D5,
	XRBaseInteractor_add_registered_mB0EFEF8438E6EA4ACECDD9B291AAE1A9BE0AD5D5,
	XRBaseInteractor_remove_registered_mCB720EC6C856730BFF04241DE157D5FDB83390C4,
	XRBaseInteractor_add_unregistered_m2C80C55F46F1F9A8107D0F44701A67A21F723024,
	XRBaseInteractor_remove_unregistered_m9C5E7918732F01064D4076C6A40CE13A519AA854,
	XRBaseInteractor_get_interactionManager_mD788218F91219F2327A02B1350DC930E3D3432F4,
	XRBaseInteractor_set_interactionManager_mF970116906FFAE5CD7772CE24FBB41D491C00695,
	XRBaseInteractor_get_interactionLayerMask_m8CF4046276AFD5EC4E36EC86176123742CEB5C13,
	XRBaseInteractor_set_interactionLayerMask_m835B6F35ACFC0B66F5C664707B0DBCD25EBCBF89,
	XRBaseInteractor_get_attachTransform_m9B4E7DE7F5374B2CDAA5256E6CF2D72FC3AF09D1,
	XRBaseInteractor_set_attachTransform_mE9AFEDA319291A10B90FA10D74C8A1D110D6B8B1,
	XRBaseInteractor_get_startingSelectedInteractable_m6E35F0706C2BDBE89010B65B465F7610949B4680,
	XRBaseInteractor_set_startingSelectedInteractable_m8A13723D7F503A44FEDED4440A9C475EE0AA4A84,
	XRBaseInteractor_get_hoverEntered_m444F4A60AE6CF56FCC4522225155A49A46A5B9A8,
	XRBaseInteractor_set_hoverEntered_m575703CB90F96D04C1DE1098A326EF7B45A420AD,
	XRBaseInteractor_get_hoverExited_m2D37FB1C6B47CC020603FAA640642DB9F14798FE,
	XRBaseInteractor_set_hoverExited_m7BBD5F61B4ECB566AF224A7E41E50F0EBA8ED7FB,
	XRBaseInteractor_get_selectEntered_m957269B06CBB2BB5CBF550B0B7853F0CE296DF64,
	XRBaseInteractor_set_selectEntered_mED77DDD1F8739A97581B359ACAF8848F58E1E1DC,
	XRBaseInteractor_get_selectExited_m05B02D438D30646B7AD5827FCEBCA401E8AA0C23,
	XRBaseInteractor_set_selectExited_m4F835CD06D8F72BA0984AE3A0A86A668AD92B4B1,
	XRBaseInteractor_get_allowHover_m491FE90B83669D9AB429D271AD1B88D31B01393E,
	XRBaseInteractor_set_allowHover_m313B52A3C885E13A10C6D611D1EA2EC43CD1B352,
	XRBaseInteractor_get_allowSelect_m07A9ADAC4DE19A8533147926B68B6F4B1B742850,
	XRBaseInteractor_set_allowSelect_m094F101EE5C21F36E284A38CF94A46AA1320E359,
	XRBaseInteractor_get_isPerformingManualInteraction_m7357ED7B9A1C9806164865C951928171899F1B3C,
	XRBaseInteractor_get_selectTarget_mEA10D51DB4A57FC59E69E115A4408F1414FC38BA,
	XRBaseInteractor_set_selectTarget_mBB9E53626D2294BDFAAA9251FA4E196B551F9D65,
	XRBaseInteractor_get_hoverTargets_mF2CC203D60951BBD907931F8971169D29867074B,
	XRBaseInteractor_Reset_mAD176832E0C0B17DD0AAE6B19369ABFAA0D288AC,
	XRBaseInteractor_Awake_m3F11BBAC030E198213D828F5E5CB262C45FEC88A,
	XRBaseInteractor_OnEnable_mCEEA2E704A8CB811724219B0742C216CA16124D0,
	XRBaseInteractor_OnDisable_mF1966E65AABD1F5BC73F5F27593AEA54DA366A3A,
	XRBaseInteractor_Start_mE91DB6506CB783CAF6E0E47F1B8423571BBB9052,
	XRBaseInteractor_OnDestroy_mF09360B0AFBDF120CE1FD1D70885C7950F8B4C65,
	XRBaseInteractor_GetHoverTargets_mC312C5DB084E10B8BF10BF4D02C01DFB2B53374A,
	NULL,
	XRBaseInteractor_FindCreateInteractionManager_mF3D7E524D16482729F4858716C73792F4C09A37F,
	XRBaseInteractor_RegisterWithInteractionManager_m8BEA8B1B49C1011214ED028284B16AFFD8E36150,
	XRBaseInteractor_UnregisterWithInteractionManager_mBC307B23DC4B6EB37BAF84CF7D8A086863F31E20,
	XRBaseInteractor_IsOnValidLayerMask_m2D17074B0D638D87C9D16DC1F3F62835381313E8,
	XRBaseInteractor_get_isHoverActive_m95DA85F5073E46E3CB78302FADD40807BEE8C9BF,
	XRBaseInteractor_get_isSelectActive_m26E5368E8E32FE4AD712BB72630281B06FA174DD,
	XRBaseInteractor_CanHover_m7F915707B115431AC270F5C7DD2F7508C6FFAD9E,
	XRBaseInteractor_CanSelect_m808F054C8D6DB8394F942167FF67CD992F9D00E8,
	XRBaseInteractor_get_requireSelectExclusive_m86FD377045D63B47945CCCCF82D30C48848A1402,
	XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m2CF71D48E97E8A9635AF9D395A59D6080D5DD422,
	XRBaseInteractor_OnRegistered_mD7B06E16B9875D9DBE6CF50596192358F2AA96C1,
	XRBaseInteractor_OnUnregistered_m4EBE7B17873E8113BC9BACDBAB75249D7FBDD2FC,
	XRBaseInteractor_OnHoverEntering_m4FC0C04996461A443E49534463151B94DEF77021,
	XRBaseInteractor_OnHoverEntered_mD6E30228AB6FCEA8A80BBFF2ECD5B791B2AE396C,
	XRBaseInteractor_OnHoverExiting_m44F40CB3CF558B99A38BFB6553A15EC229A2B71E,
	XRBaseInteractor_OnHoverExited_m7DF29FD62673E9662D29307768AC98DB082EB18E,
	XRBaseInteractor_OnSelectEntering_m374F174098B188059D3F76C2CBFB94923144212B,
	XRBaseInteractor_OnSelectEntered_mB11BF9F302085510EE9DDF6C3B81DE2C1632EEC0,
	XRBaseInteractor_OnSelectExiting_mC47F4AECFED9FD4E5F6A8C0BE93C9A0A7C43749D,
	XRBaseInteractor_OnSelectExited_m5A8A9818741F28F05EA3A36836BC399B9867D218,
	XRBaseInteractor_ProcessInteractor_m23376B99DA8A3C6638CC3FD4FD2148A399C5D915,
	XRBaseInteractor_StartManualInteraction_m7AC3B5F8B8F8D29B4C7C87DC4D4BDD49F808C650,
	XRBaseInteractor_EndManualInteraction_mF0BA787739E0EB7FD78E43E705F3FA90AFE39622,
	XRBaseInteractor_get_enableInteractions_m9FD194A044BF2D85E6C3DF9DF9901F755F65FEC3,
	XRBaseInteractor_set_enableInteractions_m2845CDCC919232D2D5FB94868E08EAC87CA90EDD,
	XRBaseInteractor_get_onHoverEntered_mAFF22647AE75A7B54B680500E2F4BF2F0065EBD7,
	XRBaseInteractor_set_onHoverEntered_m7044D9AD6CC2B4918295FD460EA4EA5C123821DC,
	XRBaseInteractor_get_onHoverExited_m1F67BDE7594CDEDD404445CC3B17D1BCB4596C7A,
	XRBaseInteractor_set_onHoverExited_m0517740B5A0EA2C50E1B5C75C5F34D5690CF8420,
	XRBaseInteractor_get_onSelectEntered_m274BD10B2794A5BB403939A510642A03573DB6D0,
	XRBaseInteractor_set_onSelectEntered_m0E83F4755C4D4BE02CE4ACA9829325C634AD872F,
	XRBaseInteractor_get_onSelectExited_mE1AFE8A1F0694D4666EC5358B535424E227EB977,
	XRBaseInteractor_set_onSelectExited_m1284249A6BC3784D72B563D343C681BD198D0EE5,
	XRBaseInteractor_get_onHoverEnter_m693C212A919B03F74F2D69B20DAA2D93B906DE76,
	XRBaseInteractor_get_onHoverExit_m2A0CAE4341ACE33B509BE2EC9D613F9323252CD2,
	XRBaseInteractor_get_onSelectEnter_mE7024934D5DEF00A4FFEF5A63BDBC670586EFFD2,
	XRBaseInteractor_get_onSelectExit_m9047E0F399D8D1492DCD0BD341CB481AC8C6BB26,
	XRBaseInteractor_OnHoverEntering_m83374B43BDABEC4D426B097C5ACB41DD54495350,
	XRBaseInteractor_OnHoverEntered_m49ECCF88AE091262B4B0583842AF79F3B623C6B7,
	XRBaseInteractor_OnHoverExiting_mC519C8B22745BE1F74A7248DE60C6162EB05199D,
	XRBaseInteractor_OnHoverExited_mD9E7E14FA53A1EE27E9D6FD5803FDC1A32F2E4F6,
	XRBaseInteractor_OnSelectEntering_mEB04C1D0F5658BE9834F60F11176131C2E269ABA,
	XRBaseInteractor_OnSelectEntered_m141EDCD666A08B559AAFDC9B4F4554D79A620358,
	XRBaseInteractor_OnSelectExiting_m9E592E95AF9402E23F9BF24591ED343ABFC85087,
	XRBaseInteractor_OnSelectExited_m9B7CF8908EBD9B81811E92373CB81F2A060F8429,
	XRBaseInteractor__ctor_m416F8C37308B52430F9AD423030D16AB7E05A485,
	XRDirectInteractor_get_validTargets_m1AF702AA9B4EB8013898DC46745291C36EA7C751,
	XRDirectInteractor_Awake_m6A97849BF2715AFAE1B45A58DEAC64321E58A170,
	XRDirectInteractor_OnTriggerEnter_m2BED922A3348BC78CD78EF76A681C61C0B1FB859,
	XRDirectInteractor_OnTriggerExit_m12DDECA7D86D1FBBE158E18ACCDB67E1E81CEB2E,
	XRDirectInteractor_GetValidTargets_m8CA5BC1503992AA42CC5F28F49B104B11ECAB2A1,
	XRDirectInteractor_CanHover_mC2A95DB54AB18945121EC18C22ADA8B1FBAF808C,
	XRDirectInteractor_CanSelect_m2293AFCD6B146DE13457AC62C663375CCA80E634,
	XRDirectInteractor_OnRegistered_m3EDF1F3036E19EEDAB2A0F590EDAEFAC62BA5FA1,
	XRDirectInteractor_OnUnregistered_m62CC0E93B54511BE86FE3FDCA518E1C06A2F1ED0,
	XRDirectInteractor_OnInteractableUnregistered_mF5B17FC26121AF3482D3CADDBD2CCBAD21B329D5,
	XRDirectInteractor_InteractableSortComparison_m143F0F61981CFCE474AFCA233BA3681F49B67A99,
	XRDirectInteractor__ctor_m7C0F3A54E51B983F48EB7F5863FCAC7C42F149F0,
	U3CU3Ec__cctor_m7113D3B1D2708F3917ED2EAC05D1388E8A0869EA,
	U3CU3Ec__ctor_m7BFB0E1AB4BB50E1AF50E2EF22CC0DFD6582F206,
	U3CU3Ec_U3CAwakeU3Eb__5_0_m79517FA0D828BB2DDD9BA228C01AD9BE8F2D12AB,
	XRRayInteractor_get_lineType_m11B4D85B8C272C14A1E56D10BE445E8FA4FE7691,
	XRRayInteractor_set_lineType_m17CBCF1710C4A02973ABC04180519A4554B16CFA,
	XRRayInteractor_get_blendVisualLinePoints_m6C845075BDFDEFD63E97FA42AE6DB662D1851D14,
	XRRayInteractor_set_blendVisualLinePoints_m0BFBF471BADBDAF001F2C2EA997182155FFE064C,
	XRRayInteractor_get_maxRaycastDistance_mE47EBDEA1527A4BDF74BBFD9D530BD4184C5AA09,
	XRRayInteractor_set_maxRaycastDistance_m38BACC2D65D05D5696748475060D7E3B44804319,
	XRRayInteractor_get_referenceFrame_mA29F959BDD666B803C63F5DD648E898AB583C6F9,
	XRRayInteractor_set_referenceFrame_mA6EF45AC331203EC2EB9A9DA1B27959DC70B5860,
	XRRayInteractor_get_velocity_m227A140028A71A480D57CDF9616943D527481EC3,
	XRRayInteractor_set_velocity_m5DB40D005635BE837486D8E804ABD630F368BAAB,
	XRRayInteractor_get_Velocity_mCAA5773EC425C7C8D406B6E9CDE0E73EB53D7A44,
	XRRayInteractor_set_Velocity_m97774541B2086E548751AC4B1284BDE9002B824F,
	XRRayInteractor_get_acceleration_m19C2CF4596F8D511C547D4A3A1812DC97B1A20E6,
	XRRayInteractor_set_acceleration_mEF6265CE2277BD768AB3D2554211A20969F95531,
	XRRayInteractor_get_Acceleration_m9B8D964257B15D8775D8303164197A33AFE9F584,
	XRRayInteractor_set_Acceleration_mDB202F18C30CE5041AB9B1FC62E4D19CCFE73074,
	XRRayInteractor_get_additionalGroundHeight_mC0BB49D530C0CC6F908D8DDE5C17BB5E68829CB1,
	XRRayInteractor_set_additionalGroundHeight_mD709D8B7D9C89E68517A5F7CF2B826160D0F2F86,
	XRRayInteractor_get_additionalFlightTime_m5971989C99031D0872BDB3D70C8FAF97ADD37865,
	XRRayInteractor_set_additionalFlightTime_m8425E7065E133CC3C1EA0F87317323531E134C9B,
	XRRayInteractor_get_AdditionalFlightTime_m1F9FC8CB6580E5E2B5F8436221BA619DDE0EE78A,
	XRRayInteractor_set_AdditionalFlightTime_m961FC7F399D855DEFCFD7ED18C738A694E2FCE11,
	XRRayInteractor_get_endPointDistance_mE30109C61BC5A973748E3EC6C9C9A5822EA0C9B1,
	XRRayInteractor_set_endPointDistance_m5F04BAEBA57074C0EA3782B1E18C138AE91F855E,
	XRRayInteractor_get_endPointHeight_m00E3D4BD1AAE1682300E4D4C30178B75C6EEC809,
	XRRayInteractor_set_endPointHeight_mC9726D5243B67607F2CE487A768D9F473790D522,
	XRRayInteractor_get_controlPointDistance_mB480B8CF83CD8212F64D86F174F6A58781052781,
	XRRayInteractor_set_controlPointDistance_m8552521764279C47C50AF061B17D6931C1B8506D,
	XRRayInteractor_get_controlPointHeight_m88F12EB5E089D06EF31370972B99D89B29237DD6,
	XRRayInteractor_set_controlPointHeight_m844AC6D4A4AFF0AFC15675C17693E7F1F74F6527,
	XRRayInteractor_get_sampleFrequency_m8D920A45B693FA1B4F5D050B2479D5B1C0F5ED74,
	XRRayInteractor_set_sampleFrequency_mFF32EB51ECFC30638F77B13DC6DF29B6428E3CD2,
	XRRayInteractor_get_hitDetectionType_mF3AB6CD1643A777AA8E51647B54F0C6E39557C33,
	XRRayInteractor_set_hitDetectionType_m2B3FC19DB2D0DCCD71162EC1A451039363CA17DA,
	XRRayInteractor_get_sphereCastRadius_mBCEE5E284DE90F4F6FE0408B10A99737467743E7,
	XRRayInteractor_set_sphereCastRadius_m40DBA5693FC75B4AA5DCEEBAA3569BBF6D9BF913,
	XRRayInteractor_get_raycastMask_m5DD13EF3F5F85E41ED1CCF8267F81355E94D0A6D,
	XRRayInteractor_set_raycastMask_m890AF8A4109415139463FFBCE431D82868689ED4,
	XRRayInteractor_get_raycastTriggerInteraction_m12AFB0195BEF2E3DF8598605430E2598F327C914,
	XRRayInteractor_set_raycastTriggerInteraction_m71DE8A036D3EF39798A49A5A07FFD1BA3A467D98,
	XRRayInteractor_get_hitClosestOnly_m025D49BD73B2E060EAF90CAF59627F780879E96B,
	XRRayInteractor_set_hitClosestOnly_mE09BC1C251D5F72271B2D41B26429DEA4A0A8CF5,
	XRRayInteractor_get_keepSelectedTargetValid_mFB34B5504DFCCF73DC1E2043A4904621D017AE44,
	XRRayInteractor_set_keepSelectedTargetValid_m396CF73104C5A4E4A8804E93F27190ED2C78F854,
	XRRayInteractor_get_hoverToSelect_mD75EAD2BC3C0FD473C2129F174838EE300F3B93A,
	XRRayInteractor_set_hoverToSelect_m3C4B41C2FA76048E938262B260DDB95552C359F5,
	XRRayInteractor_get_hoverTimeToSelect_m0A153949AB600C6F36F704DC3F18A797E08E416C,
	XRRayInteractor_set_hoverTimeToSelect_mC9200C05C52151CE7CF6528DBF08EF869DDA38F7,
	XRRayInteractor_get_enableUIInteraction_m14935C7E914EFBE4DD26D0E3ED572468DF32237B,
	XRRayInteractor_set_enableUIInteraction_m2AE7009548EB5C565E3D75FEF5E248F709B3DAF6,
	XRRayInteractor_get_allowAnchorControl_m242237B56F9D006AF8D11276574ECB530720A2ED,
	XRRayInteractor_set_allowAnchorControl_mEE404127B285C2165FCF33E1814B69DCF4FF04FA,
	XRRayInteractor_get_useForceGrab_m1620DE5DB43598F5039EC0776685DC2DDB7F04F9,
	XRRayInteractor_set_useForceGrab_mFFE852F1EA638243A48679A40090155CE9906130,
	XRRayInteractor_get_rotateSpeed_m2D6670B86E97DBBF4694C45F8DE20C085B9D5D8F,
	XRRayInteractor_set_rotateSpeed_m2D4B2F9773FC63AD8CB9000F9BB17D75F6B6770B,
	XRRayInteractor_get_translateSpeed_m6924A183E73DE03B4D492AB2C616E9DB9DCA6837,
	XRRayInteractor_set_translateSpeed_mEDDF4A2F6B3E98752CEAC5FAF0FA6E582458D591,
	XRRayInteractor_get_anchorRotateReferenceFrame_mBCDA92984F7C4CC671A9886D082711139263AE20,
	XRRayInteractor_set_anchorRotateReferenceFrame_m883BB8D901022956EE2F9971ED616888AC610E30,
	XRRayInteractor_get_angle_mEDC17A18128FA628AAC2CE9BC2A8A5403E6D034A,
	XRRayInteractor_get_Angle_m70550DA809D001294D8E33E8F76DE8C7286E95C8,
	XRRayInteractor_get_validTargets_m65662331C48C792FB9FF65ED8A69F6A366155ACC,
	XRRayInteractor_get_originalAttachTransform_m8CD24BD76F86C1F744D0F5F57010A5957B2DC8FB,
	XRRayInteractor_set_originalAttachTransform_m3CA533F587EDA6C7C181C15FC5E87100B9E5D2B9,
	XRRayInteractor_get_startTransform_m00666CB85DDDA0A708CDAE97B28CCD84478F91C1,
	XRRayInteractor_get_closestAnyHitIndex_mFD451C9E7949B9549D237491B7D7DAC13FF90126,
	XRRayInteractor_OnValidate_m6060C5021926329D95CF1F6162DE6A424EC9B632,
	XRRayInteractor_Awake_m4503C881D61C7126AB419599B588224FF00FA0DB,
	XRRayInteractor_OnEnable_mC1ACDA1ADC5ED1A4042CDC7B7FD8F5467EEC9692,
	XRRayInteractor_OnDisable_m847772A1615B3E214E40FDF6457AD4EB2D829A59,
	XRRayInteractor_OnDrawGizmosSelected_mC987E08C5D085D1E689743228B20A5AFFE39085E,
	XRRayInteractor_DrawQuadraticBezierGizmo_m595235FA27EC9B4183EE1DB3B94BECBCF4D08B88,
	XRRayInteractor_FindReferenceFrame_mA3D7EF2139B3C22305D33F24529C0FC27DE64BF8,
	XRRayInteractor_FindOrCreateXRUIInputModule_m2FD04205A59C9F9115CE8721D7B7E2B90DEDD0BE,
	XRRayInteractor_RegisterWithXRUIInputModule_mA50537933174D1DC0DE9C6DBB59AC38A363E8E95,
	XRRayInteractor_UnregisterFromXRUIInputModule_mE0528A10E0B76823EC56B44904604BF3B4D06710,
	XRRayInteractor_RegisterOrUnregisterXRUIInputModule_mD07A6BC10395319460483F32FADE18557038E8C3,
	XRRayInteractor_GetLinePoints_mA1067E0F64AAE5D39D020231CEF416B0C5893189,
	XRRayInteractor_GetLinePoints_m9315038405AE0F4312E52CEA0A8A7913E0DE818E,
	XRRayInteractor_EnsureCapacity_m0742B92557999003466040218B42B985D4133A0E,
	XRRayInteractor_TryGetHitInfo_m1368D9C2A57C2A93E81457E39D2030FA459BF31D,
	XRRayInteractor_TryGetHitInfo_m0A30AF00366B29D4D3A3DD39BE123594F26A82D2,
	XRRayInteractor_UpdateUIModel_mF222C4CBACAF69BAD574C7872AAC2527B99A3B7E,
	XRRayInteractor_TryGetUIModel_mB22719D248F0BE483F4317627B2006AFA06B3EFD,
	XRRayInteractor_GetCurrentRaycastHit_mC20769C958197D0ED1DB3FFE90411BB501E86262,
	XRRayInteractor_TryGetCurrent3DRaycastHit_m57BAB5FB88C551B6DDB78E8F1059DBBBF80E0E2E,
	XRRayInteractor_TryGetCurrent3DRaycastHit_m3F194C672E7D82034ECB54FCD4A2AFE925C5C574,
	XRRayInteractor_TryGetCurrentUIRaycastResult_m873AD7A618192FDDA0B7990DCE69FD3E0FD05390,
	XRRayInteractor_TryGetCurrentUIRaycastResult_m06AD58F70472B153B2ED72C6CE602EC8F80600F9,
	XRRayInteractor_TryGetCurrentRaycast_mDF9BCCC480B67F1E423E33780E2D75B360368047,
	XRRayInteractor_UpdateBezierControlPoints_m4D3AEE19ACA147B78F66EFB00617A1D349821F64,
	XRRayInteractor_SampleQuadraticBezierPoint_mF99E85DD1BCB3A1C656B394ED00A5B97CE28596F,
	XRRayInteractor_SampleCubicBezierPoint_m4FCC23E9AEE4290F8578DA757004C2E0FC66CE85,
	XRRayInteractor_ElevateQuadraticToCubicBezier_mE079E333BE4F24BDFF31B35A4B29DC00E42EEDC7,
	XRRayInteractor_SampleProjectilePoint_mD5AAE68C6FAB7744A2D478B1E0076615A4BCFB6B,
	XRRayInteractor_CalculateProjectileParameters_m89EA1DF264CF5F32ABD024AD091BFAD1CE975360,
	XRRayInteractor_TryRead2DAxis_m6B5E0A91275EDAAE1EA3FAD7CBA14A15AF11B59E,
	XRRayInteractor_RotateAnchor_m36FD2AC828192525A141F57BDB6337043B890231,
	XRRayInteractor_TranslateAnchor_m3604BE2C6F77AF6E10F24D4F35505974707C15F8,
	XRRayInteractor_ProcessInteractor_m1881C82B2284A766690FFB544604FB963BFF4FDA,
	XRRayInteractor_get_isSelectActive_m19B054D7EF01D479910BC9B5A7A10BACBBCD1993,
	XRRayInteractor_GetValidTargets_m3BD7A590E7F3B0E56921826F434A4D16F7EB946B,
	XRRayInteractor_UpdateSamplePoints_mD0B51E5A4E0F451465CE3C163E234401C2DD697F,
	XRRayInteractor_UpdateRaycastHits_mB5D7F591CE398668F8B4C9185DEA7B07A365AF32,
	XRRayInteractor_CheckCollidersBetweenPoints_mC36DA90F348192A355B6B0FDC0AF5F708DDA446B,
	XRRayInteractor_UpdateUIHitIndex_mF0D6C7E6DA1DB671DA3FE1194E780CEA55C76894,
	XRRayInteractor_CreateBezierCurve_m5BAB7B604D8B01BD21E2AF25B0BD925345C29A15,
	XRRayInteractor_CanHover_m2100A7C5A34B1620B00CF043AD63A62716967073,
	XRRayInteractor_CanSelect_m0507A5DA43219DBB9AE8EFBBB010827EB50C4385,
	XRRayInteractor_OnSelectEntering_mA511478A84FE506514E016415F293D55B93E58F9,
	XRRayInteractor_OnSelectExiting_m77F4E955A8561D1F9107486538CF03EA2940CCD9,
	XRRayInteractor_CaptureAttachTransform_mBDB77F465D20CAEEB60408756111AAE7BED02CC3,
	XRRayInteractor_RestoreAttachTransform_mEB75D4539FC78187A17A14F009A5B89CAE77C16B,
	XRRayInteractor_SanitizeSampleFrequency_mC5778BD588E31A60C8DFA544B3998FAF73FDE9F8,
	XRRayInteractor__ctor_m7911B2AC53C4731D2B7BF9AFDFD9CB47D6A7CFC1,
	XRRayInteractor__cctor_m19E45D7A20D823826A10DD5419E06785B7CE35B8,
	RaycastHitComparer_Compare_m35FC88786C4C31D0A05D7399C3E493F746399DB6,
	RaycastHitComparer__ctor_m7354D9FDF5790BBA5DCE25BF09F3AA167A90C513,
	SamplePoint_get_position_m936C42938CBE72F7E0E0D69CC7B3A7BDE7C844C7,
	SamplePoint_set_position_m3E16630C4554106B58E1BF98C3EC58318EBBD763,
	SamplePoint_get_parameter_m84322EF1929DC8BEC41F6756BC0D3AB7BF4E2052,
	SamplePoint_set_parameter_m4D939B740644F770649CCE42F187777F65FE805A,
	XRSocketInteractor_get_showInteractableHoverMeshes_mC102B4DCEC03266C0912F0B5FBB0F363B10C0ED8,
	XRSocketInteractor_set_showInteractableHoverMeshes_m66F111C8846F033EB6069BE51C821E855151D23B,
	XRSocketInteractor_get_interactableHoverMeshMaterial_m174CCD552AE76F1585F8E50DD5185A1189804B9F,
	XRSocketInteractor_set_interactableHoverMeshMaterial_mD4B5964256A3C6B97316FAD3591AF05B95766DB5,
	XRSocketInteractor_get_interactableCantHoverMeshMaterial_mAE89B2421D313EC9B9F5DBD3448F22EC815FC9DF,
	XRSocketInteractor_set_interactableCantHoverMeshMaterial_m91F102A1757C50F47C569E01633BF66F76D399E1,
	XRSocketInteractor_get_socketActive_mB2D54E1615E846F0AAA0BA249AE4517BF269410C,
	XRSocketInteractor_set_socketActive_m0E7EA6A077BE5C53FDDCECF36B00B7AEF9498055,
	XRSocketInteractor_get_interactableHoverScale_m52DFE5CB13BC3610F422690D67BBE94FDFFFB3C8,
	XRSocketInteractor_set_interactableHoverScale_m0625AD9055F69C50CCBA05CF744FD74B5ACC7F8F,
	XRSocketInteractor_get_recycleDelayTime_m44F5FA7B381CFCD260F68D2738FF83AA740ACACD,
	XRSocketInteractor_set_recycleDelayTime_m96B6AB49E939DE7BA69165261E2E62E49B20F2A6,
	XRSocketInteractor_InteractableSortComparison_m2906766C3D9B2E0A2D95D010C508740772980598,
	XRSocketInteractor_Awake_m61293C64F70812A938AE5908A047FFBB09C4A8AF,
	XRSocketInteractor_OnTriggerEnter_m4B8CBEE7042CBF5771AFD0D327B169B4F7E97771,
	XRSocketInteractor_OnTriggerExit_m98A6B4B6222B440E2C71AB57765C0C5E25223E0B,
	XRSocketInteractor_CreateDefaultHoverMaterials_m4C49192ADDD48632B7B274ABC075383732B7BB3A,
	XRSocketInteractor_SetMaterialFade_m748E673634DAA0BFC13A303486231F0225CD8FB1,
	XRSocketInteractor_OnHoverEntering_m6F7D0542179E6B06812F290B99B4311E098DC558,
	XRSocketInteractor_OnHoverExiting_mF88506FD24ABC0D7856C4F66FB88F274AE44DD77,
	XRSocketInteractor_OnSelectExiting_m035C4A65225F67027400AA43B338BDD7F34C0146,
	XRSocketInteractor_ProcessInteractor_m89C012C732872B9FE06335587C61D8A0230A1A3D,
	XRSocketInteractor_GetInteractableAttachMatrix_m0F69D87804267DAA495A1FB5DD01A86EA5184749,
	XRSocketInteractor_DrawHoveredInteractables_m510B6F637780296099D682669E5A1EFFFFE1730D,
	XRSocketInteractor_GetValidTargets_m873238B1C7641D14F29D535C799D919EE2CF7DE2,
	XRSocketInteractor_get_isHoverActive_mDB9CF3EB632D53438D507C3BC1FA7047257AE1D6,
	XRSocketInteractor_get_isSelectActive_m49267FD7875988D8653EBC13E1FE60E8F6272892,
	XRSocketInteractor_get_requireSelectExclusive_m6549FDB88D5983F00BC676FE7D1AA9CDC90DDFFC,
	XRSocketInteractor_get_selectedInteractableMovementTypeOverride_m93A4A394F26E0984D2B3869CECD05C37A07124EE,
	XRSocketInteractor_CanSelect_m76164FD5D8638544248150699D989D4C8FBA3C60,
	XRSocketInteractor_CanHover_m3A4EEDAA8ECD7C2AD03E90D14F65599CADA9069A,
	XRSocketInteractor_ShouldDrawHoverMesh_m5E0ED4F8CC9B6ABAE6E652B935367C79B4FFC4D8,
	XRSocketInteractor_OnRegistered_mFDD3F105FA7FA03CD0704394A2D89C3C950E3EE0,
	XRSocketInteractor_OnUnregistered_m5BFE13D1762F6292EDD06401FC45C15FA2FD979A,
	XRSocketInteractor_OnInteractableUnregistered_mBB058DE64F186A984FAEB1E55C9CB7B4761FAD1A,
	XRSocketInteractor__ctor_mA9AECC24339310C8D28B7C86DA4DCA7C6730C3F2,
	XRSocketInteractor__cctor_m5261C135610BEC8E34BA0B5DCD2936D23E8DE778,
	ShaderPropertyLookup__cctor_m56508837482E0DC1CA8286B0379C705DD05F9117,
	XRInteractableEvent__ctor_mE784C1ADE5999824CBDFB841D954E948F1944436,
	XRInteractorEvent__ctor_mD73327AEF9613FBE0E3997D81852A2B9E4ECF52C,
	BaseInteractionEventArgs_get_interactor_m2119370F273F0FF0FECA442EA5D9AB5665D36E44,
	BaseInteractionEventArgs_set_interactor_m80AEBD280C3115C9C3EA56FA160BD1C120A4F7E4,
	BaseInteractionEventArgs_get_interactable_m4A4FCEF1E72EDCB1DF503141DEA939818FDF040C,
	BaseInteractionEventArgs_set_interactable_m90A6DC899E726BB45A3A57098734C280C7A482D0,
	BaseInteractionEventArgs__ctor_m9D21E804D1DEB1407C51A1F8090FF9A0265962F5,
	HoverEnterEvent__ctor_mAFCC1AFC6B069966A16783E0F2E85040CA0EDDB7,
	HoverEnterEventArgs__ctor_mB9443E41C4DE462C6488746EE7FFFC090A9C8193,
	HoverExitEvent__ctor_mD0B6D04D4042B6E461773D290E52D20E51674424,
	HoverExitEventArgs_get_isCanceled_mF796A4E1A7EB0B69D6F0C5B0D713E448324EB86C,
	HoverExitEventArgs_set_isCanceled_mDEF194AF3E45036631E8E732C1141CF638511439,
	HoverExitEventArgs__ctor_m9FBA318245CEC6F630BAF3FAB3D80095D2E6F722,
	SelectEnterEvent__ctor_m959093821735EF8DDFFAA1F6C94100F7F056EE8B,
	SelectEnterEventArgs__ctor_m9BA655B9E94E47CC651E7987A8D660F86323A7B4,
	SelectExitEvent__ctor_mD8B97D564D22BA51E86C2609FB999E0739A1D992,
	SelectExitEventArgs_get_isCanceled_m593A728ECD659A477152A4B823EC709070063ADB,
	SelectExitEventArgs_set_isCanceled_m11626375CC34F372980C171602C7FBAF68737EE7,
	SelectExitEventArgs__ctor_mCFB1C217E20C4F49D80532A2CA92D2621E1F8932,
	ActivateEvent__ctor_m1EA8D06FBF79DC5435F769D40942C5C85B2EE2BB,
	ActivateEventArgs__ctor_m8869B99604F99AD2336CC6F5BC30DC9F66AB6B98,
	DeactivateEvent__ctor_m510A01F9AC878145DB26A3777E8AB3EFC8301A5C,
	DeactivateEventArgs__ctor_mDDA4CC88A23B3D39CF8BBD68BB2AF3EB51FF4AC7,
	BaseRegistrationEventArgs_get_manager_m0BE09F10BCBCEBAC776E08F26D4241BC00C13255,
	BaseRegistrationEventArgs_set_manager_m40D70ACA0BAAE2A1E7AC9950919F2CCE0BEE946D,
	BaseRegistrationEventArgs__ctor_m64F07C2047D7BE3DDD5B517FFEC0D5837188E874,
	InteractorRegisteredEventArgs_get_interactor_m7672E6732DE1B972682365221985CFD026E2CD09,
	InteractorRegisteredEventArgs_set_interactor_m18E824F81898AB4162E2AAC4CD6AF97719F3DD33,
	InteractorRegisteredEventArgs__ctor_m449479C1AB4804EE101B9D0FA3E620B9079E8CB2,
	InteractableRegisteredEventArgs_get_interactable_mD7C8057ACBBA5F72AD29B4F4F8F2F5C6563AF6F3,
	InteractableRegisteredEventArgs_set_interactable_m478BBE07FB963EFACFFF23861746783CE14DE5A9,
	InteractableRegisteredEventArgs__ctor_m59D059C054EF27AD86321B656D34D0E4CFF00B62,
	InteractorUnregisteredEventArgs_get_interactor_mECA1820CF23F4202E12DEB5DD581D942C3ECF42D,
	InteractorUnregisteredEventArgs_set_interactor_mEA454964958CA35141EA95E67FCFC0D6C458C17D,
	InteractorUnregisteredEventArgs__ctor_mF10FC0040D2BBE5C5DE20E2360A2A2A2FA8E6498,
	InteractableUnregisteredEventArgs_get_interactable_m3EF93A750D56C53A1BF9D57F8E1ABE1001CC7393,
	InteractableUnregisteredEventArgs_set_interactable_mA1A7F69950F7BCD6AD8D25DF465BE3D137D59446,
	InteractableUnregisteredEventArgs__ctor_m99E54FFE0A2814C9CB0E608BCB06F16EC31DDAA8,
	XRInteractionManager_add_interactorRegistered_m028E5BD40AA93199943D55D64BD33857084F1A48,
	XRInteractionManager_remove_interactorRegistered_m9992F01E9C648A44B2986261DB5F8B0624C88593,
	XRInteractionManager_add_interactorUnregistered_m9BD30E6767B10E7482B2FE582A0CA246B1C86DAD,
	XRInteractionManager_remove_interactorUnregistered_m31CD1EFC13322B2C6D866C9B21BF4BA002FFED22,
	XRInteractionManager_add_interactableRegistered_m46FAA4E08BCAA5777F070A85EA6A9D90B2545A60,
	XRInteractionManager_remove_interactableRegistered_m8573CC9BD4B53197061E6C236378EA9D2143281A,
	XRInteractionManager_add_interactableUnregistered_m5976273A58891E10B184536C4856B4A2A1F25CBE,
	XRInteractionManager_remove_interactableUnregistered_mD066EA86F5BA0F0435E18A841705836E7AD7D038,
	XRInteractionManager_get_interactors_mD18E7D1D0F8E0EB35762B8994F93053793487807,
	XRInteractionManager_get_interactables_m11B804403DE9F2BB1154376AEBBCDC802B4891F5,
	XRInteractionManager_OnEnable_m9FDECF903D46AE6BF074875277F02B2F9E58E658,
	XRInteractionManager_OnDisable_m8EDF8DD4141E19BF57A7E6D8E2F9D476C64555EC,
	XRInteractionManager_Update_mC28274BF7E3C03C69E45A05524872FB627A354D4,
	XRInteractionManager_LateUpdate_m04D4A01C8F027B6AFA66A561E8909A0C10D0B51E,
	XRInteractionManager_FixedUpdate_mB1DA91D4122F45254E3051F8368706FBC394E20F,
	XRInteractionManager_OnBeforeRender_m5A5C4B4DD7AABB3F8400AD34CA74725E5AD09A5F,
	XRInteractionManager_ProcessInteractors_m6CDE192CAA3D672EE4D8BCC8DD4D0595C9D0E185,
	XRInteractionManager_ProcessInteractables_m53573237519A0688BCBB243FB537E7DD1E9B17DD,
	XRInteractionManager_RegisterInteractor_m57441A810CF20A9D88C3E283537E791649AA4F1B,
	XRInteractionManager_UnregisterInteractor_m9AE293B5FE479C9860D1AC86297E3B59A3234D5D,
	XRInteractionManager_RegisterInteractable_mD0342CCA15534CF70643BE99563B3ADD44D5805E,
	XRInteractionManager_UnregisterInteractable_m49277C2EC6634C9BBAD397696C07DD2E4BCFAD03,
	XRInteractionManager_GetRegisteredInteractors_m0D379B8D37C8ECA19C7B81D7CF4F065DA7FC19DD,
	XRInteractionManager_GetRegisteredInteractables_m91697286C20DCD7F607F2F0A30EA44E3B4A11415,
	XRInteractionManager_TryGetInteractableForCollider_m562D8877127749E4F7AA046FF66D26C43637B453,
	XRInteractionManager_GetInteractableForCollider_m5BECE120C446F3793D2610A676F53E64B8BB81A9,
	XRInteractionManager_GetColliderToInteractableMap_m62EC335B889430B8BF99B61D818C05977E9A64DC,
	XRInteractionManager_GetValidTargets_m4622E94A65A4B738B58B65448CAE7A9405E6B2DE,
	XRInteractionManager_ForceSelect_m82C4EA94E6CCFDDC3C666E439529E1BD50C19501,
	XRInteractionManager_ClearInteractorSelection_mA6F6EA4602A14A2978EEDA285BEADE008A6B9318,
	XRInteractionManager_CancelInteractorSelection_m24C3DD25878F6D9072FA8A31891197CC1739AC7A,
	XRInteractionManager_CancelInteractableSelection_m47BA2937242C8195F48A736C7C17E3A4024CAF3A,
	XRInteractionManager_ClearInteractorHover_m9C1469AD953EB7B3F621C5562033F5DD67297D94,
	XRInteractionManager_CancelInteractorHover_m57431CBBB17D68421738CFAA6203DC4F64CFE74B,
	XRInteractionManager_CancelInteractableHover_mDEE3701E6C7B470F077F6682CF2565B742D2E93A,
	XRInteractionManager_SelectEnter_m07A0B1CE6080F54C1309174B68E8A686A416B51C,
	XRInteractionManager_SelectExit_m7BE6481CA3A08C4C2CAB3EE19C00D14F0A27EBB4,
	XRInteractionManager_SelectCancel_m11736AC32BF92590098B18E0CB2D8816101762BB,
	XRInteractionManager_HoverEnter_mE0D0F6540131E548B123AC5626DE2338497904CD,
	XRInteractionManager_HoverExit_m340E30FB80910036EB87DADAED8679B894E5BDBA,
	XRInteractionManager_HoverCancel_m6668BC4C4AA510316234AA9FA912F3B260FEE0C7,
	XRInteractionManager_SelectEnter_mF37CD6E998946ACA8F6033842E404ACB611E9B7B,
	XRInteractionManager_SelectExit_mE89596A7DFBFB1D119676A7313611B5AB0CB29DA,
	XRInteractionManager_HoverEnter_m2951929D0C14E387477E0BCC4777287DD89BAEC2,
	XRInteractionManager_HoverExit_mC3D977507246F5F59D64994C3BF29B4DADD481BF,
	XRInteractionManager_InteractorSelectValidTargets_m092D8536E08C5E5332CBE5303135E863EA81CC5D,
	XRInteractionManager_InteractorHoverValidTargets_mDF1F4BD6AF98AD76BBDF482D7576ED103DC32F8A,
	XRInteractionManager__ctor_mA88BB165F8110638607F2CB82CCF8F5D0203004F,
	CharacterControllerDriver_get_locomotionProvider_mD201F16F81932BF45B82607E697FD6883F583D66,
	CharacterControllerDriver_set_locomotionProvider_mCD84E7CE3B73224EE8B70D9C866E32830303821A,
	CharacterControllerDriver_get_minHeight_m953D2494ED979FB2261B6B8D81FA47A30E097D0E,
	CharacterControllerDriver_set_minHeight_mBA697B5D138AB4A323E80FFAEEA3288E1BC31366,
	CharacterControllerDriver_get_maxHeight_m918C15CEACFCF200494B97EC1A6FB812DBAC54A7,
	CharacterControllerDriver_set_maxHeight_mB9045529749D310B4AAA4121B930A7E991747109,
	CharacterControllerDriver_get_xrRig_m24AFC40E3B05BD7BB70B1D704E26DABCA9E43455,
	CharacterControllerDriver_get_characterController_mA8853F27086BB5E59DC581793137C903995EE9E5,
	CharacterControllerDriver_Awake_m59F3E334507F8BDCF23A087F84E8B96768237E91,
	CharacterControllerDriver_OnEnable_m7B5E66AD1FE4FBBBE3D165D59C88036343DB9A39,
	CharacterControllerDriver_OnDisable_m0D2A94CE7E22F81FD1715C47FF39C61606D72932,
	CharacterControllerDriver_Start_m2B6CB5A0A787F657D8875C384B6298AAC36DC67D,
	CharacterControllerDriver_UpdateCharacterController_m1733EE9F12247CFE7F9C2204E77B2DA43F375350,
	CharacterControllerDriver_Subscribe_mB23C7A0B5569EA3EFA55D541F7F6F647B1DA0C40,
	CharacterControllerDriver_Unsubscribe_m4DA59BAE83365BF6D3F0EB9AC01E667F0702B4E9,
	CharacterControllerDriver_SetupCharacterController_m5EB4C8731A91E72961BB2B3841FFC3E0990EDC90,
	CharacterControllerDriver_OnBeginLocomotion_mCB4A9583BC6AF9C7688C03B2CC474FB760B02FBD,
	CharacterControllerDriver_OnEndLocomotion_m162F58337E942F72AEF998F68631E2AE0D849A75,
	CharacterControllerDriver__ctor_m45A42CC13D2A337297B13FA6EC0733479B481D0C,
	ActionBasedContinuousMoveProvider_get_leftHandMoveAction_m585B2C55F246B2A87A5ACCC0BB2C5EEC915E7BFB,
	ActionBasedContinuousMoveProvider_set_leftHandMoveAction_mDB3E0196C9ADAAE083233989124B1FA603A35072,
	ActionBasedContinuousMoveProvider_get_rightHandMoveAction_mF59A3C167F1BDA9402409B3B1135F2A9E32FB88C,
	ActionBasedContinuousMoveProvider_set_rightHandMoveAction_m70FDF807430951C58B446DBB59B362757A169921,
	ActionBasedContinuousMoveProvider_OnEnable_mE9CE0DA8C13777B516CA4FB998F6496BBF6B3C46,
	ActionBasedContinuousMoveProvider_OnDisable_m9E322025AFFB3379B3F5B5FC4BC2DFC106D4BA78,
	ActionBasedContinuousMoveProvider_ReadInput_mC08E030C91C46C7D1FDE15BC940388D1ECCF070F,
	ActionBasedContinuousMoveProvider_SetInputActionProperty_mF3BA0FD3068AC13E17C7E6BEF2745C867010166D,
	ActionBasedContinuousMoveProvider__ctor_m38CF25142F1C48B3EADD8239E98859588C046D45,
	ActionBasedContinuousTurnProvider_get_leftHandTurnAction_mECA2124789B7032A0EAA63DB5FE7AEF3CC3E2CC4,
	ActionBasedContinuousTurnProvider_set_leftHandTurnAction_m13ACF7DCCD5D6D84F09D7DCE0C0203C5430531A0,
	ActionBasedContinuousTurnProvider_get_rightHandTurnAction_m0EEF7F6E48EADFB7F60659B62EF49E6044E12858,
	ActionBasedContinuousTurnProvider_set_rightHandTurnAction_mFA90EBD966286D9F44256A23EE6847F5B19415A2,
	ActionBasedContinuousTurnProvider_OnEnable_m9156DAF675AFD3D509687D43A665C4B719FE6CD7,
	ActionBasedContinuousTurnProvider_OnDisable_mB78334F6C42D60AF496D3106361C38594EFC6985,
	ActionBasedContinuousTurnProvider_ReadInput_mDA82F08C605330A6AEEB19FE64FEF5DC3D26225A,
	ActionBasedContinuousTurnProvider_SetInputActionProperty_m6AAF8E97E07CD78BCABD760F9192CC59A9A51B30,
	ActionBasedContinuousTurnProvider__ctor_m0C6ED35454030ADE9B1DB13C414D24BE13ECF8F7,
	ContinuousMoveProviderBase_get_moveSpeed_mB35DBBCA51BA43717E4FDDF0DBF244AC9F16F0FB,
	ContinuousMoveProviderBase_set_moveSpeed_m6857F6935CC04747A26BC3212208B45493A44787,
	ContinuousMoveProviderBase_get_enableStrafe_m7F0C7FB5279860E11B2E64B50049EBFD19EDBFC0,
	ContinuousMoveProviderBase_set_enableStrafe_m370B15DF41B848E9B913A90F3AF82CDA5C9B408D,
	ContinuousMoveProviderBase_get_useGravity_m33A2948B0CDC4385B0A65032AFFFA17AD1F9DE65,
	ContinuousMoveProviderBase_set_useGravity_mEE6AB574B9DD4F122FF36B00CF00F33AEACFD210,
	ContinuousMoveProviderBase_get_gravityApplicationMode_m3D5074A6746EBDA71D14FB7965E92F2D84C265EF,
	ContinuousMoveProviderBase_set_gravityApplicationMode_m556D5AEB0FA0D715EE3ED26A4F92B9A900C0A9F1,
	ContinuousMoveProviderBase_get_forwardSource_mBCBDBDED98D85729417FE422E11E1CC751152F1B,
	ContinuousMoveProviderBase_set_forwardSource_mFC654F04903F2517D5AF32028B2216DEFF341BEB,
	ContinuousMoveProviderBase_Update_m0898231FFDD27E5A34AAFD66365D75B9014B5482,
	NULL,
	ContinuousMoveProviderBase_ComputeDesiredMove_m1ED66E077EE95558BB97BE6FC237EA3B33039747,
	ContinuousMoveProviderBase_MoveRig_m479CFA45F3A2A7E50660EBC26B9332FD61DEA8E1,
	ContinuousMoveProviderBase_FindCharacterController_m112987766A2FDA2B3F3DEE777A3C08C232B2541F,
	ContinuousMoveProviderBase__ctor_m644DF2183D256C093F77CA7EC1B6AD1B679D2C90,
	ContinuousTurnProviderBase_get_turnSpeed_mF8C6211778DC7D5A89421CF9FED06D66D695C9A6,
	ContinuousTurnProviderBase_set_turnSpeed_m3FF87994730F28EB79AB1B9831B3FB9BFAF0D378,
	ContinuousTurnProviderBase_Update_m3A0E96663B17515699224E36BFCFDE2BE454217B,
	NULL,
	ContinuousTurnProviderBase_GetTurnAmount_m3FDECC773878364A1350F781C59093010C7C6E64,
	ContinuousTurnProviderBase_TurnRig_m4F3D9FB0282AE8F658E9E1659112BAC2287A5C9D,
	ContinuousTurnProviderBase__ctor_m1C0D394910C854391E522890A21BABEF063116AC,
	DeviceBasedContinuousMoveProvider_get_inputBinding_mF4B177D18A5A392F134F5813FA6CCA66D4887082,
	DeviceBasedContinuousMoveProvider_set_inputBinding_m6070E8A8887BAB81CFBAA604F5E81800DFD7DC30,
	DeviceBasedContinuousMoveProvider_get_controllers_mE1238E31FD47FA9878DC32F11975D32C4D189A76,
	DeviceBasedContinuousMoveProvider_set_controllers_m84B24F7B0EFFDFDF803778FFDD7F24AD95B899A7,
	DeviceBasedContinuousMoveProvider_get_deadzoneMin_mAF456993DCAB6F76D049CDF192000BA379A90138,
	DeviceBasedContinuousMoveProvider_set_deadzoneMin_mB07962A31B0B1EB27824B549A3D345B4183141BA,
	DeviceBasedContinuousMoveProvider_get_deadzoneMax_mC7506B5B6918A3164473C3EB35679AF270A78282,
	DeviceBasedContinuousMoveProvider_set_deadzoneMax_mD7AA56BFE8C174E0D0C0F1E30D1E1F57748157BE,
	DeviceBasedContinuousMoveProvider_ReadInput_m6201C30338A93716EF402F7DDB417A102A779359,
	DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_mC12A8A7C6896ECBF4FBBBC6736086A84C38D9673,
	DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m3CB229A0AB4C5A9A3A47626A5562C6913ED417D6,
	DeviceBasedContinuousMoveProvider__ctor_m18DEBAE9A2C792802B6396ACD664679ADE30DBD0,
	DeviceBasedContinuousMoveProvider__cctor_m694EF72DDDA6CC1D6C27ED50EE15CED52816B709,
	DeviceBasedContinuousTurnProvider_get_inputBinding_mB6E7C3FE7B3F4C1C425405ED6009A688E4B3C04D,
	DeviceBasedContinuousTurnProvider_set_inputBinding_m5F67E5062D00550ABD82576614F96C484A9E371F,
	DeviceBasedContinuousTurnProvider_get_controllers_mAA9E9FAF9573955E8EE2EABEC1B6BD078B37CC12,
	DeviceBasedContinuousTurnProvider_set_controllers_m11F44482007F5F08730F3CF077FFF3A1FCF6CDA3,
	DeviceBasedContinuousTurnProvider_get_deadzoneMin_mEEEB887C0736DE3CFC0AEB9EC696D159871840D1,
	DeviceBasedContinuousTurnProvider_set_deadzoneMin_m2EF1826AAEFE70723D0B46E15674AB88A26D982A,
	DeviceBasedContinuousTurnProvider_get_deadzoneMax_mCBA4970CAF6554084E23646F3DED00D4068B9427,
	DeviceBasedContinuousTurnProvider_set_deadzoneMax_m9D891997C8E208EF2904CD7884777D6F8A4921C3,
	DeviceBasedContinuousTurnProvider_ReadInput_mBACBE07C39754C1731FC3B065A0399305518AD34,
	DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m0E79D4BB0E4C55459053ED25742AA0DFC203EB5D,
	DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m1C40C21EB01A3959BABDCDDA7CA438994BDEEDDC,
	DeviceBasedContinuousTurnProvider__ctor_m2116020C2A06352F23EBB29878039A8E7F56D2C0,
	DeviceBasedContinuousTurnProvider__cctor_mA0DB9341DA18953A6C6370C6B4625966445AAE3E,
	LocomotionProvider_add_startLocomotion_mF8FF9FC82F52A023063192BE0CB0100971035521,
	LocomotionProvider_remove_startLocomotion_m7880E20F2705D62783AB798C485CE6A6E2CB985D,
	LocomotionProvider_add_beginLocomotion_mB1DCE91B13F70386CE4678E9B1215E2863F0007E,
	LocomotionProvider_remove_beginLocomotion_m707A5CA2BD73D33C412C60D5E33523A6ACE4E563,
	LocomotionProvider_add_endLocomotion_mB28CF916E102064979AE16EA147986F16BD30E5E,
	LocomotionProvider_remove_endLocomotion_m42DAB46E1B5303FCCE8116B8F3048544A71132A8,
	LocomotionProvider_get_system_m03FA085476B700DA9942A3B6DF3B8D3C2D7D36F1,
	LocomotionProvider_set_system_m0E7D1C4EB5D52947B2F9531618F9AA11422A6B5A,
	LocomotionProvider_Awake_m8C8152BA75A1C6E84378FDA7EFD28B527A81F0A5,
	LocomotionProvider_CanBeginLocomotion_m8552DB4BE5E1B705738A07340929D7EDE1FD1206,
	LocomotionProvider_BeginLocomotion_m74F554EA479426FF97F8A736BB0EB80CD6740624,
	LocomotionProvider_EndLocomotion_m9A60A3BF116B5CE6B5CDD56F6FE23121C42A9E7F,
	LocomotionProvider__ctor_m0062E45F994311909006A8B0BB3216CC4AA7CE3D,
	LocomotionSystem_get_timeout_m492A9A01A654E00B83E5D26778F61138FB970C0F,
	LocomotionSystem_set_timeout_m7C4398A26F09DFFBFA16AC61501CAF13C8F868C4,
	LocomotionSystem_get_xrRig_m26984B689162D0BF017A639B8E5B0FF64FCA66AD,
	LocomotionSystem_set_xrRig_mEC499C8C39ECA137808C0CA5F1706B4EEDD5B5D4,
	LocomotionSystem_get_busy_mEC4146B85EEF5A9EEAC21E1ABC42CEA4D6294774,
	LocomotionSystem_get_Busy_mE672634BA551C4C394815E29CB422A28B5465B43,
	LocomotionSystem_Awake_m7947F6DF55DB2CE711E1358DB083F2B3E4002FA7,
	LocomotionSystem_Update_m6926179639E59CFE420DD791AF5F107FC42802DC,
	LocomotionSystem_RequestExclusiveOperation_m76BBDC06D91F6601CC47079A4679CF433314DEEE,
	LocomotionSystem_ResetExclusivity_m077697D69683C5591955EB726F98A2D9E8771E60,
	LocomotionSystem_FinishExclusiveOperation_mA26B93855591AD5EA05A1EE74E4FE151544F1964,
	LocomotionSystem__ctor_m7517AD2B471AA7C1949BB4D3DAEE33A749EEE96C,
	ActionBasedSnapTurnProvider_get_leftHandSnapTurnAction_m992D03F984386EB16DAA0AFCA10C663EBE615B3A,
	ActionBasedSnapTurnProvider_set_leftHandSnapTurnAction_m096518E81762922A166F371D48E113859F7DFFCC,
	ActionBasedSnapTurnProvider_get_rightHandSnapTurnAction_mD494FA951DE44A3580811E2578628344E7923CBD,
	ActionBasedSnapTurnProvider_set_rightHandSnapTurnAction_m3BFE9318BF525AE207BCF71DEA8DC549FF9F697B,
	ActionBasedSnapTurnProvider_OnEnable_m2236EEAA3DCEE8017A3D84DDE3E2A40857B236B2,
	ActionBasedSnapTurnProvider_OnDisable_mEFBE4A56969A3BD4A7C668F6C3ACC83C46031E12,
	ActionBasedSnapTurnProvider_ReadInput_mF8DB851EBB2EBD051CE15CCC75B8EC8E64FE4795,
	ActionBasedSnapTurnProvider_SetInputActionProperty_m464E172E61770640FE2088274B9FC9087911890D,
	ActionBasedSnapTurnProvider__ctor_m52903AE39ADC9E84C44020BCD8CFCA79AD5E1406,
	DeviceBasedSnapTurnProvider_get_turnUsage_m40896A6B2D2B46DD6B2B8D3208CD7E4C619BA708,
	DeviceBasedSnapTurnProvider_set_turnUsage_mF067C956C887589A96C864A3948A9C9784DC8134,
	DeviceBasedSnapTurnProvider_get_controllers_m7B042725877E406FF7BEF73F585800CBE1692900,
	DeviceBasedSnapTurnProvider_set_controllers_mCB6BA3079122509351693F9996888CC759C4676F,
	DeviceBasedSnapTurnProvider_get_deadZone_mD16CDEB507AE4C08341A54F73DC45D1B1054AD60,
	DeviceBasedSnapTurnProvider_set_deadZone_mF2A0C6F44A9343C0FFEBDEA841FCC003A03AB0A4,
	DeviceBasedSnapTurnProvider_ReadInput_mCB5024ABD78C7D8124ADCEFAEE9C35EF07602EA5,
	DeviceBasedSnapTurnProvider__ctor_mC138D69CFAB5D407406ED459D97524BB5FA97E03,
	DeviceBasedSnapTurnProvider__cctor_mA1BFD4715D742BD90973746757A36D75856A3244,
	SnapTurnProviderBase_get_turnAmount_mB934A9515106A451B2AFE216E8A6440B34F9995A,
	SnapTurnProviderBase_set_turnAmount_m3AE35E140A4A064C5444BD6DCBDC3E6F4A17F6C7,
	SnapTurnProviderBase_get_debounceTime_m58EF18A3C288BA99B6EE6D42ABBA481D18225CD1,
	SnapTurnProviderBase_set_debounceTime_mA3A71F981B7AB3FE4EA549700A00A31EDE0BCDCF,
	SnapTurnProviderBase_get_enableTurnLeftRight_mCE216102A30A809F524228B2688AE4CD69A72E8E,
	SnapTurnProviderBase_set_enableTurnLeftRight_mE37E00B0AEF96E72C5A725657704899C5A7A2050,
	SnapTurnProviderBase_get_enableTurnAround_mB79C94E50BC13E2B41CE7F44AD804CD4A6120F3F,
	SnapTurnProviderBase_set_enableTurnAround_m1967C968578C79810E812C1430DBEED772940DA0,
	SnapTurnProviderBase_Update_mE3B3F1550F5EE35D2546D419D749C0F1E1B6D835,
	NULL,
	SnapTurnProviderBase_GetTurnAmount_m4C5F368F5D1DDB8CA050F871C755F749E33A8FD8,
	SnapTurnProviderBase_StartTurn_m47F3693CDD1A77D7F3F8B246A3EB560D5DEACA28,
	SnapTurnProviderBase_FakeStartTurn_mD7EE8938E63D4DE32735CD08E64536C9B7FAB795,
	SnapTurnProviderBase_FakeStartTurnAround_mBA49D5A87D3CA3ABCB4688BF38CE504C371C860D,
	SnapTurnProviderBase__ctor_mC7A394104AB6C51DCFEE6F009EE4A0542EAD2C3D,
	BaseTeleportationInteractable_get_teleportationProvider_m7F11373094593BE6800DF0F2E1A4E07122C77D4C,
	BaseTeleportationInteractable_set_teleportationProvider_m13EE75A5801ECDC6F499236678678912DCBD8EE0,
	BaseTeleportationInteractable_get_matchOrientation_m6A3A79A9F2B8A7B9EED84965030CF572A2BA8088,
	BaseTeleportationInteractable_set_matchOrientation_m65DE908A81D711663C0960CA47E9F572A2C57C23,
	BaseTeleportationInteractable_get_teleportTrigger_m9736C0E38FB52F8D788AB68D23A3924FE3350CC6,
	BaseTeleportationInteractable_set_teleportTrigger_m6963317C85ABB863768A08AD9BEC70A872406243,
	BaseTeleportationInteractable_Awake_m2E45F04A714A0E3A7BA523FBD5D4E27CDA67CF8D,
	BaseTeleportationInteractable_GenerateTeleportRequest_m02AC569EBA728EB910FE3172F83AFE25D912D109,
	BaseTeleportationInteractable_SendTeleportRequest_m06966E4550BD6473B924337BB96329295F414730,
	BaseTeleportationInteractable_OnSelectEntered_m34FEDC72505B26632A3C8B424C3893F074EFE5E6,
	BaseTeleportationInteractable_OnSelectExited_mC0044A385D2E8094C38AAA6134A4AAFE2F8B17B3,
	BaseTeleportationInteractable_OnActivated_m1C14C70FB9573A6C539254C3C5A588677EE7FD6A,
	BaseTeleportationInteractable_OnDeactivated_mB7A1EAC5E50867C549BACF9A37D6B13C139CC367,
	BaseTeleportationInteractable__ctor_m73D4E147FCDC9B5ADA3A990DAA59529D505358FD,
	TeleportationAnchor_get_teleportAnchorTransform_mB649F7195B32C5938C34F037FA3C299939E1372C,
	TeleportationAnchor_set_teleportAnchorTransform_mFC13614FCC73FA077DF8221A572067A47E73C1AB,
	TeleportationAnchor_OnValidate_m236595E662A5C0FAEC63CEB42B1030802AD9E374,
	TeleportationAnchor_OnDrawGizmos_mD5E293A0DF7EDA594BC772AECD58E3E9079DF78F,
	TeleportationAnchor_GenerateTeleportRequest_m9F32F7582D779E78248D13B168B540AAD6D54AE2,
	TeleportationAnchor__ctor_mC91D25351178CFA93D95CCA34213B2D2FB17A3CA,
	TeleportationArea_GenerateTeleportRequest_mA4D89EF67A4C11EC1E0FCEF196F01AA2BEDCF9CF,
	TeleportationArea__ctor_m981C857E5A856A01B3A5E7002E139D8FA16A2CD1,
	TeleportationProvider_get_currentRequest_mAE80EC4214026855B58E95F11698934A70EF3AE0,
	TeleportationProvider_set_currentRequest_mB7A7C5C75CBDAA8E39790D872CC6A1EC7D0AEB6D,
	TeleportationProvider_get_validRequest_m2AD7C84DF0321684BE2A80B9F93CC8CF496D776B,
	TeleportationProvider_set_validRequest_m12632B25FF5A8653A77FE6277FD440E0DFB8A4D2,
	TeleportationProvider_QueueTeleportRequest_mFEA3C48C18C7BC9041C239FCB854FF258DEEA9F4,
	TeleportationProvider_Update_m558B546E4D8EBC8DFEC205185DC2D4931DBD66F8,
	TeleportationProvider__ctor_mA68401AFB5FC65D62C2EB35E74B573274D6B5E1D,
	GizmoHelpers_DrawWirePlaneOriented_m5DA33156AB2E62F9A782B27255C036A18614CB26,
	GizmoHelpers_DrawWireCubeOriented_m2D604FE35E9C6B47B7A2E443539CED3B841174CC,
	GizmoHelpers_DrawAxisArrows_m59A73957FCA515A992DAF4F501141D4F79753988,
	NULL,
	XRRig_get_rig_m9E851C240AF6392715E45FBCEB17905C81D4D067,
	XRRig_set_rig_m06D3941E6FFDEB18288AF6875030F94477FCDD08,
	XRRig_get_cameraFloorOffsetObject_m84D130B76715FC55D84720B6EF2E61ED71236384,
	XRRig_set_cameraFloorOffsetObject_m2EA7E9A64EA92C9AC5F6E6210EB4535BA7B66185,
	XRRig_get_cameraGameObject_mC07CE95931449E7335ABDA829BB64A7D24A7E254,
	XRRig_set_cameraGameObject_mBB083AC5AEECE2291BD13079B4DFD1D14BC5B8C8,
	XRRig_get_trackingOriginMode_mF6BA9EC5AFF0B7F770D79A28375F557D7A56F7BF,
	XRRig_set_trackingOriginMode_mE7E827E41DE3A46B15D1D9E4FF50BF52B67D1DB7,
	XRRig_get_trackingSpace_m55D7131E5B68227B8B78F22ECE2EAB91406CF321,
	XRRig_set_trackingSpace_mEB17DC6C896A210B97052DA27209A4DBC21FA660,
	XRRig_get_cameraYOffset_mEFBA7480902AAA160131FB9814C8CF33C035B19E,
	XRRig_set_cameraYOffset_mD05CD10A47A6EA8CEC9A3C91C119B5E3F0E3D30E,
	XRRig_get_rigInCameraSpacePos_m46BDA6929B22BB60943929DF68C03F2D95AE30D4,
	XRRig_get_cameraInRigSpacePos_m6C414B6DB5C5773DD6F968A0A30B9A15175C537B,
	XRRig_get_cameraInRigSpaceHeight_m645FBDEEF6A42A35315BF06CAC5BD50B01C96322,
	XRRig_OnValidate_m3C3C5F4CF76DA05E9E4FEE5D2EE3B4DA0436EAA5,
	XRRig_Awake_mAD97FBC51DF1F48F3825C4B8C69B465C8A8D76F9,
	XRRig_Start_mF38344274D62DC649AEDCA9B5847040D0E735E88,
	XRRig_OnDestroy_mAAABBAC2991D7FD41876C72889ED813D73C2A04A,
	XRRig_OnDrawGizmos_mA5BFDAA4D5D122B126C33C51569EB117C52E3EFC,
	XRRig_UpgradeTrackingSpaceToTrackingOriginMode_m2558C531D747FAD837B16B0B6F2A9CA01E7C8F02,
	XRRig_TryInitializeCamera_m8C4BA56E4A4FA3D2A177EF179E820463F90B5742,
	XRRig_RepeatInitializeCamera_mFFF933EDE636C322553254DDD98081E4131036F3,
	XRRig_SetupCamera_m28054289B880D4DF29402ACCA09773DC501255BB,
	XRRig_OnInputSubsystemTrackingOriginUpdated_m85689F7869FCEA7903C699FED57083DC19EB706E,
	XRRig_SetupCamera_mCB7223E75C1DE2B715FD7B87F3C178C9A3648534,
	XRRig_SetupCameraLegacy_mCD13F0D825E482C1550DFB935500B8C73CB56057,
	XRRig_MoveOffsetHeight_m71208C9AF0BD19610C340719D8648547DE8F55A2,
	XRRig_MoveOffsetHeight_m8DEA1993C9C27EC13C79C2E8E2EB1AB08598C5F8,
	XRRig_RotateAroundCameraUsingRigUp_mB7E04DE02F255309A7FCD53EA98CAE62598923A1,
	XRRig_RotateAroundCameraPosition_m1ABD14C5C421C068C8DEE86EE07B3C61D3FFDBBB,
	XRRig_MatchRigUp_m5C68647D22F132B361B37935927C92CD1B18E5D3,
	XRRig_MatchRigUpCameraForward_mEB1C7FF65F31A987DC2F1EA1454B04F7A9C17E26,
	XRRig_MatchRigUpRigForward_m2C2F90C6001ED0929B481AA6B27C4E1E4940F0AC,
	XRRig_MoveCameraToWorldLocation_m4F880AD13BE30D928A549462732E285F991F6B36,
	XRRig__ctor_m535BE59B97E32AEC098F138B616B4A0A116FADB4,
	XRRig__cctor_m64BB40DB1C07DA7F793C19F56A50EE4E415C4F3A,
	XRRig_U3COnValidateU3Eg__IsModeStaleU7C34_0_m971065ABBB177C6B81B71A9321EA501E62D6E075,
	U3CRepeatInitializeCameraU3Ed__41__ctor_mC7E575C1EB31E061E1EF4768E5B950575A355D4D,
	U3CRepeatInitializeCameraU3Ed__41_System_IDisposable_Dispose_mA63AB6F487659558A0167EEAA72FF9D9F1A8B491,
	U3CRepeatInitializeCameraU3Ed__41_MoveNext_m3EA404B83FF0A26A088D5E9DA63F2CEB7A6BF98C,
	U3CRepeatInitializeCameraU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6BB9A2E9614E547FBEA2D33CBFC8105A0CE2B75E,
	U3CRepeatInitializeCameraU3Ed__41_System_Collections_IEnumerator_Reset_m77720BF240FD98DE95F2E9A77EB9C45DDFEBAEE5,
	U3CRepeatInitializeCameraU3Ed__41_System_Collections_IEnumerator_get_Current_m0EF5D447B24A5A59CAD41CBE418CA2C031DA01AF,
	JoystickModel_get_move_m70AE9CDFB7AA66AAFD351D97782ABEB641AA5530,
	JoystickModel_set_move_mF7448D0EB096CAE4AA3BA600AFD9C256BDB92DEE,
	JoystickModel_get_submitButtonDown_m4781AB6841EF967FE735A0CBDDC8B7D2C9A824FD,
	JoystickModel_set_submitButtonDown_m9836DBA6465E2649DD252CFCE998A20560378AA3,
	JoystickModel_get_submitButtonDelta_m13E6E73ED3FCDE1542C07A452F79728A22D60291,
	JoystickModel_set_submitButtonDelta_mF1EEFF5C310C6BCD9524ECC014E72238F4F237D9,
	JoystickModel_get_cancelButtonDown_m4EA1958676D8288D201EC0B465D97A1B3FF20439,
	JoystickModel_set_cancelButtonDown_m73092D4996A375205A17AEDA95436DE3A2F04C1C,
	JoystickModel_get_cancelButtonDelta_m2FF7638404C12972C68BB76D67A238D68405DDA7,
	JoystickModel_set_cancelButtonDelta_m1BA93A60D4381707771AE5BB23B2A29B0F0C899B,
	JoystickModel_get_implementationData_mEE5E6D8DC8F4FFB90D22903F7550CCAA1A038E05,
	JoystickModel_set_implementationData_mF353000BE7A505F9092D70AAD885488CD1A7557B,
	JoystickModel_Reset_m5450A9CD3FC27AA60735EC7A606F7642219B43FB,
	JoystickModel_OnFrameFinished_mEB59B1809C70BC70F9ED9A7A5242FB8340622279,
	ImplementationData_get_consecutiveMoveCount_mA34C0AD68D78BF9EFEB3E99ACF6EEC725DE26340,
	ImplementationData_set_consecutiveMoveCount_m940C6C09D01210E8D6DBF3DFF86464B40ACA4C54,
	ImplementationData_get_lastMoveDirection_m0F197FADF10FD88BEDFAF6570BE8A925BB606E7E,
	ImplementationData_set_lastMoveDirection_mB59C221E12AD9B5BADCEDA075D9BDF47C5ED5080,
	ImplementationData_get_lastMoveTime_mAE3D5AB7B9E7F6A14889824AA76455A95C0A691A,
	ImplementationData_set_lastMoveTime_m47ECDDF47D60E0A246C83E686B79A1AA3B618A4A,
	ImplementationData_Reset_mC7E2D248AB737031A8D4EE9820CF3F64C412967D,
	MouseButtonModel_get_isDown_m1CD763098303E22C163F3C680CCB3641E42F5356,
	MouseButtonModel_set_isDown_mB524856AE27BCB72E4FA521057966A08DF908483,
	MouseButtonModel_get_lastFrameDelta_mD9ABCE054D580DD7206A39288CE66DA6A946570B,
	MouseButtonModel_set_lastFrameDelta_m92B6FEE2BCB34EB047B3CA5DF2DC9316D2C7D8F4,
	MouseButtonModel_Reset_mC058FBA77FD6DDBF8BFB5CF76EE8C50F56227C06,
	MouseButtonModel_OnFrameFinished_mE55F730CAF06370BA6AB621D6932657637FBE2B8,
	MouseButtonModel_CopyTo_m81FB09020B8E0D0AE381CC861ED6AC2EF8B152FE,
	MouseButtonModel_CopyFrom_mDE54553AD7233A14E41F9806588D6E42BA79B3B7,
	ImplementationData_get_isDragging_m286676B035D542856422C65A38C50CD08348200F,
	ImplementationData_set_isDragging_m9EE85DCF9962AF0F2FF6D8A3B8DDEB33ACDEDD33,
	ImplementationData_get_pressedTime_m236A0F23942FAD42399B859634DDBA443D3E2906,
	ImplementationData_set_pressedTime_m4C64E9BB61F646ECB6CFCFB4DAF2009709A956FE,
	ImplementationData_get_pressedPosition_mE53DCBF0B8F376FB4C9BF1FAEA13E11988495295,
	ImplementationData_set_pressedPosition_mA4A1E5E3EABF70132CC91B8F17414E6C26C55CB5,
	ImplementationData_get_pressedRaycast_mA71A6D911BC67E2877120BEC46F32127E000639D,
	ImplementationData_set_pressedRaycast_m07B9A00899211C2D9EFE5C7367F0D0CD92671DCD,
	ImplementationData_get_pressedGameObject_mC3D191EA02E9FDF466A0B0E7DB836743FE3A7E0B,
	ImplementationData_set_pressedGameObject_m0E6E5DF7C22E6CF52D13D8D577C570C10D404D12,
	ImplementationData_get_pressedGameObjectRaw_m8AAD5F8569332EB9543335E8FFE454513382E35C,
	ImplementationData_set_pressedGameObjectRaw_m08BDACF14EB3891EB34D4BE7611A01E121218129,
	ImplementationData_get_draggedGameObject_mB4FDDBF950B79E25366E72F266DF02E2348ED813,
	ImplementationData_set_draggedGameObject_m1F3CABB710E5AC7EE2A51E6B33446F8C343F22FA,
	ImplementationData_Reset_m26650CA4925208D3CFCC484D107017CE6A8D4509,
	MouseModel_get_pointerId_m11D2E24194A0D949D405EBB251E239E8FDACB3D1,
	MouseModel_get_changedThisFrame_mA73BE121871FCA75556A0DB0B5AA26F24B44007A,
	MouseModel_set_changedThisFrame_m5751B58646A87B9A796E0C73E670BC262696F6DD,
	MouseModel_get_position_m78546DD8EB343EF0FAA3B00DF5FC8E5D83CAC31E,
	MouseModel_set_position_m32976C82E8173C43D920E417C1526D08C1848894,
	MouseModel_get_deltaPosition_mB4120B0D71243A5DCED22C2DCB41F61C752344A0,
	MouseModel_set_deltaPosition_m49E7E4D3B9976725AA516BE1DF87F41AC18718A2,
	MouseModel_get_scrollDelta_m575BDC1B8981D596808C1B6D5D3BA0786F0C86FE,
	MouseModel_set_scrollDelta_m5063B4C4E1B2AD1BEE7146DF1591AAB2203C1942,
	MouseModel_get_leftButton_mF2FE94CCCFC90A2602FF4161F61F20BA069CC7AF,
	MouseModel_set_leftButton_mDF681AB6BF3C50A013EDEC3BA1998F84C11C5CA3,
	MouseModel_set_leftButtonPressed_mB262B7B3E2C450A3C6FC9BEF978FF82C61B4EC05,
	MouseModel_get_rightButton_m95C9191F32EC76F8DF8E737FC86BE69DD483DE9C,
	MouseModel_set_rightButton_m0B017073C10DD745A5810A5B764FE4C38C9863B2,
	MouseModel_set_rightButtonPressed_m3B8AA3966338CB518A1E01412AE8278B8123FA98,
	MouseModel_get_middleButton_m7771854F89139CEFB78DB492621D8402351FC657,
	MouseModel_set_middleButton_mD42C3ECBE1B7E8709AA0C037E0CBC65E065CBC86,
	MouseModel_set_middleButtonPressed_m7E777E54424A123E85C19C8FBC666531045B2E2B,
	MouseModel__ctor_m83A579E595CC3EA1D0B7871BEA4F7BE3F43BCF5B,
	MouseModel_OnFrameFinished_mDFDCF666965A09EDD96DA78A378E5D8885AEA760,
	MouseModel_CopyTo_m40FA373152091998C17145F41864E19AADA3F3EF,
	MouseModel_CopyFrom_mCD3E50E6FD213121A15576B7F375C6C0605BAC1E,
	InternalData_get_hoverTargets_mED5DD88CE637A33FCB133AB2A1164DBF31A153C4,
	InternalData_set_hoverTargets_m58FA8DC4B246C66F1B644FCB88657EBE790FBF45,
	InternalData_get_pointerTarget_m23F87D3C2E745888E515AFC1B1019D67D3815ABC,
	InternalData_set_pointerTarget_mF9314EBE084E03FB7CBEDCF822FF4CA6DDDDA5C8,
	InternalData_Reset_mE88036CD76DEA4817FC9EA538A96AEC351BBFBC3,
	TouchModel_get_pointerId_m09132E54C14049EE958701E47521DBF87AE46CAA,
	TouchModel_get_selectPhase_mAB7BD6D97EE045B8CBA8FE6D9674AE69B8FA9764,
	TouchModel_set_selectPhase_mEFA5BF0498E34859A19804B53380A6A44775E7B2,
	TouchModel_get_selectDelta_m3C485FF688B2D891723D298D56B95EDDB522EF5B,
	TouchModel_set_selectDelta_m9D3C5D26D870867BAFAFA5ABD0A327321B442021,
	TouchModel_get_changedThisFrame_m23FD7722215391AEE0B605CF9D8E66AE909E67B8,
	TouchModel_set_changedThisFrame_m561781EE6C0BFD95C120EB69B0BC84FCF6C63CB5,
	TouchModel_get_position_m733738D61FF916C6754A28320A3C9E986B1FEFF9,
	TouchModel_set_position_m192EEBE8DC7EC01D31651052C7E6EB0594618419,
	TouchModel_get_deltaPosition_m9E35067BFB1D1BDDC3F1C79A9A00E51A7E969ECC,
	TouchModel_set_deltaPosition_mA92EDE6055F346698EF3484330B18FDF1479F106,
	TouchModel__ctor_m2E4B407C745FD930A50FF3DF0E234396E1E9D903,
	TouchModel_Reset_mF62A73478E369AD0FB97C38E11BF8F704206F7F0,
	TouchModel_OnFrameFinished_m07CDE88E34A987019751A05CE638F6A08E17EFA0,
	TouchModel_CopyTo_mDD7D97D3A60CBB3F6C342E12546F02D551EC16E8,
	TouchModel_CopyFrom_m97D1D1FC51032EB8EA514CC3D32CB82D23577FE9,
	ImplementationData_get_hoverTargets_m712167711F5E065EF75C3593498EB5682F02524B,
	ImplementationData_set_hoverTargets_m535B94D1E4CE496E48B6CFC3CD0FEBD8F5D0BFE7,
	ImplementationData_get_pointerTarget_m99391EE2BB2C1566C578C8366FAA3A33F3A10197,
	ImplementationData_set_pointerTarget_m9A1690C598287B3ED3BD9752BD92EBC6BFCFBE1E,
	ImplementationData_get_isDragging_m1D754410DC0DF37DF9AA39C04E7A488E82D958EE,
	ImplementationData_set_isDragging_m2DBCC77F6E037B90B04E8B22198E776A9E6CCF92,
	ImplementationData_get_pressedTime_mDD847C787AC675CFE647E4216ADCE857A0F5C47F,
	ImplementationData_set_pressedTime_m2998A794D01109054102594B68C5876CB19B07AF,
	ImplementationData_get_pressedPosition_m5218B58A65B1252DEF55E1E70A2CD93FBDDAF97B,
	ImplementationData_set_pressedPosition_m29A8C216BA3FD177E9A443678FADB09D3BAC3169,
	ImplementationData_get_pressedRaycast_mFF0FD2531D8FAD7DC4F9F2847837F0E85726C65A,
	ImplementationData_set_pressedRaycast_m05F79A6CC57D04E4DDA51136390484B5EC4294E2,
	ImplementationData_get_pressedGameObject_m77E3E5A1AC94C35A10A5CE3F6B4A4849D9E31297,
	ImplementationData_set_pressedGameObject_m085ED8ADB34B7E733689A41969C08E49CEC510A1,
	ImplementationData_get_pressedGameObjectRaw_m5241D8F233E573A0D6A5D95E8D366989CB99A9D3,
	ImplementationData_set_pressedGameObjectRaw_mB8BB6FA60ABC1583206435291ED0A063CF55E34F,
	ImplementationData_get_draggedGameObject_mA29B766C2B3421C6A6126A032EC06998E6049A2B,
	ImplementationData_set_draggedGameObject_m9CF28E709931F5E9C64B8E1A2C04BE428E6389D6,
	ImplementationData_Reset_mA1A9200248AE4DE55F23C8248FC71D19D1297896,
	TrackedDeviceEventData__ctor_m9BFD5A55C43B5A58601D06115C03CE4051918D95,
	TrackedDeviceEventData_get_rayPoints_mA9FBBE93DC03B69F011B80202670D247859C6804,
	TrackedDeviceEventData_set_rayPoints_m538512D7DF7AB490E2790704CE82D8A967983258,
	TrackedDeviceEventData_get_rayHitIndex_m8953BA1EB97C9DAECF82D522389112154272639C,
	TrackedDeviceEventData_set_rayHitIndex_mC2E51FF9F570EF9B76DF485444295DE228E0612A,
	TrackedDeviceEventData_get_layerMask_mFD08C45D5450B44F9029B91A8DB5E8CE293DCA0B,
	TrackedDeviceEventData_set_layerMask_m765FDC4C0A6821E43539F06DACB13BCDD04004C2,
	TrackedDeviceEventData_get_interactor_mA00E13242D00AE5C04C1035158B8BC796D4A8A30,
	TrackedDeviceGraphicRaycaster_get_ignoreReversedGraphics_m6993D2E5318D6583C7DA17FD80782DB725C78E3D,
	TrackedDeviceGraphicRaycaster_set_ignoreReversedGraphics_m0161DB6A8C3E83B6DE293FCDD729DF6D14EF73D0,
	TrackedDeviceGraphicRaycaster_get_checkFor2DOcclusion_m36139C25B14C7E5F877EDE5B28A8DC17E0639CA7,
	TrackedDeviceGraphicRaycaster_set_checkFor2DOcclusion_m9734AF8E12A0B58B290DBA60131A25752806BECF,
	TrackedDeviceGraphicRaycaster_get_checkFor3DOcclusion_m158267D5C6CC36324F3E0909B4B6CD80255D744C,
	TrackedDeviceGraphicRaycaster_set_checkFor3DOcclusion_m1AB8A6330DA062FF8FFC1058F7A4A02A270E61FA,
	TrackedDeviceGraphicRaycaster_get_blockingMask_m9D6A9012CD2C55EC70A7649BA1BAEBE38BFA5AFD,
	TrackedDeviceGraphicRaycaster_set_blockingMask_mE8AE475D17143EF140431FAF485535E86BEDE517,
	TrackedDeviceGraphicRaycaster_get_raycastTriggerInteraction_mD8699AC8629259E139A3FAF8854011E92F8B744C,
	TrackedDeviceGraphicRaycaster_set_raycastTriggerInteraction_m1B8383E3CE6C89428E5FA7FE06DEE08ED85780B5,
	TrackedDeviceGraphicRaycaster_get_eventCamera_m3EFCF67C039BCEF356D5521BAD8DB1DF00FB92EF,
	TrackedDeviceGraphicRaycaster_Raycast_m6ADB184895B59C1FAC0DED7ADA1BDAF58C881480,
	TrackedDeviceGraphicRaycaster_get_canvas_m5E641EB589123E2A1599B28E1DCA3488ACE9AADB,
	TrackedDeviceGraphicRaycaster_FindClosestHit_mA27555583B00234BFA12B3A617117CEEDB065BB1,
	TrackedDeviceGraphicRaycaster_FindClosestHit_m8B68F4307253C769057EF035101A28C14F0CB4FC,
	TrackedDeviceGraphicRaycaster_PerformRaycasts_m128D132A0C91EE78BA1D67D6B4FC0EE358DF3774,
	TrackedDeviceGraphicRaycaster_PerformRaycast_m1E02BA87EB404F71BDAEE51046112543FC8C3255,
	TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_m0412421DF25AF5FD6241A3AC33F24BE046A18910,
	TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_m270E40985BAA694F09B5646C48AAF1E6A3FB26C5,
	TrackedDeviceGraphicRaycaster__ctor_mA408EA45E5ED282A1219A52DF77C1BCA432B9D0F,
	TrackedDeviceGraphicRaycaster__cctor_m5D870686FDAE444EFE752BA7770B20AC211398B6,
	RaycastHitData__ctor_mA3105F92D1D16D531B60FACB7453F972D13D9249,
	RaycastHitData_get_graphic_mF244823E64AB76542BED4C51A8BCF45ACC81144B,
	RaycastHitData_get_worldHitPosition_m399EAA366E322BE0BD61E56368F737FC29F85E28,
	RaycastHitData_get_screenPosition_m812ADB2AA30A26B4AB1B5AFBC8F06979131AE08A,
	RaycastHitData_get_distance_m5F6671106F1D00C942F5402BD17D9F27BFB2C22C,
	RaycastHitData_get_displayIndex_m32F8946542D364F916BE8D04CB8B61C150B99198,
	RaycastHitComparer_Compare_m7B6425F530A627AE2E4907917EE8F16A7F1BD8D1,
	RaycastHitComparer__ctor_mF6293EBA83713B48EA1D35CBB1A40BA53A8D3CD3,
	TrackedDeviceModel_get_implementationData_mADCDA47D3AD499318CDE0BBEA2BE132689DE2EE5,
	TrackedDeviceModel_get_pointerId_mD80CE625A75CA576B28A9C8ACB63D571A6606B67,
	TrackedDeviceModel_get_maxRaycastDistance_m3A722F116890557E9C451E7966830DB91325C1D0,
	TrackedDeviceModel_set_maxRaycastDistance_m5A2BDC35BAE802154CA48F0141EB1B68A327124E,
	TrackedDeviceModel_get_select_m5BA61464B02AB3202ACE442320C0BE21B4CE44F0,
	TrackedDeviceModel_set_select_m9B5835627C8C86095E53A520F355EB2AEB99E2FF,
	TrackedDeviceModel_get_selectDelta_mE75B1DD26F07531FC8FB387802D4FF37F1FD6A0A,
	TrackedDeviceModel_set_selectDelta_mB827DB0A535918C47D1855DE994092A2C3DA6DFE,
	TrackedDeviceModel_get_changedThisFrame_m68B82453470231A4F6679AD1254FA69B298893CD,
	TrackedDeviceModel_set_changedThisFrame_m54AAB4E033B8D5FB021C9941D2F0535C9AF03B52,
	TrackedDeviceModel_get_position_m00C189C1464672F36AB30D8D5D27B530F9DFD1A8,
	TrackedDeviceModel_set_position_mB7F655655F284799CA203C3050100717371A71B2,
	TrackedDeviceModel_get_orientation_m1ADE24778B2D6A1B54C1A9276AE2D9DF4A558AE9,
	TrackedDeviceModel_set_orientation_m84FA015204514B424CFC408A4B0E5C9C6476BDB0,
	TrackedDeviceModel_get_raycastPoints_mAC3EB88F58248C61A9574674B1BEC617D2673E30,
	TrackedDeviceModel_set_raycastPoints_m8A427DE3C9C4405E6C1CFDB1D32FF48ECAD45514,
	TrackedDeviceModel_get_currentRaycast_m73EFCB5A66AE403012FF9FEC6B439D31C2E5266B,
	TrackedDeviceModel_set_currentRaycast_m8E73593D06B1606AB02B03467243094884F5CD12,
	TrackedDeviceModel_get_currentRaycastEndpointIndex_m925CFAC84DCE305E31D381EC25B88C5D86D4E805,
	TrackedDeviceModel_set_currentRaycastEndpointIndex_mA4ABAD82D6BF7784AC287AD89F453D5D7AF9A041,
	TrackedDeviceModel_get_raycastLayerMask_m026CBA559DE2753C8E0BFDC0C61A86540480AE45,
	TrackedDeviceModel_set_raycastLayerMask_mF035862C9351DAE42ECFE530D2CC4E5EE6AA8779,
	TrackedDeviceModel_get_scrollDelta_m98E3C008CE34CA7698FBB522240054675857C201,
	TrackedDeviceModel_set_scrollDelta_m3044CFFEB48920A17459E320098354EAFD140A41,
	TrackedDeviceModel__ctor_mAE27577B157ECE28CF94FFACE80975BC194E0EC1,
	TrackedDeviceModel_Reset_mBABBE929D784F92680CFC66E4BD26DC7F9EA15ED,
	TrackedDeviceModel_OnFrameFinished_m32FC34175809DBB3A1BBC26699D6D9FB40A7C480,
	TrackedDeviceModel_CopyTo_mC2DC5C1F6ADF2CBF06B7D8288964DAB339E7D692,
	TrackedDeviceModel_CopyFrom_mE187E9E91E324AA0ABD3D1E8CD30DD793BFA0C39,
	ImplementationData_get_hoverTargets_m41E773C53C151D97E9492E8F45ED8FB4E96A59A7,
	ImplementationData_set_hoverTargets_m19F1CB02F7A7692C5D20A89947DFABFD92CAB455,
	ImplementationData_get_pointerTarget_m4B202866FF1FA91937343DCCB013B74DC114FE60,
	ImplementationData_set_pointerTarget_mFB25C58ADE397F423F6E9C022BBB41B0553B740E,
	ImplementationData_get_isDragging_m46C5339146DD29A9F8F17820C6EF44A3E7BEAF6C,
	ImplementationData_set_isDragging_m456D482B7022A4F5920ADFC3CC40B9A9AD8E3757,
	ImplementationData_get_pressedTime_m5CCBBBA87FDEBC3EA7EEEA060BE5D75D869AF5EF,
	ImplementationData_set_pressedTime_m29F68A8DB6BAF909CDFCD88FD5F5A319059AEE90,
	ImplementationData_get_position_m956AC6C7FB1ADEC574061B12EA47FED7780AC498,
	ImplementationData_set_position_m8E4DD90017F1D25E85A7C3C81B1DE163E30DB7DB,
	ImplementationData_get_pressedPosition_mCABB186BED5B1D8518709A46FE359DB489EF86C1,
	ImplementationData_set_pressedPosition_m0A20F9AB3E05608A87702FC7D9AEB11BCA833726,
	ImplementationData_get_pressedRaycast_m1E35327FB13E41C71374DBB7B117D0DE32C337F0,
	ImplementationData_set_pressedRaycast_m088EA8CF851F035A6E05B7AAD0DD4DFAE9504745,
	ImplementationData_get_pressedGameObject_m1A17AB48043129AEB2EBEA6946AA699E0C8BD61C,
	ImplementationData_set_pressedGameObject_m3D05029ED302431CAE9346C26F4CC2BBF4A3E066,
	ImplementationData_get_pressedGameObjectRaw_mCC3398E95B1DBBB0A3A63AB307E76ACD390BF72F,
	ImplementationData_set_pressedGameObjectRaw_m9925CC40E6A24D23784861334482B1E10B493D43,
	ImplementationData_get_draggedGameObject_mA1BB6E49C20D8AF62693ED0023261303286D2C3B,
	ImplementationData_set_draggedGameObject_mA2E82652C8A181F5EFDFD1CEBDFF655F07D895F3,
	ImplementationData_Reset_mAB96D4826DF6DD8D1A45E408B3771A340B70CC50,
	UIInputModule_get_clickSpeed_mED8269543BF6E7B9D6F29767103FA1BFDDDBABD1,
	UIInputModule_set_clickSpeed_m5FAF42247EA9E935740DF515DF3662D87724AE91,
	UIInputModule_get_moveDeadzone_m5FC1449527025B0AEE65FE6701A6930A284326A3,
	UIInputModule_set_moveDeadzone_m4985AD362CF90600168BFE20A3A79F2A7F0F6A5C,
	UIInputModule_get_repeatDelay_m4C2807BEED1855AA63863ECC5D930EF5730E41EF,
	UIInputModule_set_repeatDelay_mE62431ED050B2ED75776A4782EFF661F74E87665,
	UIInputModule_get_repeatRate_m264B9272E73D3FF3393F99B5BE0DDD7EE470A829,
	UIInputModule_set_repeatRate_m2E9C993F77FA13817BAFCC0D53E9B7B947741324,
	UIInputModule_get_trackedDeviceDragThresholdMultiplier_mC88BCECF2840B6C883B81D46902AE26BD96F9925,
	UIInputModule_set_trackedDeviceDragThresholdMultiplier_m244A9F1DB957B27F7F759A6DB7C41473AA76C40C,
	UIInputModule_get_uiCamera_m70A1AAB50856078AFC1FEFF561B03A80443F243F,
	UIInputModule_set_uiCamera_m53AED31E29BD6BA148C4E8B33BDCDCAAB5A1D1EA,
	UIInputModule_Update_mEC7D21BA91C671CAFED3DC41175BD912C6BF55CD,
	UIInputModule_DoProcess_m77427B9BD29BEA5E3201BB93386BCF5388D1FEDA,
	UIInputModule_Process_mCA4F1691A7B55CBD58FC6A51D5F1F6FC66E610A6,
	UIInputModule_SendUpdateEventToSelectedObject_m8031016F1A2FE893D81357CAF45D187F524DA3B5,
	UIInputModule_PerformRaycast_m252CDEE5EA783493953231E7CE8DB1DE65BCEFCD,
	UIInputModule_ProcessMouse_m55F4E0D3E1292EC33136205250F961F41E84BA47,
	UIInputModule_ProcessMouseMovement_m7115515A5AD98BD9240950BCB704BF814D73CE56,
	UIInputModule_ProcessMouseButton_m93741FDFD381DA1C36E41A223916AEA9502A65FC,
	UIInputModule_ProcessMouseButtonDrag_mB5381110D311AB1CAA00F4A457539883D6F84902,
	UIInputModule_ProcessMouseScroll_m451578BEFC8A77118B213F77894BC0C1E2EC321F,
	UIInputModule_ProcessTouch_m5906227FF084CE3D00977BD7F11EEF65FA068549,
	UIInputModule_ProcessTrackedDevice_mD5B96B2E4A90048260B92532B7D6B821197A49EC,
	UIInputModule_ProcessJoystick_mF08E9C4D6B2456EF2BD5CB6E6416619CC4166639,
	UIInputModule_GetOrCreateCachedPointerEvent_m6EC7DEB510FE1B554CC61FADD6B4DD33DD7E0321,
	UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m4105AF887118BBA58060308881098FDD69E40D8B,
	UIInputModule_GetOrCreateCachedAxisEvent_m4B7D4DC52E215F2A17F441FD2C1F1CBA457A61A8,
	UIInputModule__ctor_mF46715D3F1B896D7C6C99A15B00545866FBD0FD4,
	NULL,
	NULL,
	XRUIInputModule_get_maxRaycastDistance_m7EFD446560D43460B3F42AB48E029E7C6471DFE1,
	XRUIInputModule_set_maxRaycastDistance_mA92538AC86945632CB6434D64A10702D7E7EBFC9,
	XRUIInputModule_get_enableXRInput_mCB0B36DF3D3958107FC3294ACF3B48B0E0BD68D3,
	XRUIInputModule_set_enableXRInput_m543057C13560D5308529DD63D042F09AD7F9DA62,
	XRUIInputModule_get_enableMouseInput_m850A66D3DDA974FB48C329184164490C85BC0D7C,
	XRUIInputModule_set_enableMouseInput_m97B0DA3F625FD8AA84A686443C5E0BDE5104C5D2,
	XRUIInputModule_get_enableTouchInput_m765DDE7A7703A1F7690819C2838196026591B525,
	XRUIInputModule_set_enableTouchInput_mEB65C6C52B8E36896706998F19A37E1E072DB36C,
	XRUIInputModule_OnEnable_m1C141B8400BDB078017CEC570C4B1F8854CA5059,
	XRUIInputModule_RegisterInteractor_m374CF9E0F84B50B6D62DF650A6EF8C8A54604FD2,
	XRUIInputModule_UnregisterInteractor_m31D9300477B62C22339EF1223BAB161058BA9F00,
	XRUIInputModule_GetInteractor_m26CAC08CC8AE4331B2039C3C407455FA790E430A,
	XRUIInputModule_GetTrackedDeviceModel_m0974947125B5DB8C3DCBCDA9D17F676E5412A3BD,
	XRUIInputModule_DoProcess_m9F19917E52D74623EE80FF69CC43F5F110567375,
	XRUIInputModule_ProcessMouse_m86E2C9637324C799E35E77C4A94ECF3DD6864092,
	XRUIInputModule_ProcessTouches_m2AE05974DFAEC594CB8AC172AF65C1BAC0B2A68E,
	XRUIInputModule__ctor_m49BDF588B681FBB6C14DFE6BCE0BA1B2F94B0583,
	RegisteredInteractor__ctor_m599746C9D0CEC3BC8EE3848164F5CD99611FC30C,
	RegisteredTouch__ctor_m6464420D1DFD3E6F407C3582184963173CFBF959,
	CardinalUtility_GetNearestCardinal_mD0D5EEA123C0B684D20BE8DBF98B1954BB134B28,
	InputActionManager_get_actionAssets_mCC3D35605B78EAEEAAFF33EEAB4AF59121DEE92D,
	InputActionManager_set_actionAssets_mE83FBC4F082307875665DF9CD857FBE4D0735921,
	InputActionManager_OnEnable_mB35FEF9B4B3A734E29A7DF1CF220C5E31ADB4BBD,
	InputActionManager_OnDisable_mB49CFBC312F2F49804F42E5D15DC433AF425CEDF,
	InputActionManager_EnableInput_m23B975D861464777A37EBEB3D797127ED9C5F300,
	InputActionManager_DisableInput_mC9ADD2BC09F5858C875FB8BA3F215BC91D04FF49,
	InputActionManager__ctor_m5B4FC1A3708BF9C4C2CD0E6981BE9A0766221CAF,
	InputActionPropertyExtensions_EnableDirectAction_mA61CA2DCFB497E459F53938F1DA9B117C8653CC7,
	InputActionPropertyExtensions_DisableDirectAction_m2F8AB32FD2D98F072682A770301BF66829658DD4,
	SimulatedInputLayoutLoader__cctor_m3D22CCF524A29655239041B7A009527A7DF234E9,
	SimulatedInputLayoutLoader_Initialize_mA8D3A8DED86CC5D6DD0CF667B4F9567FD588923A,
	SimulatedInputLayoutLoader_RegisterInputLayouts_m6438013D44910B5E51E0CAD32DFB7980FFA0A0EC,
	XRDeviceSimulator_get_keyboardXTranslateAction_mAEC857837C3AD47E6756817C17490B91306E556E,
	XRDeviceSimulator_set_keyboardXTranslateAction_m14EC02ECE9BB46857ACCAA0E166EDC281C99DD9F,
	XRDeviceSimulator_get_keyboardYTranslateAction_mDF1A80117C3F9FB22D2742E2E9254385F07CC1E4,
	XRDeviceSimulator_set_keyboardYTranslateAction_m63709C1276410510ED6ED3D9FDB3C770BE56358C,
	XRDeviceSimulator_get_keyboardZTranslateAction_m995C15288E5FE69E97648F31DEE60FF216DAF527,
	XRDeviceSimulator_set_keyboardZTranslateAction_m9FEA64151745175A92B2E8ECCC8B4A27E8E4ADD7,
	XRDeviceSimulator_get_manipulateLeftAction_mA85B27C1880AC1DE15975D2C7C1B89934922125A,
	XRDeviceSimulator_set_manipulateLeftAction_mF11CD458504C68947EBB0AD53FD7CFA47AFF0342,
	XRDeviceSimulator_get_manipulateRightAction_mF0363E1B3F89E964284CAB88EC8A375BA22F02CA,
	XRDeviceSimulator_set_manipulateRightAction_m7DFF0258BF3CB30963F464BB62AACC6826FFF790,
	XRDeviceSimulator_get_toggleManipulateLeftAction_mA7BCE1A7F1B06B0A86DCD4EF807BA5C7971536D0,
	XRDeviceSimulator_set_toggleManipulateLeftAction_m607071E6465FF4DF40CBB2A370824182BF6F5501,
	XRDeviceSimulator_get_toggleManipulateRightAction_mB1D68E47D156979F8933A1880B1B6266A7DFD743,
	XRDeviceSimulator_set_toggleManipulateRightAction_m1A1DCBF5F4F31471DAD2C64EBA55DA892B81BDFC,
	XRDeviceSimulator_get_manipulateHeadAction_m1650DFE59F8873E51FA31DE5B7D21B58BCAE1F83,
	XRDeviceSimulator_set_manipulateHeadAction_mDF6DEC50297F7BB491903468B66E6041A742B91E,
	XRDeviceSimulator_get_mouseDeltaAction_m065F754881E23CF189B73D92FA55E9F3FA6C4898,
	XRDeviceSimulator_set_mouseDeltaAction_mE2BF32E0F48E4DC3815C1AB1DF8870C1880DEDF7,
	XRDeviceSimulator_get_mouseScrollAction_m8E2D28871F31EFC91ABBBC0AF23373542589863B,
	XRDeviceSimulator_set_mouseScrollAction_mF887890C9E5BD5D4035EA9E4F98284A1C2BC428A,
	XRDeviceSimulator_get_rotateModeOverrideAction_m52C0F7D6F6B8CB65FC53D8BE9E902321BB047928,
	XRDeviceSimulator_set_rotateModeOverrideAction_m9CF7EB921CBACE13DA840DED5171AAC8C2865EA4,
	XRDeviceSimulator_get_toggleMouseTransformationModeAction_mBE870DC9239163FEB958CC68A77954F83043C43C,
	XRDeviceSimulator_set_toggleMouseTransformationModeAction_m4AAA05D30ECED5C6FE39D38BFEE39A3755F48789,
	XRDeviceSimulator_get_negateModeAction_mD3F492596539B2E94D374B0A3BD6B67A2E1A5705,
	XRDeviceSimulator_set_negateModeAction_mF939E46C69911339E0D7F75FB59297F495595AB9,
	XRDeviceSimulator_get_xConstraintAction_m0BBF93C6665FCD2B01B0D188CA02D3533AC1EE83,
	XRDeviceSimulator_set_xConstraintAction_m26CB0C3DBA2D8EC2C816428C3097BDBC0B936B82,
	XRDeviceSimulator_get_yConstraintAction_m88E3F22740F8D1D8BCB91B0E018B8543B1E43B64,
	XRDeviceSimulator_set_yConstraintAction_m419D7ECB9726D11B94EF13188C94712514FB4E5D,
	XRDeviceSimulator_get_zConstraintAction_mB70DB1E733D48E968566AFF7B991071277147FA3,
	XRDeviceSimulator_set_zConstraintAction_mAA5C4E3451548EEB1A6D3D37DAA8853A44BEB368,
	XRDeviceSimulator_get_resetAction_mF5B360BF55BF43892AE586E8BBA718FF4DFE9AD6,
	XRDeviceSimulator_set_resetAction_m38CB0732FC6B85BDE2F8A46007B33F79BF3C391D,
	XRDeviceSimulator_get_toggleCursorLockAction_m7445BA478DFE51BABDE53525E3EF915A0BC25D36,
	XRDeviceSimulator_set_toggleCursorLockAction_m925FA2348E18E841B157DE750E0C49D19C84B2EC,
	XRDeviceSimulator_get_toggleDevicePositionTargetAction_m8A96CE958D4808BEFAF135DB74CA285623A54461,
	XRDeviceSimulator_set_toggleDevicePositionTargetAction_m03962215EE0113F70021A0A8325DD27301A3CAED,
	XRDeviceSimulator_get_togglePrimary2DAxisTargetAction_mD7F64B00E8C105AF42762F3E16BC40A176A52D64,
	XRDeviceSimulator_set_togglePrimary2DAxisTargetAction_m089E9ACA27A858CD2B1B0BDAB7924D0CCFF02093,
	XRDeviceSimulator_get_toggleSecondary2DAxisTargetAction_m9FC15DBC134C76FC8A175D52DC3D8E2632AD8B2F,
	XRDeviceSimulator_set_toggleSecondary2DAxisTargetAction_mD354D81F6C13CC58EBB441E73D37DAE11FBE1FEF,
	XRDeviceSimulator_get_axis2DAction_m16CD23D63EC0719B98D0F13F576F4C48F8ED4A56,
	XRDeviceSimulator_set_axis2DAction_m694E81502DACE237BF3979B0556036D958A09DE6,
	XRDeviceSimulator_get_restingHandAxis2DAction_m8956462E6DC1E539DC94DDFC08635D060C8A8D04,
	XRDeviceSimulator_set_restingHandAxis2DAction_m4F434D67CAFD4BE291829883E14C9674BC603D5B,
	XRDeviceSimulator_get_gripAction_m0B8C8D5371D10914A69BD1635F2FF649BDBD4EF0,
	XRDeviceSimulator_set_gripAction_m2559D8F1FCA153D2917C7D15AC7A7B658018047E,
	XRDeviceSimulator_get_triggerAction_m308DC7EBA6FE05360C9A9FD56B9C4A1CADC3DCAB,
	XRDeviceSimulator_set_triggerAction_m7318C2B689FAA3E0FE1EA23A3B159CBB4790C127,
	XRDeviceSimulator_get_primaryButtonAction_m26B030CEC4D2A1B3D5E44AF69413699E43AEDC68,
	XRDeviceSimulator_set_primaryButtonAction_m3E8CDCBBDE435FBE7616D09D96C3399F38490679,
	XRDeviceSimulator_get_secondaryButtonAction_m89F1E90EC5406039C46BD6BB200CA8E3E8CA89CB,
	XRDeviceSimulator_set_secondaryButtonAction_mF1AA502AB807073F8D1CF2C30748FCE17A6C5BDF,
	XRDeviceSimulator_get_menuAction_mB112D9FD60BC25CB5AA100F1DE501EAFF1F07021,
	XRDeviceSimulator_set_menuAction_m9C30DA78848B09E419095389CF576BC5014A49DE,
	XRDeviceSimulator_get_primary2DAxisClickAction_m5B25D0CDD29382E2CA7E6AC2BF874EB3911BE872,
	XRDeviceSimulator_set_primary2DAxisClickAction_mBFDC086582382D82B0187886F1D4A7E4DE395A61,
	XRDeviceSimulator_get_secondary2DAxisClickAction_m99BAB0619C7B06594E1C5F92BB9D5A6FCF293908,
	XRDeviceSimulator_set_secondary2DAxisClickAction_mB4083F206D165F5CCB3C8DE9519585C0774C260A,
	XRDeviceSimulator_get_primary2DAxisTouchAction_m1C4E79B47D994E0FBC0790C2750869CCF6FACE7D,
	XRDeviceSimulator_set_primary2DAxisTouchAction_m4AD4B650F940CED900B6B700E03441DB164E7099,
	XRDeviceSimulator_get_secondary2DAxisTouchAction_mAEAAE4D34F3453E0FD2A553A0A4FB7879C6EF43C,
	XRDeviceSimulator_set_secondary2DAxisTouchAction_m39EB08C1CE99B146186401F0398EBB1DCBEF73FF,
	XRDeviceSimulator_get_primaryTouchAction_mEC658D2FF7E8367AF1EA1F8B79B916F7504CA3DF,
	XRDeviceSimulator_set_primaryTouchAction_m3D5A0C9051548EF940FAA2859F545D8B5559F823,
	XRDeviceSimulator_get_secondaryTouchAction_m8E40B1403A5818E40F91DDB46F7C45CEE497AD93,
	XRDeviceSimulator_set_secondaryTouchAction_m83D111D1C1BE4330D136E725BC412A58DD1DB820,
	XRDeviceSimulator_get_cameraTransform_m5E26EF97718C2531462C1C747310F0257C9B65EE,
	XRDeviceSimulator_set_cameraTransform_m4CE32DC6AF026A8F90139D3B5027153FF0FFF496,
	XRDeviceSimulator_get_keyboardTranslateSpace_mA7581591050894F335DBC74DCDDC4FE7066C9DA6,
	XRDeviceSimulator_set_keyboardTranslateSpace_mC4B14614B9DA1B3B570ADFA4C49DAC10E91D7684,
	XRDeviceSimulator_get_mouseTranslateSpace_m3CEB5444AFA0C96BA3F0A4377525520FA743DBBE,
	XRDeviceSimulator_set_mouseTranslateSpace_m60E5A51DF00057F58B02CE4A2D2D6EA8F8A90F11,
	XRDeviceSimulator_get_keyboardXTranslateSpeed_m34D631E53F390CE9DAA933F93F3A094B53ECA7A1,
	XRDeviceSimulator_set_keyboardXTranslateSpeed_m233FB1BE01843CE795024CAB9765FE5318F90E87,
	XRDeviceSimulator_get_keyboardYTranslateSpeed_mF416AC06A8E033D360E290CD69F9329CC4005000,
	XRDeviceSimulator_set_keyboardYTranslateSpeed_m7436D89A2EA6EE5FD4DF71A0046D562ED05E883D,
	XRDeviceSimulator_get_keyboardZTranslateSpeed_m824737FE57562AFB74B84662DDB76C93B6215F8D,
	XRDeviceSimulator_set_keyboardZTranslateSpeed_m05B9955C3FBE81E1A5A25A151494549BA61CA257,
	XRDeviceSimulator_get_mouseXTranslateSensitivity_mEF1AC7C4C47A5B36B190E61A05C4A5958016F1B7,
	XRDeviceSimulator_set_mouseXTranslateSensitivity_m216B7D285E468FC3F4B7CE0E8780A9A85D9FEF82,
	XRDeviceSimulator_get_mouseYTranslateSensitivity_m13D10E49A258BD10D22E9F8758B36D52FA54F70F,
	XRDeviceSimulator_set_mouseYTranslateSensitivity_mCBFFCA92FB5D7F82B5257BDCA997AE3E715DA257,
	XRDeviceSimulator_get_mouseScrollTranslateSensitivity_m7C0AFB651FE881FF12AA8465CB1A3099CF3E8F30,
	XRDeviceSimulator_set_mouseScrollTranslateSensitivity_m8177BD424F661EEDF75CAD618EC2E85191976FEF,
	XRDeviceSimulator_get_mouseXRotateSensitivity_mF22D03037E2CD4C19686035824E6B96FF758931D,
	XRDeviceSimulator_set_mouseXRotateSensitivity_mD84B0488D9172D04A7D9DACCB4311F395E108C16,
	XRDeviceSimulator_get_mouseYRotateSensitivity_mB2CA87C42C3DE9621A741372E37E66035EB34A47,
	XRDeviceSimulator_set_mouseYRotateSensitivity_m010D3B1F052848EC5CEE995260FADCF05B12E126,
	XRDeviceSimulator_get_mouseScrollRotateSensitivity_m01BCDF76CD5CC4970700DD2E63934F1B75CD5FE8,
	XRDeviceSimulator_set_mouseScrollRotateSensitivity_m5F89AC4B8DB0DB525259CCC3DDF8D586C4F1FFBF,
	XRDeviceSimulator_get_mouseYRotateInvert_m346B6297579E45C8FA6875482CA0D22E1A734784,
	XRDeviceSimulator_set_mouseYRotateInvert_m656BDA7CE8337D4FD40877241E7106ACFACDF551,
	XRDeviceSimulator_get_desiredCursorLockMode_m991469ACF251962DF3CA09ECAFA3592BD91614BF,
	XRDeviceSimulator_set_desiredCursorLockMode_m65D95EB9007710D62193A6BFD164FC1B9D20E7C3,
	XRDeviceSimulator_get_mouseTransformationMode_m8BD4DE8F0E31B845095DCD38FFB84A294DA067B7,
	XRDeviceSimulator_set_mouseTransformationMode_mE5FC60CA32B7CDE857D77B03BCFC6F7FD9707DD6,
	XRDeviceSimulator_get_axis2DTargets_m68C47B011246DC08BB9611A418F78BAC47DCEFF7,
	XRDeviceSimulator_set_axis2DTargets_m5CFC74095D9951134A840A5749C61D1F8D0FAC71,
	XRDeviceSimulator_Awake_mDBFC043E3D0959B6FCFC9B0827EC10FAEF9A12BF,
	XRDeviceSimulator_OnEnable_m5A55CA99DEFF70FCFA7224EDE01079E41D7A136E,
	XRDeviceSimulator_OnDisable_m6CF9E25E75DD2A57F7B1EB82AFF8A16B6A2F3BC3,
	XRDeviceSimulator_Update_m112C3A2F264E3DFCEA0761EAB9F4E3C7876F2027,
	XRDeviceSimulator_ProcessPoseInput_mEE5099FB14FD82F27B725339783B2E71945BAF6D,
	XRDeviceSimulator_ProcessControlInput_m9D55B442803730177CB77B6EC35E6EA92ACBAC52,
	XRDeviceSimulator_ProcessAxis2DControlInput_m5A022CEF566854D71D1DDB07BDAE259F78158B95,
	XRDeviceSimulator_ProcessButtonControlInput_m7A0601E20685FB8052F808192BC28689E9D49410,
	XRDeviceSimulator_AddDevices_m1D2D79EB8D14AFEEF34A3D7027CBA69C9BB61790,
	XRDeviceSimulator_RemoveDevices_m8E53C56EE87606F4DEAA9CED64DFE622C3128716,
	XRDeviceSimulator_GetResetScale_m974B3F9007BC2E6A3B382CF9376E93DD28C57F76,
	XRDeviceSimulator_GetAxes_m33C5790A6707C2B9E1613D1A4744B96BE6D5751B,
	XRDeviceSimulator_GetDeltaRotation_m37171322FF139EE6C8211923E0D893AC48C64AE9,
	XRDeviceSimulator_GetDeltaRotation_mAD9A8D40BA4F68C019757BAF887FA1FB14E56F55,
	XRDeviceSimulator_Subscribe_m6023F8721D7CBAD7F197C237A4A4EC9EF8686B27,
	XRDeviceSimulator_Unsubscribe_m13A8C3E7B350425869BF70C573F9961D75886E58,
	XRDeviceSimulator_Negate_mDC1562BE50A1F941B079D79850F48A58FF267B22,
	XRDeviceSimulator_Negate_m71147EF32467ECE0FFAC7204E909944F375F4B4D,
	XRDeviceSimulator_SubscribeKeyboardXTranslateAction_m6A981141F7DE6B0F503CE24005CBFB84BD34F816,
	XRDeviceSimulator_UnsubscribeKeyboardXTranslateAction_mD06F002A3C7F6DE6A523268FA16C64A711783762,
	XRDeviceSimulator_SubscribeKeyboardYTranslateAction_m57AB1C72BD66A290068437C7FF63B490EF01768B,
	XRDeviceSimulator_UnsubscribeKeyboardYTranslateAction_mB50D21E194002F0C2B9B636F45C256BE9228382E,
	XRDeviceSimulator_SubscribeKeyboardZTranslateAction_mC7873AD4DE21F216B37C2BB4907783345C093768,
	XRDeviceSimulator_UnsubscribeKeyboardZTranslateAction_mB421A42AE7476E8451067FBFA9745F83ECF4A403,
	XRDeviceSimulator_SubscribeManipulateLeftAction_m26BAE17735BA8D7534E821A34E062F14C9A18ABD,
	XRDeviceSimulator_UnsubscribeManipulateLeftAction_mE66D82A44D9E829CE9E521E1B85444F17CE12437,
	XRDeviceSimulator_SubscribeManipulateRightAction_m4514A8B2CE274FDF4C983D1FE0DD0B4E48E185FB,
	XRDeviceSimulator_UnsubscribeManipulateRightAction_m69E6AD489547565D436DA74E795CDBA5D612F3FF,
	XRDeviceSimulator_SubscribeToggleManipulateLeftAction_m59F59D6BB2D082DE361ACF3F6560A3062FA05BA4,
	XRDeviceSimulator_UnsubscribeToggleManipulateLeftAction_mC1D54164D14273C7FB74C7FE46849C4B221CA16E,
	XRDeviceSimulator_SubscribeToggleManipulateRightAction_mBBC73942B18FE3900A4DA0D467316BD77543E9DA,
	XRDeviceSimulator_UnsubscribeToggleManipulateRightAction_mDA6F51559FB94E780BABB80814D97D3F9E425072,
	XRDeviceSimulator_SubscribeManipulateHeadAction_m50F771079632C738C674A274D41303F3B85D0107,
	XRDeviceSimulator_UnsubscribeManipulateHeadAction_mEA96DB7DE4C30F4B8279F4523CA289B6639A0653,
	XRDeviceSimulator_SubscribeMouseDeltaAction_mC6ABEFE67947F1DDBBA1A4D6B8CDBDE19D588F7F,
	XRDeviceSimulator_UnsubscribeMouseDeltaAction_mE59CAC816FDC3FB64F778EA45875610BDC5C5327,
	XRDeviceSimulator_SubscribeMouseScrollAction_mD5D0833C607F4FAF7D104B917A768D8D4AC407FD,
	XRDeviceSimulator_UnsubscribeMouseScrollAction_m4CCC73F3075BE954B49132FBC224FD0E7F962D07,
	XRDeviceSimulator_SubscribeRotateModeOverrideAction_m40CB1843B4C14EB183CD5973296862C6BEA2B727,
	XRDeviceSimulator_UnsubscribeRotateModeOverrideAction_mD8D3CE7A2B19CEBA539524142A667F1691C96C9A,
	XRDeviceSimulator_SubscribeToggleMouseTransformationModeAction_m9708A297228953DD9B1BFF208225AD5994E7A22F,
	XRDeviceSimulator_UnsubscribeToggleMouseTransformationModeAction_m3C3753A2134B75B226C455DD22EBF9FFBDE881F5,
	XRDeviceSimulator_SubscribeNegateModeAction_m4469FE7F3AEE7DF9EC8C9EA84691DD2808492344,
	XRDeviceSimulator_UnsubscribeNegateModeAction_m5D818930F3FDA653C95C3AB1478E4FEA2809BDCA,
	XRDeviceSimulator_SubscribeXConstraintAction_mBE5B5EA0C1E72D034597BB8FF1D2195E8C89E513,
	XRDeviceSimulator_UnsubscribeXConstraintAction_mB252DDCE49BD71228D08235869AF423039670065,
	XRDeviceSimulator_SubscribeYConstraintAction_m7766A0EC7E6330AF41B41B86ADAF7E61915C896E,
	XRDeviceSimulator_UnsubscribeYConstraintAction_mE46D21B812BC6FC4EE73AF7B8A870C817EAB9A7A,
	XRDeviceSimulator_SubscribeZConstraintAction_m8BDE69B132DD19F2C11DC7B2235694E06F396910,
	XRDeviceSimulator_UnsubscribeZConstraintAction_mF02E2FE56EB101E9DBC57D021DA9745EEECC97CF,
	XRDeviceSimulator_SubscribeResetAction_m1B18DD654BFF817ACF5C639CC28B5F8844093D57,
	XRDeviceSimulator_UnsubscribeResetAction_mA14B2EA33DC090346DE3A291CD8947F173C554A5,
	XRDeviceSimulator_SubscribeToggleCursorLockAction_m66626DBA5BC3D51851DC302E5D05619DD6D8949F,
	XRDeviceSimulator_UnsubscribeToggleCursorLockAction_mB073C2CBEA2991D5579B336B08ACD0AE1BA2EA50,
	XRDeviceSimulator_SubscribeToggleDevicePositionTargetAction_m9C5AFC5528BCAEF28E457C93B29B4F11DB482DF4,
	XRDeviceSimulator_UnsubscribeToggleDevicePositionTargetAction_m6E463B0563EF4428A37E8B903C11275A0ABF0C21,
	XRDeviceSimulator_SubscribeTogglePrimary2DAxisTargetAction_m8188CA681130F539B2D6F819200249FEF3E1696D,
	XRDeviceSimulator_UnsubscribeTogglePrimary2DAxisTargetAction_mA66448125CA11AA7A6C138A81953A87AA1818B03,
	XRDeviceSimulator_SubscribeToggleSecondary2DAxisTargetAction_m3CC5D4623FD75EE2E428483543DD4AE1D2031DA2,
	XRDeviceSimulator_UnsubscribeToggleSecondary2DAxisTargetAction_m1CCD6C28C46BF9C27B15401A1355C8C5E2E26438,
	XRDeviceSimulator_SubscribeAxis2DAction_mEE8886128181FBFBE8D5E8D3FECD7113C6948E65,
	XRDeviceSimulator_UnsubscribeAxis2DAction_mB2BDDB6B635540B39042D50D88A7C4C5A4655881,
	XRDeviceSimulator_SubscribeRestingHandAxis2DAction_m2DA465BEB5D3BC636A0763A67074AFC5B49C035C,
	XRDeviceSimulator_UnsubscribeRestingHandAxis2DAction_m049D9B71FC3F41F73A483FB1FC13B2FBE13CC71F,
	XRDeviceSimulator_SubscribeGripAction_m773AECCB7C7087A87FED8FE5ACC189C56A0DE1F1,
	XRDeviceSimulator_UnsubscribeGripAction_mA7C1B8224432C0CC38C7F7C4608D12FB8CD39B55,
	XRDeviceSimulator_SubscribeTriggerAction_mD4FFFD0B4430797981D289C9CCB8640D458D4E67,
	XRDeviceSimulator_UnsubscribeTriggerAction_mDCCDCC52FA565A48D46E1E825E402B1689C317B5,
	XRDeviceSimulator_SubscribePrimaryButtonAction_m737222A31E00B58AB25C9D66A43094221EF34E63,
	XRDeviceSimulator_UnsubscribePrimaryButtonAction_m0F1F148088CA510E47BEBF7625A904CACE959C76,
	XRDeviceSimulator_SubscribeSecondaryButtonAction_m442B2AD6E5F329CD28A0E570CB7C0101945F81CD,
	XRDeviceSimulator_UnsubscribeSecondaryButtonAction_m9B5B23C64ACA719403B3B882637878286D955B95,
	XRDeviceSimulator_SubscribeMenuAction_m3EEF1010C6EED412197B1466FB1D72FBA0E6C674,
	XRDeviceSimulator_UnsubscribeMenuAction_m30A656E00AF44A7911608FEEF38A74A898B66748,
	XRDeviceSimulator_SubscribePrimary2DAxisClickAction_m73C15F34F2E665BFD5AFB5A3F925C4F4665BE4BA,
	XRDeviceSimulator_UnsubscribePrimary2DAxisClickAction_m5A00374DB38D3DFDD92A68A66981492ECBC03977,
	XRDeviceSimulator_SubscribeSecondary2DAxisClickAction_mAB5934DACF09F037E4CC2619FE5066F3CDAB3064,
	XRDeviceSimulator_UnsubscribeSecondary2DAxisClickAction_m6CAA519997ABEF342FF74F558BD6E4B82314A1D5,
	XRDeviceSimulator_SubscribePrimary2DAxisTouchAction_m3EA13486E47B0828641D9D732811B23C7AEA185F,
	XRDeviceSimulator_UnsubscribePrimary2DAxisTouchAction_m26F2A35ADB7A6394FE2F471ED0FC609994D23638,
	XRDeviceSimulator_SubscribeSecondary2DAxisTouchAction_m0A7ECAD84ADC2A59BDD0973301D18B6E750F706A,
	XRDeviceSimulator_UnsubscribeSecondary2DAxisTouchAction_m7A4A35BC2507747E49F663B2B2DC316907E0AF06,
	XRDeviceSimulator_SubscribePrimaryTouchAction_m180904DB9DBECD51EE7F7BA000A219F824958A8D,
	XRDeviceSimulator_UnsubscribePrimaryTouchAction_m77AB572F4913323761FAC52E5E27CC0D23CAF31C,
	XRDeviceSimulator_SubscribeSecondaryTouchAction_mE6BCF08D72F50509E2B598FD76D5E5B2ED3941C2,
	XRDeviceSimulator_UnsubscribeSecondaryTouchAction_mCB2EDC912046BC4D6AA6F665D78D93BDE12B4E2B,
	XRDeviceSimulator_OnKeyboardXTranslatePerformed_m67D9C81C79322E88AAB39CE84C37FAAB7C91F80A,
	XRDeviceSimulator_OnKeyboardXTranslateCanceled_m9D3DEEA004C755F7EB437C73FC0F1C93C2C5CE2A,
	XRDeviceSimulator_OnKeyboardYTranslatePerformed_m3C16C270EE32CF28406AD517DCDD12CCFA923779,
	XRDeviceSimulator_OnKeyboardYTranslateCanceled_mB7E662108181FA0EF68D552AB64A72E8D0E7B807,
	XRDeviceSimulator_OnKeyboardZTranslatePerformed_m31B9D2B07CB305046B816D52FBD7A9BC840C07A2,
	XRDeviceSimulator_OnKeyboardZTranslateCanceled_m10F647E991EEE77F776A8788F96E7DC382F23AED,
	XRDeviceSimulator_OnManipulateLeftPerformed_m3F5E6822F34708EFAD23751B58722EEE6DDD26B1,
	XRDeviceSimulator_OnManipulateLeftCanceled_mD53A7A680C685A7F047A3F7DB78D49DCF930A212,
	XRDeviceSimulator_OnManipulateRightPerformed_m162F4EDB2B1A864153EC1CFACDF4B17F1E62A062,
	XRDeviceSimulator_OnManipulateRightCanceled_mA285F03C11962E9ED786294DEADD6E27EBF0E526,
	XRDeviceSimulator_OnToggleManipulateLeftPerformed_m472E7851F37DF7DA7D06695217A0925D431AF029,
	XRDeviceSimulator_OnToggleManipulateRightPerformed_m600CBEB0CD83C7A78622BD681EE9442050210961,
	XRDeviceSimulator_OnManipulateHeadPerformed_mE3CDEB5905751F0DAA2BC8813DDFE12411A5173B,
	XRDeviceSimulator_OnManipulateHeadCanceled_m123048DD036F30B8FEB3FE3FDBA0201F245522A1,
	XRDeviceSimulator_OnMouseDeltaPerformed_mA0D337A02CEECFAEC4B8E92F6B8987FE9AA58991,
	XRDeviceSimulator_OnMouseDeltaCanceled_m6B92B3B296A3F4D9DA6685B648FE94FE0D26AD33,
	XRDeviceSimulator_OnMouseScrollPerformed_m4341955EE336EE6BD8405E7250259E1EA80C6371,
	XRDeviceSimulator_OnMouseScrollCanceled_m7DB823B684CA455943B87407CD2EB800D546FB95,
	XRDeviceSimulator_OnRotateModeOverridePerformed_m4DD6A28D80710853E0097DE1F3909BB053E19F07,
	XRDeviceSimulator_OnRotateModeOverrideCanceled_m75BEAEB4D125418AE7393765262251BEA29D4605,
	XRDeviceSimulator_OnToggleMouseTransformationModePerformed_m62CC1589FEF4D4D2931E28CED20AD419F7673594,
	XRDeviceSimulator_OnNegateModePerformed_mF5A3FC1E7834584441A53DEF77D7A0A5B138C36B,
	XRDeviceSimulator_OnNegateModeCanceled_mF056E71CFCC8B0F48042B8A5522BA063DBCE2DBB,
	XRDeviceSimulator_OnXConstraintPerformed_mDDAE59658180A383E2BDCC8A429DC4EE620BB262,
	XRDeviceSimulator_OnXConstraintCanceled_mF01C0548845D2119A9CAC33F8EB339E48E6BFCE0,
	XRDeviceSimulator_OnYConstraintPerformed_m0173CD7EC54D58A438FFA16807AB2772EFB35853,
	XRDeviceSimulator_OnYConstraintCanceled_m427318933BC81323C0AFDEE8C71B6F3B9BBB37B4,
	XRDeviceSimulator_OnZConstraintPerformed_m4ED22AD9BBAB1AF16415EF0946B159F65A6C0CA4,
	XRDeviceSimulator_OnZConstraintCanceled_m684DCF1B8E317BCCC6CE0CE4935D71FC5F50F289,
	XRDeviceSimulator_OnResetPerformed_m9D12641FB8502A5B91E1B27339B0E7EE063B67F3,
	XRDeviceSimulator_OnResetCanceled_m1E37719FF57FDC428E2AFACEF4A20B14A3C2BF7A,
	XRDeviceSimulator_OnToggleCursorLockPerformed_m8A1D0929190187D7B1CBF20FA5D4488DFD4ED011,
	XRDeviceSimulator_OnToggleDevicePositionTargetPerformed_mCCFCF515D5BB98ADDF4E53CC9114399D9C082EFE,
	XRDeviceSimulator_OnTogglePrimary2DAxisTargetPerformed_m62DFCC38E4E98931C3E8DF1712DA44467F833F83,
	XRDeviceSimulator_OnToggleSecondary2DAxisTargetPerformed_mE8CEB9D921E05D1BE58648DA93CD6C08F66805CE,
	XRDeviceSimulator_OnAxis2DPerformed_m0F66BD565DCFBC421C3BB74FB186A96107CD9252,
	XRDeviceSimulator_OnAxis2DCanceled_mD1EC2441F41AAFB2895CA3A95E24971DE45EA5CB,
	XRDeviceSimulator_OnRestingHandAxis2DPerformed_mA2E9B677E765ACA748E9A68BB96877A9C0FDB10F,
	XRDeviceSimulator_OnRestingHandAxis2DCanceled_m93109CCE09FA2CAE73993D9E1A65365F0237AFD1,
	XRDeviceSimulator_OnGripPerformed_m45555D39BD72B048474024A7A7C7E9FB72F48AAE,
	XRDeviceSimulator_OnGripCanceled_m6520B48935110A8C7F25B7A543575977A630C655,
	XRDeviceSimulator_OnTriggerPerformed_m6F547E9B665D0964E31965D8AD2716A78A6DC907,
	XRDeviceSimulator_OnTriggerCanceled_m283F4544B37B56773DACC9DD92DCF44CC0DF1EB3,
	XRDeviceSimulator_OnPrimaryButtonPerformed_m124F6723F67F2CACD4D1783DFA8273934404A1CB,
	XRDeviceSimulator_OnPrimaryButtonCanceled_m95B43E0F3B270432403188607A54C6061EA1D794,
	XRDeviceSimulator_OnSecondaryButtonPerformed_m1B8DFE13115DB786568FB589127E3B9A01D2B4C9,
	XRDeviceSimulator_OnSecondaryButtonCanceled_m425BAA1805DBF8B055BB325F5B70A23762DAD197,
	XRDeviceSimulator_OnMenuPerformed_mD1D644DFD0606C5BE4F51B67B1C915A5C262691F,
	XRDeviceSimulator_OnMenuCanceled_mC5FFC84ACA43297D3C309F5F601B2E3EE83AB20E,
	XRDeviceSimulator_OnPrimary2DAxisClickPerformed_m7CC2E6E040AA141EE326B11C109ECB28F730B30D,
	XRDeviceSimulator_OnPrimary2DAxisClickCanceled_m1010C0CC454EF35FBE04E2D7A93641FD32B493A6,
	XRDeviceSimulator_OnSecondary2DAxisClickPerformed_m28CF38854844D89E2D46F7C4F1D258773C8FCA91,
	XRDeviceSimulator_OnSecondary2DAxisClickCanceled_mF8567A7DC54E0C7FB585C1D05BD97920D2133A96,
	XRDeviceSimulator_OnPrimary2DAxisTouchPerformed_m56D605B3EB1ACF04F73A08E390BE24C8F0D56909,
	XRDeviceSimulator_OnPrimary2DAxisTouchCanceled_mBCC70F3EF5FADFCC4360CF9FD8B53597CD002748,
	XRDeviceSimulator_OnSecondary2DAxisTouchPerformed_mF91A7CE7A57BE193F3AA424D2AEC86C4A507E7FD,
	XRDeviceSimulator_OnSecondary2DAxisTouchCanceled_mA9B90963F3E6F51981D0463D8E22FD2FA77E5EE1,
	XRDeviceSimulator_OnPrimaryTouchPerformed_mB2CEBD175DE3FF771A7553C85A562487B989606E,
	XRDeviceSimulator_OnPrimaryTouchCanceled_m31AA5DACEDD6C2B97FB0F5086707C63D7779C82B,
	XRDeviceSimulator_OnSecondaryTouchPerformed_m036545C71E058E00D72B1096497A772338C432FF,
	XRDeviceSimulator_OnSecondaryTouchCanceled_m5707F4CBCEBD7C40AE36AB14DC2B01367A8FC61A,
	XRDeviceSimulator_GetInputAction_m6A41B50DBE3CC7A7159E84D3A158C36560BB4AD8,
	XRDeviceSimulator__ctor_m52F5FF6A90EBE423D0C4207CBEEEA28E00F01F50,
	XRSimulatedController_get_primary2DAxis_m323C25A3929D29AFBF8D986CA6B39090B0908103,
	XRSimulatedController_set_primary2DAxis_m8E4DAC62428C65DAC69F41536D095ABC5CDC2F75,
	XRSimulatedController_get_trigger_m6C857ADA82B60913A8AD0DF98DCF4F8E6181E087,
	XRSimulatedController_set_trigger_m5147740FA56F49CAF973F53498D174346E824CF0,
	XRSimulatedController_get_grip_m49D414921BB9186AABE3BFD7337F539ADFD99379,
	XRSimulatedController_set_grip_m816763A0BC7ADF3E557635A0BEC4C3559889718C,
	XRSimulatedController_get_secondary2DAxis_m782E667D776EAC2A6AD8FD81F5FCD967B927E890,
	XRSimulatedController_set_secondary2DAxis_mC211E0FED3C0A7CD0E622CF4582811ED1AAB0397,
	XRSimulatedController_get_primaryButton_mBF42EE5D6CE008CB35B3C745A177F50906D44EFB,
	XRSimulatedController_set_primaryButton_m24B4C9D45B4CBD8AC1BAE51DAA81AAB1CBD3AC8B,
	XRSimulatedController_get_primaryTouch_mD02E6C05E7172688D8CF560802F28A4AE8F336BA,
	XRSimulatedController_set_primaryTouch_m10B9B6B82FD96AF73C3C02B5246E1A678D393FFD,
	XRSimulatedController_get_secondaryButton_mEC8A3128207D76F501CAAB4D51E00449B3FF06B3,
	XRSimulatedController_set_secondaryButton_m00AD5FAD1FA7B3919F7D176896C7B206BE052E40,
	XRSimulatedController_get_secondaryTouch_mA58DDFCAF1B7F59632CBF3DAF3C86BDAAC04625A,
	XRSimulatedController_set_secondaryTouch_m062383677858ADB61358AC650344FBA07F08CEA2,
	XRSimulatedController_get_gripButton_m455A8F80FEBC9B529B5C0EC1CDA91E47C19684BF,
	XRSimulatedController_set_gripButton_mBDE3A20238B93A3615C50CEBEB339E3E7D440093,
	XRSimulatedController_get_triggerButton_m9528934FB7246F09CD565040974B5A30EBAC64CE,
	XRSimulatedController_set_triggerButton_m47FEB0AC89CEFA97D7527A2213FCAA7193FC2EF1,
	XRSimulatedController_get_menuButton_mDC50D9A568D267AC711415D2CDBC0A59224D4E49,
	XRSimulatedController_set_menuButton_m732B18585FE0BA10717DCE82FCBEC7E05A403069,
	XRSimulatedController_get_primary2DAxisClick_m444F8F703D81E6413A023D5CB12E393B36D83D23,
	XRSimulatedController_set_primary2DAxisClick_m42B7BA9549D375EAE2ADC395DA06C7AF1ED0B839,
	XRSimulatedController_get_primary2DAxisTouch_m1F472FC37AE6CC0055414447E6ADAA21AD735A9F,
	XRSimulatedController_set_primary2DAxisTouch_mA9BEEE51984E1995812A1BA0402EEBA3EACE490A,
	XRSimulatedController_get_secondary2DAxisClick_m5FF8AB05F3DFEF4B1711F525A04D749A6F09C731,
	XRSimulatedController_set_secondary2DAxisClick_m20FD0ADE245DEF6B0C97CACC7B09FA89CF68D464,
	XRSimulatedController_get_secondary2DAxisTouch_m53965D0BC06C819C456315D25533E351825C1A46,
	XRSimulatedController_set_secondary2DAxisTouch_m47F79E33622C064FA49423AECE66E22E5BDECF82,
	XRSimulatedController_get_batteryLevel_mAA0601728C444A0AEE5490035B1512F54D9630FE,
	XRSimulatedController_set_batteryLevel_m428ADCAB02761E7FCF0732A51672B9B7ED1B3F88,
	XRSimulatedController_get_userPresence_m3FF21CACBBF62F3D231CC583629A70A7EC0EDE4E,
	XRSimulatedController_set_userPresence_mB31695E2AC927F2AC1E4501ADF8148A81F253900,
	XRSimulatedController_FinishSetup_m3FF9228BA9B5BD9506F824E708D8A088EFB45D2A,
	XRSimulatedController__ctor_m832C2B3ACDA212CABE445F8248960849A7CF2C58,
	XRSimulatedControllerState_get_formatId_mE026B646A8286F1AB49928BA2121BA41E41E22AC,
	XRSimulatedControllerState_get_format_mBC60834E041568E9DDE493F77DAC0BFFF9CEADE3,
	XRSimulatedControllerState_WithButton_m1B3D8EB3C81BABA0BCE4DC52632F43C8617AE6CF,
	XRSimulatedControllerState_Reset_m524D26C8145A95198ABEFBCE125E5681436FB793,
	XRSimulatedHMD__ctor_m5A6C1A3D704B28FDB61A81A83BC05159C17EE9B9,
	XRSimulatedHMDState_get_formatId_m9618D28EDCDB79B05B864195329B666C5D617E49,
	XRSimulatedHMDState_get_format_mE598AF3AD93850E9C42AEB5BE7DC82BBDDF14844,
	XRSimulatedHMDState_Reset_mD47104BCF5DBB055F673EA4F7889819079B94406,
	SectorInteraction_get_pressPointOrDefault_mC48A3C5FEF778359655233D9CB76B99707DBD9E8,
	SectorInteraction_get_defaultPressPoint_mC8BA99741478D69AC5AD20C53A2563B269A50703,
	SectorInteraction_set_defaultPressPoint_mE149D21B50B09B456919B022D214762DF1E738B9,
	SectorInteraction_Process_mC8FC7CDD31ADE884395B0F2CCE3445B83E04DCD2,
	SectorInteraction_IsValidDirection_m216A8C540C569A703F921ACB6E62B56C75C271DD,
	SectorInteraction_GetNearestDirection_m33380BA3A20657BFA06F0CA7FB32EE15D48BE9FC,
	SectorInteraction_Reset_m19D8A80BE1E89AEE8C7BF9F16B4B44BB13424D99,
	SectorInteraction__cctor_mE52D92B20C725EF6ED77927E99C5C28F6C50D6B9,
	SectorInteraction_Initialize_mE02B33790B23EABF1D52D8C95E422CD033C90EDE,
	SectorInteraction__ctor_m96B44EF9FE2E61A02C49FEBE2127771D40538BB1,
	ARAnnotationInteractable__ctor_m42B79205F4D0AB0C8CDA30E59428F8E3D820CE51,
	ARBaseGestureInteractable__ctor_mD923A2DF3AA56F3060B2C96084B123A51DFE5164,
	ARPlacementInteractable__ctor_mBD9DBE1093318B6E8A3D673361774C0396B93805,
	ARRotationInteractable__ctor_m161C23C6C6E9AB51E26694B1CDD374D38492145F,
	ARScaleInteractable__ctor_mF7019A322AB2FB8C2DD91DAE3F59A02FC92CB228,
	ARSelectionInteractable__ctor_mD263DD55CC459C55DA650F4B8DCCA90F15854D21,
	ARTranslationInteractable__ctor_m1B370E054C8F454B3B7A3931F044CCFB8DA29709,
	ARGestureInteractor__ctor_m1A489A1BD7E5DCBAE1409FB59E479620257CDA1E,
};
extern void ButtonInfo__ctor_m3CD43D1CD1FBA164B697DC217C9E21B157386DE3_AdjustorThunk (void);
extern void InteractionState_get_active_mEB70F6F01B332BF518B3F7D0048614DF3D11416D_AdjustorThunk (void);
extern void InteractionState_set_active_m4D33BA01AC08B427995FB81C61AADE55059E5D8E_AdjustorThunk (void);
extern void InteractionState_get_activatedThisFrame_m3805CFB50DE51865E8B0CF64EAD512E6535F5990_AdjustorThunk (void);
extern void InteractionState_set_activatedThisFrame_mC09EBD51CFF932E8EF2D2234D98F6F4A68220C04_AdjustorThunk (void);
extern void InteractionState_get_deactivatedThisFrame_m33159255C5B5A45C78F331152CAD09878CDBECC5_AdjustorThunk (void);
extern void InteractionState_set_deactivatedThisFrame_m6463CD864EB7142897A97F8C32485016A6282369_AdjustorThunk (void);
extern void InteractionState_get_deActivatedThisFrame_m77D75E7C5865BE2C111506E4CC5F090AE7F813DB_AdjustorThunk (void);
extern void InteractionState_set_deActivatedThisFrame_m739E5BF6021D03E5C2D9BA5AD6902AD1D2AA6156_AdjustorThunk (void);
extern void InteractionState_ResetFrameDependent_m81E03E441EFBB763DC1DB870345606C2CFB85996_AdjustorThunk (void);
extern void InteractionState_Reset_m7144B5C32B6E7118DA7048CC9A5FE9B3A30E3656_AdjustorThunk (void);
extern void SamplePoint_get_position_m936C42938CBE72F7E0E0D69CC7B3A7BDE7C844C7_AdjustorThunk (void);
extern void SamplePoint_set_position_m3E16630C4554106B58E1BF98C3EC58318EBBD763_AdjustorThunk (void);
extern void SamplePoint_get_parameter_m84322EF1929DC8BEC41F6756BC0D3AB7BF4E2052_AdjustorThunk (void);
extern void SamplePoint_set_parameter_m4D939B740644F770649CCE42F187777F65FE805A_AdjustorThunk (void);
extern void JoystickModel_get_move_m70AE9CDFB7AA66AAFD351D97782ABEB641AA5530_AdjustorThunk (void);
extern void JoystickModel_set_move_mF7448D0EB096CAE4AA3BA600AFD9C256BDB92DEE_AdjustorThunk (void);
extern void JoystickModel_get_submitButtonDown_m4781AB6841EF967FE735A0CBDDC8B7D2C9A824FD_AdjustorThunk (void);
extern void JoystickModel_set_submitButtonDown_m9836DBA6465E2649DD252CFCE998A20560378AA3_AdjustorThunk (void);
extern void JoystickModel_get_submitButtonDelta_m13E6E73ED3FCDE1542C07A452F79728A22D60291_AdjustorThunk (void);
extern void JoystickModel_set_submitButtonDelta_mF1EEFF5C310C6BCD9524ECC014E72238F4F237D9_AdjustorThunk (void);
extern void JoystickModel_get_cancelButtonDown_m4EA1958676D8288D201EC0B465D97A1B3FF20439_AdjustorThunk (void);
extern void JoystickModel_set_cancelButtonDown_m73092D4996A375205A17AEDA95436DE3A2F04C1C_AdjustorThunk (void);
extern void JoystickModel_get_cancelButtonDelta_m2FF7638404C12972C68BB76D67A238D68405DDA7_AdjustorThunk (void);
extern void JoystickModel_set_cancelButtonDelta_m1BA93A60D4381707771AE5BB23B2A29B0F0C899B_AdjustorThunk (void);
extern void JoystickModel_get_implementationData_mEE5E6D8DC8F4FFB90D22903F7550CCAA1A038E05_AdjustorThunk (void);
extern void JoystickModel_set_implementationData_mF353000BE7A505F9092D70AAD885488CD1A7557B_AdjustorThunk (void);
extern void JoystickModel_Reset_m5450A9CD3FC27AA60735EC7A606F7642219B43FB_AdjustorThunk (void);
extern void JoystickModel_OnFrameFinished_mEB59B1809C70BC70F9ED9A7A5242FB8340622279_AdjustorThunk (void);
extern void ImplementationData_get_consecutiveMoveCount_mA34C0AD68D78BF9EFEB3E99ACF6EEC725DE26340_AdjustorThunk (void);
extern void ImplementationData_set_consecutiveMoveCount_m940C6C09D01210E8D6DBF3DFF86464B40ACA4C54_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveDirection_m0F197FADF10FD88BEDFAF6570BE8A925BB606E7E_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveDirection_mB59C221E12AD9B5BADCEDA075D9BDF47C5ED5080_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveTime_mAE3D5AB7B9E7F6A14889824AA76455A95C0A691A_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveTime_m47ECDDF47D60E0A246C83E686B79A1AA3B618A4A_AdjustorThunk (void);
extern void ImplementationData_Reset_mC7E2D248AB737031A8D4EE9820CF3F64C412967D_AdjustorThunk (void);
extern void MouseButtonModel_get_isDown_m1CD763098303E22C163F3C680CCB3641E42F5356_AdjustorThunk (void);
extern void MouseButtonModel_set_isDown_mB524856AE27BCB72E4FA521057966A08DF908483_AdjustorThunk (void);
extern void MouseButtonModel_get_lastFrameDelta_mD9ABCE054D580DD7206A39288CE66DA6A946570B_AdjustorThunk (void);
extern void MouseButtonModel_set_lastFrameDelta_m92B6FEE2BCB34EB047B3CA5DF2DC9316D2C7D8F4_AdjustorThunk (void);
extern void MouseButtonModel_Reset_mC058FBA77FD6DDBF8BFB5CF76EE8C50F56227C06_AdjustorThunk (void);
extern void MouseButtonModel_OnFrameFinished_mE55F730CAF06370BA6AB621D6932657637FBE2B8_AdjustorThunk (void);
extern void MouseButtonModel_CopyTo_m81FB09020B8E0D0AE381CC861ED6AC2EF8B152FE_AdjustorThunk (void);
extern void MouseButtonModel_CopyFrom_mDE54553AD7233A14E41F9806588D6E42BA79B3B7_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_m286676B035D542856422C65A38C50CD08348200F_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_m9EE85DCF9962AF0F2FF6D8A3B8DDEB33ACDEDD33_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_m236A0F23942FAD42399B859634DDBA443D3E2906_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m4C64E9BB61F646ECB6CFCFB4DAF2009709A956FE_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_mE53DCBF0B8F376FB4C9BF1FAEA13E11988495295_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_mA4A1E5E3EABF70132CC91B8F17414E6C26C55CB5_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_mA71A6D911BC67E2877120BEC46F32127E000639D_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_m07B9A00899211C2D9EFE5C7367F0D0CD92671DCD_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_mC3D191EA02E9FDF466A0B0E7DB836743FE3A7E0B_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_m0E6E5DF7C22E6CF52D13D8D577C570C10D404D12_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_m8AAD5F8569332EB9543335E8FFE454513382E35C_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_m08BDACF14EB3891EB34D4BE7611A01E121218129_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_mB4FDDBF950B79E25366E72F266DF02E2348ED813_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_m1F3CABB710E5AC7EE2A51E6B33446F8C343F22FA_AdjustorThunk (void);
extern void ImplementationData_Reset_m26650CA4925208D3CFCC484D107017CE6A8D4509_AdjustorThunk (void);
extern void MouseModel_get_pointerId_m11D2E24194A0D949D405EBB251E239E8FDACB3D1_AdjustorThunk (void);
extern void MouseModel_get_changedThisFrame_mA73BE121871FCA75556A0DB0B5AA26F24B44007A_AdjustorThunk (void);
extern void MouseModel_set_changedThisFrame_m5751B58646A87B9A796E0C73E670BC262696F6DD_AdjustorThunk (void);
extern void MouseModel_get_position_m78546DD8EB343EF0FAA3B00DF5FC8E5D83CAC31E_AdjustorThunk (void);
extern void MouseModel_set_position_m32976C82E8173C43D920E417C1526D08C1848894_AdjustorThunk (void);
extern void MouseModel_get_deltaPosition_mB4120B0D71243A5DCED22C2DCB41F61C752344A0_AdjustorThunk (void);
extern void MouseModel_set_deltaPosition_m49E7E4D3B9976725AA516BE1DF87F41AC18718A2_AdjustorThunk (void);
extern void MouseModel_get_scrollDelta_m575BDC1B8981D596808C1B6D5D3BA0786F0C86FE_AdjustorThunk (void);
extern void MouseModel_set_scrollDelta_m5063B4C4E1B2AD1BEE7146DF1591AAB2203C1942_AdjustorThunk (void);
extern void MouseModel_get_leftButton_mF2FE94CCCFC90A2602FF4161F61F20BA069CC7AF_AdjustorThunk (void);
extern void MouseModel_set_leftButton_mDF681AB6BF3C50A013EDEC3BA1998F84C11C5CA3_AdjustorThunk (void);
extern void MouseModel_set_leftButtonPressed_mB262B7B3E2C450A3C6FC9BEF978FF82C61B4EC05_AdjustorThunk (void);
extern void MouseModel_get_rightButton_m95C9191F32EC76F8DF8E737FC86BE69DD483DE9C_AdjustorThunk (void);
extern void MouseModel_set_rightButton_m0B017073C10DD745A5810A5B764FE4C38C9863B2_AdjustorThunk (void);
extern void MouseModel_set_rightButtonPressed_m3B8AA3966338CB518A1E01412AE8278B8123FA98_AdjustorThunk (void);
extern void MouseModel_get_middleButton_m7771854F89139CEFB78DB492621D8402351FC657_AdjustorThunk (void);
extern void MouseModel_set_middleButton_mD42C3ECBE1B7E8709AA0C037E0CBC65E065CBC86_AdjustorThunk (void);
extern void MouseModel_set_middleButtonPressed_m7E777E54424A123E85C19C8FBC666531045B2E2B_AdjustorThunk (void);
extern void MouseModel__ctor_m83A579E595CC3EA1D0B7871BEA4F7BE3F43BCF5B_AdjustorThunk (void);
extern void MouseModel_OnFrameFinished_mDFDCF666965A09EDD96DA78A378E5D8885AEA760_AdjustorThunk (void);
extern void MouseModel_CopyTo_m40FA373152091998C17145F41864E19AADA3F3EF_AdjustorThunk (void);
extern void MouseModel_CopyFrom_mCD3E50E6FD213121A15576B7F375C6C0605BAC1E_AdjustorThunk (void);
extern void InternalData_get_hoverTargets_mED5DD88CE637A33FCB133AB2A1164DBF31A153C4_AdjustorThunk (void);
extern void InternalData_set_hoverTargets_m58FA8DC4B246C66F1B644FCB88657EBE790FBF45_AdjustorThunk (void);
extern void InternalData_get_pointerTarget_m23F87D3C2E745888E515AFC1B1019D67D3815ABC_AdjustorThunk (void);
extern void InternalData_set_pointerTarget_mF9314EBE084E03FB7CBEDCF822FF4CA6DDDDA5C8_AdjustorThunk (void);
extern void InternalData_Reset_mE88036CD76DEA4817FC9EA538A96AEC351BBFBC3_AdjustorThunk (void);
extern void TouchModel_get_pointerId_m09132E54C14049EE958701E47521DBF87AE46CAA_AdjustorThunk (void);
extern void TouchModel_get_selectPhase_mAB7BD6D97EE045B8CBA8FE6D9674AE69B8FA9764_AdjustorThunk (void);
extern void TouchModel_set_selectPhase_mEFA5BF0498E34859A19804B53380A6A44775E7B2_AdjustorThunk (void);
extern void TouchModel_get_selectDelta_m3C485FF688B2D891723D298D56B95EDDB522EF5B_AdjustorThunk (void);
extern void TouchModel_set_selectDelta_m9D3C5D26D870867BAFAFA5ABD0A327321B442021_AdjustorThunk (void);
extern void TouchModel_get_changedThisFrame_m23FD7722215391AEE0B605CF9D8E66AE909E67B8_AdjustorThunk (void);
extern void TouchModel_set_changedThisFrame_m561781EE6C0BFD95C120EB69B0BC84FCF6C63CB5_AdjustorThunk (void);
extern void TouchModel_get_position_m733738D61FF916C6754A28320A3C9E986B1FEFF9_AdjustorThunk (void);
extern void TouchModel_set_position_m192EEBE8DC7EC01D31651052C7E6EB0594618419_AdjustorThunk (void);
extern void TouchModel_get_deltaPosition_m9E35067BFB1D1BDDC3F1C79A9A00E51A7E969ECC_AdjustorThunk (void);
extern void TouchModel_set_deltaPosition_mA92EDE6055F346698EF3484330B18FDF1479F106_AdjustorThunk (void);
extern void TouchModel__ctor_m2E4B407C745FD930A50FF3DF0E234396E1E9D903_AdjustorThunk (void);
extern void TouchModel_Reset_mF62A73478E369AD0FB97C38E11BF8F704206F7F0_AdjustorThunk (void);
extern void TouchModel_OnFrameFinished_m07CDE88E34A987019751A05CE638F6A08E17EFA0_AdjustorThunk (void);
extern void TouchModel_CopyTo_mDD7D97D3A60CBB3F6C342E12546F02D551EC16E8_AdjustorThunk (void);
extern void TouchModel_CopyFrom_m97D1D1FC51032EB8EA514CC3D32CB82D23577FE9_AdjustorThunk (void);
extern void ImplementationData_get_hoverTargets_m712167711F5E065EF75C3593498EB5682F02524B_AdjustorThunk (void);
extern void ImplementationData_set_hoverTargets_m535B94D1E4CE496E48B6CFC3CD0FEBD8F5D0BFE7_AdjustorThunk (void);
extern void ImplementationData_get_pointerTarget_m99391EE2BB2C1566C578C8366FAA3A33F3A10197_AdjustorThunk (void);
extern void ImplementationData_set_pointerTarget_m9A1690C598287B3ED3BD9752BD92EBC6BFCFBE1E_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_m1D754410DC0DF37DF9AA39C04E7A488E82D958EE_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_m2DBCC77F6E037B90B04E8B22198E776A9E6CCF92_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_mDD847C787AC675CFE647E4216ADCE857A0F5C47F_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m2998A794D01109054102594B68C5876CB19B07AF_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_m5218B58A65B1252DEF55E1E70A2CD93FBDDAF97B_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_m29A8C216BA3FD177E9A443678FADB09D3BAC3169_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_mFF0FD2531D8FAD7DC4F9F2847837F0E85726C65A_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_m05F79A6CC57D04E4DDA51136390484B5EC4294E2_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_m77E3E5A1AC94C35A10A5CE3F6B4A4849D9E31297_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_m085ED8ADB34B7E733689A41969C08E49CEC510A1_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_m5241D8F233E573A0D6A5D95E8D366989CB99A9D3_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_mB8BB6FA60ABC1583206435291ED0A063CF55E34F_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_mA29B766C2B3421C6A6126A032EC06998E6049A2B_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_m9CF28E709931F5E9C64B8E1A2C04BE428E6389D6_AdjustorThunk (void);
extern void ImplementationData_Reset_mA1A9200248AE4DE55F23C8248FC71D19D1297896_AdjustorThunk (void);
extern void RaycastHitData__ctor_mA3105F92D1D16D531B60FACB7453F972D13D9249_AdjustorThunk (void);
extern void RaycastHitData_get_graphic_mF244823E64AB76542BED4C51A8BCF45ACC81144B_AdjustorThunk (void);
extern void RaycastHitData_get_worldHitPosition_m399EAA366E322BE0BD61E56368F737FC29F85E28_AdjustorThunk (void);
extern void RaycastHitData_get_screenPosition_m812ADB2AA30A26B4AB1B5AFBC8F06979131AE08A_AdjustorThunk (void);
extern void RaycastHitData_get_distance_m5F6671106F1D00C942F5402BD17D9F27BFB2C22C_AdjustorThunk (void);
extern void RaycastHitData_get_displayIndex_m32F8946542D364F916BE8D04CB8B61C150B99198_AdjustorThunk (void);
extern void TrackedDeviceModel_get_implementationData_mADCDA47D3AD499318CDE0BBEA2BE132689DE2EE5_AdjustorThunk (void);
extern void TrackedDeviceModel_get_pointerId_mD80CE625A75CA576B28A9C8ACB63D571A6606B67_AdjustorThunk (void);
extern void TrackedDeviceModel_get_maxRaycastDistance_m3A722F116890557E9C451E7966830DB91325C1D0_AdjustorThunk (void);
extern void TrackedDeviceModel_set_maxRaycastDistance_m5A2BDC35BAE802154CA48F0141EB1B68A327124E_AdjustorThunk (void);
extern void TrackedDeviceModel_get_select_m5BA61464B02AB3202ACE442320C0BE21B4CE44F0_AdjustorThunk (void);
extern void TrackedDeviceModel_set_select_m9B5835627C8C86095E53A520F355EB2AEB99E2FF_AdjustorThunk (void);
extern void TrackedDeviceModel_get_selectDelta_mE75B1DD26F07531FC8FB387802D4FF37F1FD6A0A_AdjustorThunk (void);
extern void TrackedDeviceModel_set_selectDelta_mB827DB0A535918C47D1855DE994092A2C3DA6DFE_AdjustorThunk (void);
extern void TrackedDeviceModel_get_changedThisFrame_m68B82453470231A4F6679AD1254FA69B298893CD_AdjustorThunk (void);
extern void TrackedDeviceModel_set_changedThisFrame_m54AAB4E033B8D5FB021C9941D2F0535C9AF03B52_AdjustorThunk (void);
extern void TrackedDeviceModel_get_position_m00C189C1464672F36AB30D8D5D27B530F9DFD1A8_AdjustorThunk (void);
extern void TrackedDeviceModel_set_position_mB7F655655F284799CA203C3050100717371A71B2_AdjustorThunk (void);
extern void TrackedDeviceModel_get_orientation_m1ADE24778B2D6A1B54C1A9276AE2D9DF4A558AE9_AdjustorThunk (void);
extern void TrackedDeviceModel_set_orientation_m84FA015204514B424CFC408A4B0E5C9C6476BDB0_AdjustorThunk (void);
extern void TrackedDeviceModel_get_raycastPoints_mAC3EB88F58248C61A9574674B1BEC617D2673E30_AdjustorThunk (void);
extern void TrackedDeviceModel_set_raycastPoints_m8A427DE3C9C4405E6C1CFDB1D32FF48ECAD45514_AdjustorThunk (void);
extern void TrackedDeviceModel_get_currentRaycast_m73EFCB5A66AE403012FF9FEC6B439D31C2E5266B_AdjustorThunk (void);
extern void TrackedDeviceModel_set_currentRaycast_m8E73593D06B1606AB02B03467243094884F5CD12_AdjustorThunk (void);
extern void TrackedDeviceModel_get_currentRaycastEndpointIndex_m925CFAC84DCE305E31D381EC25B88C5D86D4E805_AdjustorThunk (void);
extern void TrackedDeviceModel_set_currentRaycastEndpointIndex_mA4ABAD82D6BF7784AC287AD89F453D5D7AF9A041_AdjustorThunk (void);
extern void TrackedDeviceModel_get_raycastLayerMask_m026CBA559DE2753C8E0BFDC0C61A86540480AE45_AdjustorThunk (void);
extern void TrackedDeviceModel_set_raycastLayerMask_mF035862C9351DAE42ECFE530D2CC4E5EE6AA8779_AdjustorThunk (void);
extern void TrackedDeviceModel_get_scrollDelta_m98E3C008CE34CA7698FBB522240054675857C201_AdjustorThunk (void);
extern void TrackedDeviceModel_set_scrollDelta_m3044CFFEB48920A17459E320098354EAFD140A41_AdjustorThunk (void);
extern void TrackedDeviceModel__ctor_mAE27577B157ECE28CF94FFACE80975BC194E0EC1_AdjustorThunk (void);
extern void TrackedDeviceModel_Reset_mBABBE929D784F92680CFC66E4BD26DC7F9EA15ED_AdjustorThunk (void);
extern void TrackedDeviceModel_OnFrameFinished_m32FC34175809DBB3A1BBC26699D6D9FB40A7C480_AdjustorThunk (void);
extern void TrackedDeviceModel_CopyTo_mC2DC5C1F6ADF2CBF06B7D8288964DAB339E7D692_AdjustorThunk (void);
extern void TrackedDeviceModel_CopyFrom_mE187E9E91E324AA0ABD3D1E8CD30DD793BFA0C39_AdjustorThunk (void);
extern void ImplementationData_get_hoverTargets_m41E773C53C151D97E9492E8F45ED8FB4E96A59A7_AdjustorThunk (void);
extern void ImplementationData_set_hoverTargets_m19F1CB02F7A7692C5D20A89947DFABFD92CAB455_AdjustorThunk (void);
extern void ImplementationData_get_pointerTarget_m4B202866FF1FA91937343DCCB013B74DC114FE60_AdjustorThunk (void);
extern void ImplementationData_set_pointerTarget_mFB25C58ADE397F423F6E9C022BBB41B0553B740E_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_m46C5339146DD29A9F8F17820C6EF44A3E7BEAF6C_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_m456D482B7022A4F5920ADFC3CC40B9A9AD8E3757_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_m5CCBBBA87FDEBC3EA7EEEA060BE5D75D869AF5EF_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m29F68A8DB6BAF909CDFCD88FD5F5A319059AEE90_AdjustorThunk (void);
extern void ImplementationData_get_position_m956AC6C7FB1ADEC574061B12EA47FED7780AC498_AdjustorThunk (void);
extern void ImplementationData_set_position_m8E4DD90017F1D25E85A7C3C81B1DE163E30DB7DB_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_mCABB186BED5B1D8518709A46FE359DB489EF86C1_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_m0A20F9AB3E05608A87702FC7D9AEB11BCA833726_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_m1E35327FB13E41C71374DBB7B117D0DE32C337F0_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_m088EA8CF851F035A6E05B7AAD0DD4DFAE9504745_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_m1A17AB48043129AEB2EBEA6946AA699E0C8BD61C_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_m3D05029ED302431CAE9346C26F4CC2BBF4A3E066_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_mCC3398E95B1DBBB0A3A63AB307E76ACD390BF72F_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_m9925CC40E6A24D23784861334482B1E10B493D43_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_mA1BB6E49C20D8AF62693ED0023261303286D2C3B_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_mA2E82652C8A181F5EFDFD1CEBDFF655F07D895F3_AdjustorThunk (void);
extern void ImplementationData_Reset_mAB96D4826DF6DD8D1A45E408B3771A340B70CC50_AdjustorThunk (void);
extern void RegisteredInteractor__ctor_m599746C9D0CEC3BC8EE3848164F5CD99611FC30C_AdjustorThunk (void);
extern void RegisteredTouch__ctor_m6464420D1DFD3E6F407C3582184963173CFBF959_AdjustorThunk (void);
extern void XRSimulatedControllerState_get_format_mBC60834E041568E9DDE493F77DAC0BFFF9CEADE3_AdjustorThunk (void);
extern void XRSimulatedControllerState_WithButton_m1B3D8EB3C81BABA0BCE4DC52632F43C8617AE6CF_AdjustorThunk (void);
extern void XRSimulatedControllerState_Reset_m524D26C8145A95198ABEFBCE125E5681436FB793_AdjustorThunk (void);
extern void XRSimulatedHMDState_get_format_mE598AF3AD93850E9C42AEB5BE7DC82BBDDF14844_AdjustorThunk (void);
extern void XRSimulatedHMDState_Reset_mD47104BCF5DBB055F673EA4F7889819079B94406_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[184] = 
{
	{ 0x06000005, ButtonInfo__ctor_m3CD43D1CD1FBA164B697DC217C9E21B157386DE3_AdjustorThunk },
	{ 0x0600004F, InteractionState_get_active_mEB70F6F01B332BF518B3F7D0048614DF3D11416D_AdjustorThunk },
	{ 0x06000050, InteractionState_set_active_m4D33BA01AC08B427995FB81C61AADE55059E5D8E_AdjustorThunk },
	{ 0x06000051, InteractionState_get_activatedThisFrame_m3805CFB50DE51865E8B0CF64EAD512E6535F5990_AdjustorThunk },
	{ 0x06000052, InteractionState_set_activatedThisFrame_mC09EBD51CFF932E8EF2D2234D98F6F4A68220C04_AdjustorThunk },
	{ 0x06000053, InteractionState_get_deactivatedThisFrame_m33159255C5B5A45C78F331152CAD09878CDBECC5_AdjustorThunk },
	{ 0x06000054, InteractionState_set_deactivatedThisFrame_m6463CD864EB7142897A97F8C32485016A6282369_AdjustorThunk },
	{ 0x06000055, InteractionState_get_deActivatedThisFrame_m77D75E7C5865BE2C111506E4CC5F090AE7F813DB_AdjustorThunk },
	{ 0x06000056, InteractionState_set_deActivatedThisFrame_m739E5BF6021D03E5C2D9BA5AD6902AD1D2AA6156_AdjustorThunk },
	{ 0x06000057, InteractionState_ResetFrameDependent_m81E03E441EFBB763DC1DB870345606C2CFB85996_AdjustorThunk },
	{ 0x06000058, InteractionState_Reset_m7144B5C32B6E7118DA7048CC9A5FE9B3A30E3656_AdjustorThunk },
	{ 0x060002D0, SamplePoint_get_position_m936C42938CBE72F7E0E0D69CC7B3A7BDE7C844C7_AdjustorThunk },
	{ 0x060002D1, SamplePoint_set_position_m3E16630C4554106B58E1BF98C3EC58318EBBD763_AdjustorThunk },
	{ 0x060002D2, SamplePoint_get_parameter_m84322EF1929DC8BEC41F6756BC0D3AB7BF4E2052_AdjustorThunk },
	{ 0x060002D3, SamplePoint_set_parameter_m4D939B740644F770649CCE42F187777F65FE805A_AdjustorThunk },
	{ 0x0600042D, JoystickModel_get_move_m70AE9CDFB7AA66AAFD351D97782ABEB641AA5530_AdjustorThunk },
	{ 0x0600042E, JoystickModel_set_move_mF7448D0EB096CAE4AA3BA600AFD9C256BDB92DEE_AdjustorThunk },
	{ 0x0600042F, JoystickModel_get_submitButtonDown_m4781AB6841EF967FE735A0CBDDC8B7D2C9A824FD_AdjustorThunk },
	{ 0x06000430, JoystickModel_set_submitButtonDown_m9836DBA6465E2649DD252CFCE998A20560378AA3_AdjustorThunk },
	{ 0x06000431, JoystickModel_get_submitButtonDelta_m13E6E73ED3FCDE1542C07A452F79728A22D60291_AdjustorThunk },
	{ 0x06000432, JoystickModel_set_submitButtonDelta_mF1EEFF5C310C6BCD9524ECC014E72238F4F237D9_AdjustorThunk },
	{ 0x06000433, JoystickModel_get_cancelButtonDown_m4EA1958676D8288D201EC0B465D97A1B3FF20439_AdjustorThunk },
	{ 0x06000434, JoystickModel_set_cancelButtonDown_m73092D4996A375205A17AEDA95436DE3A2F04C1C_AdjustorThunk },
	{ 0x06000435, JoystickModel_get_cancelButtonDelta_m2FF7638404C12972C68BB76D67A238D68405DDA7_AdjustorThunk },
	{ 0x06000436, JoystickModel_set_cancelButtonDelta_m1BA93A60D4381707771AE5BB23B2A29B0F0C899B_AdjustorThunk },
	{ 0x06000437, JoystickModel_get_implementationData_mEE5E6D8DC8F4FFB90D22903F7550CCAA1A038E05_AdjustorThunk },
	{ 0x06000438, JoystickModel_set_implementationData_mF353000BE7A505F9092D70AAD885488CD1A7557B_AdjustorThunk },
	{ 0x06000439, JoystickModel_Reset_m5450A9CD3FC27AA60735EC7A606F7642219B43FB_AdjustorThunk },
	{ 0x0600043A, JoystickModel_OnFrameFinished_mEB59B1809C70BC70F9ED9A7A5242FB8340622279_AdjustorThunk },
	{ 0x0600043B, ImplementationData_get_consecutiveMoveCount_mA34C0AD68D78BF9EFEB3E99ACF6EEC725DE26340_AdjustorThunk },
	{ 0x0600043C, ImplementationData_set_consecutiveMoveCount_m940C6C09D01210E8D6DBF3DFF86464B40ACA4C54_AdjustorThunk },
	{ 0x0600043D, ImplementationData_get_lastMoveDirection_m0F197FADF10FD88BEDFAF6570BE8A925BB606E7E_AdjustorThunk },
	{ 0x0600043E, ImplementationData_set_lastMoveDirection_mB59C221E12AD9B5BADCEDA075D9BDF47C5ED5080_AdjustorThunk },
	{ 0x0600043F, ImplementationData_get_lastMoveTime_mAE3D5AB7B9E7F6A14889824AA76455A95C0A691A_AdjustorThunk },
	{ 0x06000440, ImplementationData_set_lastMoveTime_m47ECDDF47D60E0A246C83E686B79A1AA3B618A4A_AdjustorThunk },
	{ 0x06000441, ImplementationData_Reset_mC7E2D248AB737031A8D4EE9820CF3F64C412967D_AdjustorThunk },
	{ 0x06000442, MouseButtonModel_get_isDown_m1CD763098303E22C163F3C680CCB3641E42F5356_AdjustorThunk },
	{ 0x06000443, MouseButtonModel_set_isDown_mB524856AE27BCB72E4FA521057966A08DF908483_AdjustorThunk },
	{ 0x06000444, MouseButtonModel_get_lastFrameDelta_mD9ABCE054D580DD7206A39288CE66DA6A946570B_AdjustorThunk },
	{ 0x06000445, MouseButtonModel_set_lastFrameDelta_m92B6FEE2BCB34EB047B3CA5DF2DC9316D2C7D8F4_AdjustorThunk },
	{ 0x06000446, MouseButtonModel_Reset_mC058FBA77FD6DDBF8BFB5CF76EE8C50F56227C06_AdjustorThunk },
	{ 0x06000447, MouseButtonModel_OnFrameFinished_mE55F730CAF06370BA6AB621D6932657637FBE2B8_AdjustorThunk },
	{ 0x06000448, MouseButtonModel_CopyTo_m81FB09020B8E0D0AE381CC861ED6AC2EF8B152FE_AdjustorThunk },
	{ 0x06000449, MouseButtonModel_CopyFrom_mDE54553AD7233A14E41F9806588D6E42BA79B3B7_AdjustorThunk },
	{ 0x0600044A, ImplementationData_get_isDragging_m286676B035D542856422C65A38C50CD08348200F_AdjustorThunk },
	{ 0x0600044B, ImplementationData_set_isDragging_m9EE85DCF9962AF0F2FF6D8A3B8DDEB33ACDEDD33_AdjustorThunk },
	{ 0x0600044C, ImplementationData_get_pressedTime_m236A0F23942FAD42399B859634DDBA443D3E2906_AdjustorThunk },
	{ 0x0600044D, ImplementationData_set_pressedTime_m4C64E9BB61F646ECB6CFCFB4DAF2009709A956FE_AdjustorThunk },
	{ 0x0600044E, ImplementationData_get_pressedPosition_mE53DCBF0B8F376FB4C9BF1FAEA13E11988495295_AdjustorThunk },
	{ 0x0600044F, ImplementationData_set_pressedPosition_mA4A1E5E3EABF70132CC91B8F17414E6C26C55CB5_AdjustorThunk },
	{ 0x06000450, ImplementationData_get_pressedRaycast_mA71A6D911BC67E2877120BEC46F32127E000639D_AdjustorThunk },
	{ 0x06000451, ImplementationData_set_pressedRaycast_m07B9A00899211C2D9EFE5C7367F0D0CD92671DCD_AdjustorThunk },
	{ 0x06000452, ImplementationData_get_pressedGameObject_mC3D191EA02E9FDF466A0B0E7DB836743FE3A7E0B_AdjustorThunk },
	{ 0x06000453, ImplementationData_set_pressedGameObject_m0E6E5DF7C22E6CF52D13D8D577C570C10D404D12_AdjustorThunk },
	{ 0x06000454, ImplementationData_get_pressedGameObjectRaw_m8AAD5F8569332EB9543335E8FFE454513382E35C_AdjustorThunk },
	{ 0x06000455, ImplementationData_set_pressedGameObjectRaw_m08BDACF14EB3891EB34D4BE7611A01E121218129_AdjustorThunk },
	{ 0x06000456, ImplementationData_get_draggedGameObject_mB4FDDBF950B79E25366E72F266DF02E2348ED813_AdjustorThunk },
	{ 0x06000457, ImplementationData_set_draggedGameObject_m1F3CABB710E5AC7EE2A51E6B33446F8C343F22FA_AdjustorThunk },
	{ 0x06000458, ImplementationData_Reset_m26650CA4925208D3CFCC484D107017CE6A8D4509_AdjustorThunk },
	{ 0x06000459, MouseModel_get_pointerId_m11D2E24194A0D949D405EBB251E239E8FDACB3D1_AdjustorThunk },
	{ 0x0600045A, MouseModel_get_changedThisFrame_mA73BE121871FCA75556A0DB0B5AA26F24B44007A_AdjustorThunk },
	{ 0x0600045B, MouseModel_set_changedThisFrame_m5751B58646A87B9A796E0C73E670BC262696F6DD_AdjustorThunk },
	{ 0x0600045C, MouseModel_get_position_m78546DD8EB343EF0FAA3B00DF5FC8E5D83CAC31E_AdjustorThunk },
	{ 0x0600045D, MouseModel_set_position_m32976C82E8173C43D920E417C1526D08C1848894_AdjustorThunk },
	{ 0x0600045E, MouseModel_get_deltaPosition_mB4120B0D71243A5DCED22C2DCB41F61C752344A0_AdjustorThunk },
	{ 0x0600045F, MouseModel_set_deltaPosition_m49E7E4D3B9976725AA516BE1DF87F41AC18718A2_AdjustorThunk },
	{ 0x06000460, MouseModel_get_scrollDelta_m575BDC1B8981D596808C1B6D5D3BA0786F0C86FE_AdjustorThunk },
	{ 0x06000461, MouseModel_set_scrollDelta_m5063B4C4E1B2AD1BEE7146DF1591AAB2203C1942_AdjustorThunk },
	{ 0x06000462, MouseModel_get_leftButton_mF2FE94CCCFC90A2602FF4161F61F20BA069CC7AF_AdjustorThunk },
	{ 0x06000463, MouseModel_set_leftButton_mDF681AB6BF3C50A013EDEC3BA1998F84C11C5CA3_AdjustorThunk },
	{ 0x06000464, MouseModel_set_leftButtonPressed_mB262B7B3E2C450A3C6FC9BEF978FF82C61B4EC05_AdjustorThunk },
	{ 0x06000465, MouseModel_get_rightButton_m95C9191F32EC76F8DF8E737FC86BE69DD483DE9C_AdjustorThunk },
	{ 0x06000466, MouseModel_set_rightButton_m0B017073C10DD745A5810A5B764FE4C38C9863B2_AdjustorThunk },
	{ 0x06000467, MouseModel_set_rightButtonPressed_m3B8AA3966338CB518A1E01412AE8278B8123FA98_AdjustorThunk },
	{ 0x06000468, MouseModel_get_middleButton_m7771854F89139CEFB78DB492621D8402351FC657_AdjustorThunk },
	{ 0x06000469, MouseModel_set_middleButton_mD42C3ECBE1B7E8709AA0C037E0CBC65E065CBC86_AdjustorThunk },
	{ 0x0600046A, MouseModel_set_middleButtonPressed_m7E777E54424A123E85C19C8FBC666531045B2E2B_AdjustorThunk },
	{ 0x0600046B, MouseModel__ctor_m83A579E595CC3EA1D0B7871BEA4F7BE3F43BCF5B_AdjustorThunk },
	{ 0x0600046C, MouseModel_OnFrameFinished_mDFDCF666965A09EDD96DA78A378E5D8885AEA760_AdjustorThunk },
	{ 0x0600046D, MouseModel_CopyTo_m40FA373152091998C17145F41864E19AADA3F3EF_AdjustorThunk },
	{ 0x0600046E, MouseModel_CopyFrom_mCD3E50E6FD213121A15576B7F375C6C0605BAC1E_AdjustorThunk },
	{ 0x0600046F, InternalData_get_hoverTargets_mED5DD88CE637A33FCB133AB2A1164DBF31A153C4_AdjustorThunk },
	{ 0x06000470, InternalData_set_hoverTargets_m58FA8DC4B246C66F1B644FCB88657EBE790FBF45_AdjustorThunk },
	{ 0x06000471, InternalData_get_pointerTarget_m23F87D3C2E745888E515AFC1B1019D67D3815ABC_AdjustorThunk },
	{ 0x06000472, InternalData_set_pointerTarget_mF9314EBE084E03FB7CBEDCF822FF4CA6DDDDA5C8_AdjustorThunk },
	{ 0x06000473, InternalData_Reset_mE88036CD76DEA4817FC9EA538A96AEC351BBFBC3_AdjustorThunk },
	{ 0x06000474, TouchModel_get_pointerId_m09132E54C14049EE958701E47521DBF87AE46CAA_AdjustorThunk },
	{ 0x06000475, TouchModel_get_selectPhase_mAB7BD6D97EE045B8CBA8FE6D9674AE69B8FA9764_AdjustorThunk },
	{ 0x06000476, TouchModel_set_selectPhase_mEFA5BF0498E34859A19804B53380A6A44775E7B2_AdjustorThunk },
	{ 0x06000477, TouchModel_get_selectDelta_m3C485FF688B2D891723D298D56B95EDDB522EF5B_AdjustorThunk },
	{ 0x06000478, TouchModel_set_selectDelta_m9D3C5D26D870867BAFAFA5ABD0A327321B442021_AdjustorThunk },
	{ 0x06000479, TouchModel_get_changedThisFrame_m23FD7722215391AEE0B605CF9D8E66AE909E67B8_AdjustorThunk },
	{ 0x0600047A, TouchModel_set_changedThisFrame_m561781EE6C0BFD95C120EB69B0BC84FCF6C63CB5_AdjustorThunk },
	{ 0x0600047B, TouchModel_get_position_m733738D61FF916C6754A28320A3C9E986B1FEFF9_AdjustorThunk },
	{ 0x0600047C, TouchModel_set_position_m192EEBE8DC7EC01D31651052C7E6EB0594618419_AdjustorThunk },
	{ 0x0600047D, TouchModel_get_deltaPosition_m9E35067BFB1D1BDDC3F1C79A9A00E51A7E969ECC_AdjustorThunk },
	{ 0x0600047E, TouchModel_set_deltaPosition_mA92EDE6055F346698EF3484330B18FDF1479F106_AdjustorThunk },
	{ 0x0600047F, TouchModel__ctor_m2E4B407C745FD930A50FF3DF0E234396E1E9D903_AdjustorThunk },
	{ 0x06000480, TouchModel_Reset_mF62A73478E369AD0FB97C38E11BF8F704206F7F0_AdjustorThunk },
	{ 0x06000481, TouchModel_OnFrameFinished_m07CDE88E34A987019751A05CE638F6A08E17EFA0_AdjustorThunk },
	{ 0x06000482, TouchModel_CopyTo_mDD7D97D3A60CBB3F6C342E12546F02D551EC16E8_AdjustorThunk },
	{ 0x06000483, TouchModel_CopyFrom_m97D1D1FC51032EB8EA514CC3D32CB82D23577FE9_AdjustorThunk },
	{ 0x06000484, ImplementationData_get_hoverTargets_m712167711F5E065EF75C3593498EB5682F02524B_AdjustorThunk },
	{ 0x06000485, ImplementationData_set_hoverTargets_m535B94D1E4CE496E48B6CFC3CD0FEBD8F5D0BFE7_AdjustorThunk },
	{ 0x06000486, ImplementationData_get_pointerTarget_m99391EE2BB2C1566C578C8366FAA3A33F3A10197_AdjustorThunk },
	{ 0x06000487, ImplementationData_set_pointerTarget_m9A1690C598287B3ED3BD9752BD92EBC6BFCFBE1E_AdjustorThunk },
	{ 0x06000488, ImplementationData_get_isDragging_m1D754410DC0DF37DF9AA39C04E7A488E82D958EE_AdjustorThunk },
	{ 0x06000489, ImplementationData_set_isDragging_m2DBCC77F6E037B90B04E8B22198E776A9E6CCF92_AdjustorThunk },
	{ 0x0600048A, ImplementationData_get_pressedTime_mDD847C787AC675CFE647E4216ADCE857A0F5C47F_AdjustorThunk },
	{ 0x0600048B, ImplementationData_set_pressedTime_m2998A794D01109054102594B68C5876CB19B07AF_AdjustorThunk },
	{ 0x0600048C, ImplementationData_get_pressedPosition_m5218B58A65B1252DEF55E1E70A2CD93FBDDAF97B_AdjustorThunk },
	{ 0x0600048D, ImplementationData_set_pressedPosition_m29A8C216BA3FD177E9A443678FADB09D3BAC3169_AdjustorThunk },
	{ 0x0600048E, ImplementationData_get_pressedRaycast_mFF0FD2531D8FAD7DC4F9F2847837F0E85726C65A_AdjustorThunk },
	{ 0x0600048F, ImplementationData_set_pressedRaycast_m05F79A6CC57D04E4DDA51136390484B5EC4294E2_AdjustorThunk },
	{ 0x06000490, ImplementationData_get_pressedGameObject_m77E3E5A1AC94C35A10A5CE3F6B4A4849D9E31297_AdjustorThunk },
	{ 0x06000491, ImplementationData_set_pressedGameObject_m085ED8ADB34B7E733689A41969C08E49CEC510A1_AdjustorThunk },
	{ 0x06000492, ImplementationData_get_pressedGameObjectRaw_m5241D8F233E573A0D6A5D95E8D366989CB99A9D3_AdjustorThunk },
	{ 0x06000493, ImplementationData_set_pressedGameObjectRaw_mB8BB6FA60ABC1583206435291ED0A063CF55E34F_AdjustorThunk },
	{ 0x06000494, ImplementationData_get_draggedGameObject_mA29B766C2B3421C6A6126A032EC06998E6049A2B_AdjustorThunk },
	{ 0x06000495, ImplementationData_set_draggedGameObject_m9CF28E709931F5E9C64B8E1A2C04BE428E6389D6_AdjustorThunk },
	{ 0x06000496, ImplementationData_Reset_mA1A9200248AE4DE55F23C8248FC71D19D1297896_AdjustorThunk },
	{ 0x060004B4, RaycastHitData__ctor_mA3105F92D1D16D531B60FACB7453F972D13D9249_AdjustorThunk },
	{ 0x060004B5, RaycastHitData_get_graphic_mF244823E64AB76542BED4C51A8BCF45ACC81144B_AdjustorThunk },
	{ 0x060004B6, RaycastHitData_get_worldHitPosition_m399EAA366E322BE0BD61E56368F737FC29F85E28_AdjustorThunk },
	{ 0x060004B7, RaycastHitData_get_screenPosition_m812ADB2AA30A26B4AB1B5AFBC8F06979131AE08A_AdjustorThunk },
	{ 0x060004B8, RaycastHitData_get_distance_m5F6671106F1D00C942F5402BD17D9F27BFB2C22C_AdjustorThunk },
	{ 0x060004B9, RaycastHitData_get_displayIndex_m32F8946542D364F916BE8D04CB8B61C150B99198_AdjustorThunk },
	{ 0x060004BC, TrackedDeviceModel_get_implementationData_mADCDA47D3AD499318CDE0BBEA2BE132689DE2EE5_AdjustorThunk },
	{ 0x060004BD, TrackedDeviceModel_get_pointerId_mD80CE625A75CA576B28A9C8ACB63D571A6606B67_AdjustorThunk },
	{ 0x060004BE, TrackedDeviceModel_get_maxRaycastDistance_m3A722F116890557E9C451E7966830DB91325C1D0_AdjustorThunk },
	{ 0x060004BF, TrackedDeviceModel_set_maxRaycastDistance_m5A2BDC35BAE802154CA48F0141EB1B68A327124E_AdjustorThunk },
	{ 0x060004C0, TrackedDeviceModel_get_select_m5BA61464B02AB3202ACE442320C0BE21B4CE44F0_AdjustorThunk },
	{ 0x060004C1, TrackedDeviceModel_set_select_m9B5835627C8C86095E53A520F355EB2AEB99E2FF_AdjustorThunk },
	{ 0x060004C2, TrackedDeviceModel_get_selectDelta_mE75B1DD26F07531FC8FB387802D4FF37F1FD6A0A_AdjustorThunk },
	{ 0x060004C3, TrackedDeviceModel_set_selectDelta_mB827DB0A535918C47D1855DE994092A2C3DA6DFE_AdjustorThunk },
	{ 0x060004C4, TrackedDeviceModel_get_changedThisFrame_m68B82453470231A4F6679AD1254FA69B298893CD_AdjustorThunk },
	{ 0x060004C5, TrackedDeviceModel_set_changedThisFrame_m54AAB4E033B8D5FB021C9941D2F0535C9AF03B52_AdjustorThunk },
	{ 0x060004C6, TrackedDeviceModel_get_position_m00C189C1464672F36AB30D8D5D27B530F9DFD1A8_AdjustorThunk },
	{ 0x060004C7, TrackedDeviceModel_set_position_mB7F655655F284799CA203C3050100717371A71B2_AdjustorThunk },
	{ 0x060004C8, TrackedDeviceModel_get_orientation_m1ADE24778B2D6A1B54C1A9276AE2D9DF4A558AE9_AdjustorThunk },
	{ 0x060004C9, TrackedDeviceModel_set_orientation_m84FA015204514B424CFC408A4B0E5C9C6476BDB0_AdjustorThunk },
	{ 0x060004CA, TrackedDeviceModel_get_raycastPoints_mAC3EB88F58248C61A9574674B1BEC617D2673E30_AdjustorThunk },
	{ 0x060004CB, TrackedDeviceModel_set_raycastPoints_m8A427DE3C9C4405E6C1CFDB1D32FF48ECAD45514_AdjustorThunk },
	{ 0x060004CC, TrackedDeviceModel_get_currentRaycast_m73EFCB5A66AE403012FF9FEC6B439D31C2E5266B_AdjustorThunk },
	{ 0x060004CD, TrackedDeviceModel_set_currentRaycast_m8E73593D06B1606AB02B03467243094884F5CD12_AdjustorThunk },
	{ 0x060004CE, TrackedDeviceModel_get_currentRaycastEndpointIndex_m925CFAC84DCE305E31D381EC25B88C5D86D4E805_AdjustorThunk },
	{ 0x060004CF, TrackedDeviceModel_set_currentRaycastEndpointIndex_mA4ABAD82D6BF7784AC287AD89F453D5D7AF9A041_AdjustorThunk },
	{ 0x060004D0, TrackedDeviceModel_get_raycastLayerMask_m026CBA559DE2753C8E0BFDC0C61A86540480AE45_AdjustorThunk },
	{ 0x060004D1, TrackedDeviceModel_set_raycastLayerMask_mF035862C9351DAE42ECFE530D2CC4E5EE6AA8779_AdjustorThunk },
	{ 0x060004D2, TrackedDeviceModel_get_scrollDelta_m98E3C008CE34CA7698FBB522240054675857C201_AdjustorThunk },
	{ 0x060004D3, TrackedDeviceModel_set_scrollDelta_m3044CFFEB48920A17459E320098354EAFD140A41_AdjustorThunk },
	{ 0x060004D4, TrackedDeviceModel__ctor_mAE27577B157ECE28CF94FFACE80975BC194E0EC1_AdjustorThunk },
	{ 0x060004D5, TrackedDeviceModel_Reset_mBABBE929D784F92680CFC66E4BD26DC7F9EA15ED_AdjustorThunk },
	{ 0x060004D6, TrackedDeviceModel_OnFrameFinished_m32FC34175809DBB3A1BBC26699D6D9FB40A7C480_AdjustorThunk },
	{ 0x060004D7, TrackedDeviceModel_CopyTo_mC2DC5C1F6ADF2CBF06B7D8288964DAB339E7D692_AdjustorThunk },
	{ 0x060004D8, TrackedDeviceModel_CopyFrom_mE187E9E91E324AA0ABD3D1E8CD30DD793BFA0C39_AdjustorThunk },
	{ 0x060004D9, ImplementationData_get_hoverTargets_m41E773C53C151D97E9492E8F45ED8FB4E96A59A7_AdjustorThunk },
	{ 0x060004DA, ImplementationData_set_hoverTargets_m19F1CB02F7A7692C5D20A89947DFABFD92CAB455_AdjustorThunk },
	{ 0x060004DB, ImplementationData_get_pointerTarget_m4B202866FF1FA91937343DCCB013B74DC114FE60_AdjustorThunk },
	{ 0x060004DC, ImplementationData_set_pointerTarget_mFB25C58ADE397F423F6E9C022BBB41B0553B740E_AdjustorThunk },
	{ 0x060004DD, ImplementationData_get_isDragging_m46C5339146DD29A9F8F17820C6EF44A3E7BEAF6C_AdjustorThunk },
	{ 0x060004DE, ImplementationData_set_isDragging_m456D482B7022A4F5920ADFC3CC40B9A9AD8E3757_AdjustorThunk },
	{ 0x060004DF, ImplementationData_get_pressedTime_m5CCBBBA87FDEBC3EA7EEEA060BE5D75D869AF5EF_AdjustorThunk },
	{ 0x060004E0, ImplementationData_set_pressedTime_m29F68A8DB6BAF909CDFCD88FD5F5A319059AEE90_AdjustorThunk },
	{ 0x060004E1, ImplementationData_get_position_m956AC6C7FB1ADEC574061B12EA47FED7780AC498_AdjustorThunk },
	{ 0x060004E2, ImplementationData_set_position_m8E4DD90017F1D25E85A7C3C81B1DE163E30DB7DB_AdjustorThunk },
	{ 0x060004E3, ImplementationData_get_pressedPosition_mCABB186BED5B1D8518709A46FE359DB489EF86C1_AdjustorThunk },
	{ 0x060004E4, ImplementationData_set_pressedPosition_m0A20F9AB3E05608A87702FC7D9AEB11BCA833726_AdjustorThunk },
	{ 0x060004E5, ImplementationData_get_pressedRaycast_m1E35327FB13E41C71374DBB7B117D0DE32C337F0_AdjustorThunk },
	{ 0x060004E6, ImplementationData_set_pressedRaycast_m088EA8CF851F035A6E05B7AAD0DD4DFAE9504745_AdjustorThunk },
	{ 0x060004E7, ImplementationData_get_pressedGameObject_m1A17AB48043129AEB2EBEA6946AA699E0C8BD61C_AdjustorThunk },
	{ 0x060004E8, ImplementationData_set_pressedGameObject_m3D05029ED302431CAE9346C26F4CC2BBF4A3E066_AdjustorThunk },
	{ 0x060004E9, ImplementationData_get_pressedGameObjectRaw_mCC3398E95B1DBBB0A3A63AB307E76ACD390BF72F_AdjustorThunk },
	{ 0x060004EA, ImplementationData_set_pressedGameObjectRaw_m9925CC40E6A24D23784861334482B1E10B493D43_AdjustorThunk },
	{ 0x060004EB, ImplementationData_get_draggedGameObject_mA1BB6E49C20D8AF62693ED0023261303286D2C3B_AdjustorThunk },
	{ 0x060004EC, ImplementationData_set_draggedGameObject_mA2E82652C8A181F5EFDFD1CEBDFF655F07D895F3_AdjustorThunk },
	{ 0x060004ED, ImplementationData_Reset_mAB96D4826DF6DD8D1A45E408B3771A340B70CC50_AdjustorThunk },
	{ 0x0600051E, RegisteredInteractor__ctor_m599746C9D0CEC3BC8EE3848164F5CD99611FC30C_AdjustorThunk },
	{ 0x0600051F, RegisteredTouch__ctor_m6464420D1DFD3E6F407C3582184963173CFBF959_AdjustorThunk },
	{ 0x0600064B, XRSimulatedControllerState_get_format_mBC60834E041568E9DDE493F77DAC0BFFF9CEADE3_AdjustorThunk },
	{ 0x0600064C, XRSimulatedControllerState_WithButton_m1B3D8EB3C81BABA0BCE4DC52632F43C8617AE6CF_AdjustorThunk },
	{ 0x0600064D, XRSimulatedControllerState_Reset_m524D26C8145A95198ABEFBCE125E5681436FB793_AdjustorThunk },
	{ 0x06000650, XRSimulatedHMDState_get_format_mE598AF3AD93850E9C42AEB5BE7DC82BBDDF14844_AdjustorThunk },
	{ 0x06000651, XRSimulatedHMDState_Reset_mD47104BCF5DBB055F673EA4F7889819079B94406_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1635] = 
{
	2890,
	2890,
	3392,
	4497,
	1294,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2803,
	2280,
	2861,
	2332,
	2890,
	2890,
	2308,
	2308,
	989,
	2890,
	2890,
	1053,
	4065,
	4326,
	2890,
	1935,
	2816,
	2292,
	2858,
	2329,
	2858,
	2329,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2819,
	2819,
	2819,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	1884,
	2308,
	1177,
	2308,
	2308,
	2308,
	2890,
	1333,
	989,
	2890,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2890,
	2890,
	2890,
	2308,
	103,
	1312,
	2890,
	2890,
	2834,
	2816,
	2292,
	2816,
	2292,
	2816,
	2292,
	2816,
	2292,
	2861,
	2332,
	2816,
	2292,
	2816,
	2292,
	2816,
	2292,
	2816,
	2292,
	2834,
	2308,
	2806,
	2308,
	2308,
	1133,
	989,
	2890,
	2858,
	2329,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2858,
	2329,
	2782,
	2782,
	2861,
	2332,
	2890,
	2890,
	2890,
	2890,
	2259,
	1884,
	2890,
	2834,
	2782,
	103,
	2308,
	2890,
	2890,
	2890,
	2770,
	2244,
	2858,
	2329,
	2858,
	2329,
	2834,
	2308,
	2890,
	2890,
	2329,
	2858,
	2308,
	2308,
	2308,
	2308,
	2890,
	4497,
	4497,
	2308,
	2308,
	2308,
	2308,
	2834,
	2308,
	2834,
	2824,
	2299,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2834,
	2308,
	2858,
	2329,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2091,
	1963,
	1963,
	1963,
	2308,
	2308,
	2292,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2834,
	2834,
	2834,
	2834,
	2834,
	2834,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2890,
	2834,
	2308,
	2861,
	2332,
	2816,
	2292,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2890,
	2292,
	2134,
	1774,
	2332,
	2292,
	2292,
	1320,
	2308,
	2308,
	2308,
	2890,
	2890,
	2890,
	2308,
	2308,
	2890,
	2890,
	2890,
	2134,
	2890,
	2890,
	1963,
	2858,
	929,
	390,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2834,
	2308,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2858,
	1963,
	2858,
	2890,
	2861,
	2332,
	2834,
	2308,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2861,
	2332,
	2858,
	2329,
	2824,
	2299,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	3878,
	929,
	2858,
	2890,
	2308,
	2308,
	2890,
	2816,
	2292,
	2858,
	2329,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2834,
	2308,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2834,
	2308,
	2834,
	2890,
	2292,
	2858,
	2858,
	2308,
	2308,
	2308,
	2308,
	989,
	2308,
	2890,
	2890,
	2890,
	2858,
	2834,
	2834,
	2308,
	2858,
	2834,
	2834,
	2308,
	2858,
	2834,
	2834,
	2308,
	2858,
	2834,
	2834,
	2308,
	2858,
	2858,
	2858,
	2890,
	2308,
	2308,
	2308,
	2308,
	2834,
	2308,
	2824,
	2299,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2858,
	2329,
	2858,
	2834,
	2308,
	2834,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2308,
	2308,
	2890,
	2890,
	2890,
	1963,
	2858,
	2858,
	1963,
	1963,
	2858,
	2726,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2292,
	2308,
	2890,
	2858,
	2329,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2834,
	2834,
	2834,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2890,
	2834,
	2890,
	2308,
	2308,
	2308,
	1963,
	1963,
	2308,
	2308,
	2308,
	836,
	2890,
	4497,
	2890,
	1963,
	2816,
	2292,
	2858,
	2329,
	2861,
	2332,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2816,
	2292,
	2816,
	2292,
	2861,
	2332,
	2824,
	2299,
	2816,
	2292,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	2834,
	2308,
	2861,
	2861,
	2834,
	2834,
	2308,
	2834,
	2816,
	2890,
	2890,
	2890,
	2890,
	2890,
	3734,
	2890,
	2890,
	2890,
	2890,
	2890,
	636,
	929,
	4020,
	172,
	390,
	2237,
	1884,
	1884,
	1884,
	929,
	1884,
	929,
	171,
	2890,
	3432,
	3192,
	3022,
	3432,
	414,
	3933,
	1302,
	758,
	2292,
	2858,
	2308,
	1177,
	2890,
	851,
	2890,
	746,
	1963,
	1963,
	2308,
	2308,
	2890,
	2890,
	4218,
	2890,
	4497,
	839,
	2890,
	2887,
	2358,
	2861,
	2332,
	2858,
	2329,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2861,
	2332,
	2861,
	2332,
	836,
	2890,
	2308,
	2308,
	2890,
	4045,
	2308,
	2308,
	2308,
	2292,
	530,
	2890,
	2308,
	2858,
	2858,
	2858,
	2726,
	1963,
	1963,
	670,
	2308,
	2308,
	2308,
	2890,
	4497,
	4497,
	2890,
	2890,
	2834,
	2308,
	2834,
	2308,
	2890,
	2890,
	2890,
	2890,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	2858,
	2329,
	2890,
	2890,
	2890,
	2890,
	2890,
	2834,
	2308,
	2890,
	2834,
	2308,
	2890,
	2834,
	2308,
	2890,
	2834,
	2308,
	2890,
	2834,
	2308,
	2890,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2834,
	2834,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2292,
	2292,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	1752,
	1752,
	2237,
	906,
	1298,
	2308,
	2308,
	2308,
	1298,
	2308,
	2308,
	1298,
	1298,
	1298,
	1298,
	1298,
	1298,
	755,
	755,
	755,
	755,
	1298,
	1298,
	2890,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2834,
	2834,
	2890,
	2890,
	2890,
	2890,
	2890,
	2308,
	2308,
	2890,
	2308,
	2308,
	2890,
	2803,
	2280,
	2803,
	2280,
	2890,
	2890,
	2885,
	1053,
	2890,
	2803,
	2280,
	2803,
	2280,
	2890,
	2890,
	2885,
	1053,
	2890,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2816,
	2292,
	2834,
	2308,
	2890,
	2885,
	2136,
	2358,
	2890,
	2890,
	2861,
	2332,
	2890,
	2885,
	2094,
	2332,
	2890,
	2816,
	2292,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2885,
	2131,
	2093,
	2890,
	4497,
	2816,
	2292,
	2834,
	2308,
	2861,
	2332,
	2861,
	2332,
	2885,
	2131,
	2093,
	2890,
	4497,
	2308,
	2308,
	2308,
	2308,
	2308,
	2308,
	2834,
	2308,
	2890,
	2858,
	2858,
	2858,
	2890,
	2861,
	2332,
	2834,
	2308,
	2858,
	2858,
	2890,
	2890,
	1597,
	2890,
	1597,
	2890,
	2803,
	2280,
	2803,
	2280,
	2890,
	2890,
	2885,
	1053,
	2890,
	2816,
	2292,
	2834,
	2308,
	2861,
	2332,
	2885,
	2890,
	4497,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2890,
	2885,
	2094,
	2332,
	2329,
	2890,
	2890,
	2834,
	2308,
	2816,
	2292,
	2816,
	2292,
	2890,
	672,
	2308,
	2308,
	2308,
	2308,
	2308,
	2890,
	2834,
	2308,
	2890,
	2890,
	672,
	2890,
	672,
	2890,
	2873,
	2345,
	2858,
	2329,
	2002,
	2890,
	2890,
	3733,
	3733,
	4061,
	-1,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2816,
	2292,
	2816,
	2292,
	2861,
	2332,
	2887,
	2887,
	2861,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2834,
	2858,
	2308,
	1963,
	1946,
	2890,
	2332,
	1991,
	1000,
	2016,
	1001,
	1001,
	2016,
	2890,
	4497,
	2858,
	2292,
	2890,
	2858,
	2834,
	2890,
	2834,
	2885,
	2356,
	2858,
	2329,
	2816,
	2292,
	2858,
	2329,
	2816,
	2292,
	2942,
	2406,
	2890,
	2890,
	2816,
	2292,
	2816,
	2292,
	2861,
	2332,
	2890,
	2858,
	2329,
	2816,
	2292,
	2890,
	2890,
	2308,
	2308,
	2858,
	2329,
	2861,
	2332,
	2885,
	2356,
	2849,
	2324,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2890,
	2816,
	2858,
	2329,
	2885,
	2356,
	2885,
	2356,
	2885,
	2356,
	2830,
	2304,
	2329,
	2830,
	2304,
	2329,
	2830,
	2304,
	2329,
	2292,
	2890,
	2308,
	2308,
	2834,
	2308,
	2834,
	2308,
	2890,
	2816,
	2816,
	2292,
	2816,
	2292,
	2858,
	2329,
	2885,
	2356,
	2885,
	2356,
	2292,
	2890,
	2890,
	2308,
	2308,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2861,
	2332,
	2885,
	2356,
	2849,
	2324,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2890,
	2308,
	2834,
	2308,
	2816,
	2292,
	2824,
	2299,
	2834,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2824,
	2299,
	2816,
	2292,
	2834,
	1298,
	2834,
	3878,
	3879,
	1298,
	410,
	223,
	3416,
	2890,
	4497,
	226,
	2834,
	2887,
	2885,
	2861,
	2816,
	868,
	2890,
	2955,
	2816,
	2861,
	2332,
	2858,
	2329,
	2816,
	2292,
	2858,
	2329,
	2887,
	2358,
	2845,
	2320,
	2834,
	2308,
	2849,
	2324,
	2816,
	2292,
	2824,
	2299,
	2885,
	2356,
	2292,
	2329,
	2890,
	2308,
	2308,
	2834,
	2308,
	2834,
	2308,
	2858,
	2329,
	2861,
	2332,
	2885,
	2356,
	2885,
	2356,
	2849,
	2324,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2890,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2834,
	2308,
	2890,
	2890,
	2890,
	2858,
	1782,
	2237,
	2308,
	1177,
	1302,
	2308,
	2237,
	1058,
	2237,
	2834,
	2834,
	2834,
	2890,
	2237,
	1884,
	2861,
	2332,
	2858,
	2329,
	2858,
	2329,
	2858,
	2329,
	2890,
	2308,
	2308,
	1746,
	969,
	2890,
	2890,
	2890,
	2890,
	1294,
	1324,
	4227,
	2834,
	2308,
	2890,
	2890,
	2890,
	2890,
	2890,
	4378,
	4378,
	4497,
	4497,
	4497,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2816,
	2292,
	2816,
	2292,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2861,
	2332,
	2858,
	2329,
	2816,
	2292,
	2816,
	2292,
	2816,
	2292,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2237,
	2890,
	2890,
	2887,
	3217,
	3593,
	3593,
	3719,
	3719,
	4218,
	1585,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	2382,
	4291,
	2890,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2834,
	2308,
	2890,
	2890,
	4451,
	2787,
	1345,
	2890,
	2890,
	4451,
	2787,
	2890,
	2861,
	4489,
	4389,
	2237,
	1884,
	4218,
	2890,
	4497,
	4497,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000400, { 0, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[3] = 
{
	{ (Il2CppRGCTXDataType)2, 1948 },
	{ (Il2CppRGCTXDataType)2, 1564 },
	{ (Il2CppRGCTXDataType)2, 1497 },
};
extern const CustomAttributesCacheGenerator g_Unity_XR_Interaction_Toolkit_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_Interaction_Toolkit_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_Interaction_Toolkit_CodeGenModule = 
{
	"Unity.XR.Interaction.Toolkit.dll",
	1635,
	s_methodPointers,
	184,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	3,
	s_rgctxValues,
	NULL,
	g_Unity_XR_Interaction_Toolkit_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
