﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.XR.OpenXR.Features.Mock.MockRuntime::.ctor()
extern void MockRuntime__ctor_m8E2086CD08568B1E7621905B54E0796308F245FD (void);
static Il2CppMethodPointer s_methodPointers[1] = 
{
	MockRuntime__ctor_m8E2086CD08568B1E7621905B54E0796308F245FD,
};
static const int32_t s_InvokerIndices[1] = 
{
	2890,
};
extern const CustomAttributesCacheGenerator g_Unity_XR_OpenXR_Features_MockRuntime_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_MockRuntime_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_MockRuntime_CodeGenModule = 
{
	"Unity.XR.OpenXR.Features.MockRuntime.dll",
	1,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_Unity_XR_OpenXR_Features_MockRuntime_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
