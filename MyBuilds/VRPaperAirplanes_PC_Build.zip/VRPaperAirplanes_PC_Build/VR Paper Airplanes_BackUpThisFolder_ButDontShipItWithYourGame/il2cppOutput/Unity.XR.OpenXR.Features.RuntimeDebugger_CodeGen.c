﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.IntPtr UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::HookGetInstanceProcAddr(System.IntPtr)
extern void RuntimeDebuggerOpenXRFeature_HookGetInstanceProcAddr_mB23453F1BC12217D08F3490236B83B0FAE1C8861 (void);
// 0x00000002 System.Void UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::RecvMsg(UnityEngine.Networking.PlayerConnection.MessageEventArgs)
extern void RuntimeDebuggerOpenXRFeature_RecvMsg_m4B3A679D5130A7DA70921CB87B63F1A51A39E165 (void);
// 0x00000003 System.IntPtr UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::Native_HookGetInstanceProcAddr(System.IntPtr,System.UInt32,System.UInt32)
extern void RuntimeDebuggerOpenXRFeature_Native_HookGetInstanceProcAddr_mC598EAE452C76E216DAA76377CB7D36965EBC465 (void);
// 0x00000004 System.Boolean UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::Native_GetDataForRead(System.IntPtr&,System.UInt32&)
extern void RuntimeDebuggerOpenXRFeature_Native_GetDataForRead_m00399A143A57F9E5623DD238CA542E1A82DD97FD (void);
// 0x00000005 System.Void UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::Native_StartDataAccess()
extern void RuntimeDebuggerOpenXRFeature_Native_StartDataAccess_mFC9FBE2EFFAA00353ADAF6275C3E696A85CA9D9F (void);
// 0x00000006 System.Void UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::Native_EndDataAccess()
extern void RuntimeDebuggerOpenXRFeature_Native_EndDataAccess_m72DD450D71C7E82C91BAABDBDC20386C179172DE (void);
// 0x00000007 System.Void UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::.ctor()
extern void RuntimeDebuggerOpenXRFeature__ctor_m439EFEF760C06B4AEDA07665B84E1EA5CA7D81E4 (void);
// 0x00000008 System.Void UnityEngine.XR.OpenXR.Features.RuntimeDebugger.RuntimeDebuggerOpenXRFeature::.cctor()
extern void RuntimeDebuggerOpenXRFeature__cctor_m836207D6D93FB9004748E48DE8357EEB115D4138 (void);
static Il2CppMethodPointer s_methodPointers[8] = 
{
	RuntimeDebuggerOpenXRFeature_HookGetInstanceProcAddr_mB23453F1BC12217D08F3490236B83B0FAE1C8861,
	RuntimeDebuggerOpenXRFeature_RecvMsg_m4B3A679D5130A7DA70921CB87B63F1A51A39E165,
	RuntimeDebuggerOpenXRFeature_Native_HookGetInstanceProcAddr_mC598EAE452C76E216DAA76377CB7D36965EBC465,
	RuntimeDebuggerOpenXRFeature_Native_GetDataForRead_m00399A143A57F9E5623DD238CA542E1A82DD97FD,
	RuntimeDebuggerOpenXRFeature_Native_StartDataAccess_mFC9FBE2EFFAA00353ADAF6275C3E696A85CA9D9F,
	RuntimeDebuggerOpenXRFeature_Native_EndDataAccess_m72DD450D71C7E82C91BAABDBDC20386C179172DE,
	RuntimeDebuggerOpenXRFeature__ctor_m439EFEF760C06B4AEDA07665B84E1EA5CA7D81E4,
	RuntimeDebuggerOpenXRFeature__cctor_m836207D6D93FB9004748E48DE8357EEB115D4138,
};
static const int32_t s_InvokerIndices[8] = 
{
	1710,
	2308,
	3546,
	3887,
	4497,
	4497,
	2890,
	4497,
};
extern const CustomAttributesCacheGenerator g_Unity_XR_OpenXR_Features_RuntimeDebugger_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_RuntimeDebugger_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_RuntimeDebugger_CodeGenModule = 
{
	"Unity.XR.OpenXR.Features.RuntimeDebugger.dll",
	8,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_Unity_XR_OpenXR_Features_RuntimeDebugger_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
