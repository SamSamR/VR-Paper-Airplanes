﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void AirPlanePhysics::Awake()
extern void AirPlanePhysics_Awake_mB0BBF2136AF5C82C9BD0E594618AD3AC24C66EA9 (void);
// 0x00000002 System.Void AirPlanePhysics::FixedUpdate()
extern void AirPlanePhysics_FixedUpdate_m313CA8DD8BF5F5EE43419583DFFEE5F838A6A584 (void);
// 0x00000003 System.Void AirPlanePhysics::isGrabbed()
extern void AirPlanePhysics_isGrabbed_mC58CCD7BCB4340A08465389DA238B44531F946BF (void);
// 0x00000004 System.Void AirPlanePhysics::notGrabbed()
extern void AirPlanePhysics_notGrabbed_m2171D9DEE2C20AE44E4C24C2C892B5BC8CA9C5F8 (void);
// 0x00000005 System.Collections.IEnumerator AirPlanePhysics::enableGravity()
extern void AirPlanePhysics_enableGravity_mE7B99306E251EE15F9561929A9E11DEF6D6E5FFE (void);
// 0x00000006 System.Void AirPlanePhysics::OnTriggerExit(UnityEngine.Collider)
extern void AirPlanePhysics_OnTriggerExit_mBE5A5F918002E364E7FED21501220342025ABC4E (void);
// 0x00000007 System.Void AirPlanePhysics::OnCollisionEnter(UnityEngine.Collision)
extern void AirPlanePhysics_OnCollisionEnter_mFE624EFA54F92F381938B86ADDE00C3DE4B75851 (void);
// 0x00000008 System.Void AirPlanePhysics::.ctor()
extern void AirPlanePhysics__ctor_m3608F0C95E4509331B49B2B6112EC50BAF136FA4 (void);
// 0x00000009 System.Void AirPlanePhysics/<enableGravity>d__12::.ctor(System.Int32)
extern void U3CenableGravityU3Ed__12__ctor_m7E41019B54AFAA1B5F385EF299B7CD8EB5C2B095 (void);
// 0x0000000A System.Void AirPlanePhysics/<enableGravity>d__12::System.IDisposable.Dispose()
extern void U3CenableGravityU3Ed__12_System_IDisposable_Dispose_m01AD3DD3E53580ED79DB591C0C290C304F3CD78A (void);
// 0x0000000B System.Boolean AirPlanePhysics/<enableGravity>d__12::MoveNext()
extern void U3CenableGravityU3Ed__12_MoveNext_m6C834BD2B8B179B6FC93ED526239ED453C759E13 (void);
// 0x0000000C System.Object AirPlanePhysics/<enableGravity>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CenableGravityU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m45E1BDE7E0E35A6D6D28BF5945F56CD35146221A (void);
// 0x0000000D System.Void AirPlanePhysics/<enableGravity>d__12::System.Collections.IEnumerator.Reset()
extern void U3CenableGravityU3Ed__12_System_Collections_IEnumerator_Reset_m2D8C6F450365D15647B1529E343CFF15CB4F5C0E (void);
// 0x0000000E System.Object AirPlanePhysics/<enableGravity>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CenableGravityU3Ed__12_System_Collections_IEnumerator_get_Current_mABC768192C954672765A28B9C67642C5E7C8EA26 (void);
// 0x0000000F System.Void AirplaneBehaviour::Awake()
extern void AirplaneBehaviour_Awake_m93BFA5041E1CBC5BCB1AD8BF6BBFA7BFB6A909E8 (void);
// 0x00000010 System.Void AirplaneBehaviour::isGrabbed()
extern void AirplaneBehaviour_isGrabbed_m23E472F46D773BD722C742C45AE4017A375F64E6 (void);
// 0x00000011 System.Void AirplaneBehaviour::notGrabbed()
extern void AirplaneBehaviour_notGrabbed_m3E1AA0E21C02DDA0C3DE7B3F6427514BF6555BC0 (void);
// 0x00000012 System.Void AirplaneBehaviour::OnTriggerEnter(UnityEngine.Collider)
extern void AirplaneBehaviour_OnTriggerEnter_m3ECED2738ABA9A793072AA1F0A72A9309FCD1A4F (void);
// 0x00000013 System.Void AirplaneBehaviour::OnCollisionEnter(UnityEngine.Collision)
extern void AirplaneBehaviour_OnCollisionEnter_m367FF392B889FB2FBA068882D8A24886036FAA93 (void);
// 0x00000014 System.Void AirplaneBehaviour::.ctor()
extern void AirplaneBehaviour__ctor_m279B66357CF9C55DDC47BB124B0AC728492DB1D7 (void);
// 0x00000015 System.Void ChangeLevel::Start()
extern void ChangeLevel_Start_m4979F83BADD865245FBDB157935FFD9AF1C38E30 (void);
// 0x00000016 System.Void ChangeLevel::OnTriggerEnter(UnityEngine.Collider)
extern void ChangeLevel_OnTriggerEnter_m6822A9F83A2348BCB1540B5A4C360DA12D7F09E0 (void);
// 0x00000017 System.Void ChangeLevel::.ctor()
extern void ChangeLevel__ctor_m04A1580C1031D1A07639022C6B262618F552F9A2 (void);
// 0x00000018 System.Void ChildRotation::Awake()
extern void ChildRotation_Awake_m244BEF106A088971B09470BED60DC1CD37300046 (void);
// 0x00000019 System.Void ChildRotation::FixedUpdate()
extern void ChildRotation_FixedUpdate_m8DEF8481587A67FD4F884896745144D1BBBEACDF (void);
// 0x0000001A System.Void ChildRotation::axisSelection(ChildRotation/Direction)
extern void ChildRotation_axisSelection_m9C7555FA41CB7057B1F45198C0DB0CAE80239B00 (void);
// 0x0000001B System.Void ChildRotation::OnTriggerStay(UnityEngine.Collider)
extern void ChildRotation_OnTriggerStay_mB7209287E611DD4976DA9F3C85677A417A9EE5B2 (void);
// 0x0000001C System.Void ChildRotation::.ctor()
extern void ChildRotation__ctor_m63191F23E36BCC421CA097B822AB7CB95BC54D89 (void);
// 0x0000001D System.Void GameManager::Awake()
extern void GameManager_Awake_m22F42B2A82708B10F652CAD8F2E0A4767110FF30 (void);
// 0x0000001E System.Void GameManager::Update()
extern void GameManager_Update_mC9303BA7C3117BD861F49F8E36151CC52117E6C1 (void);
// 0x0000001F System.Void GameManager::BinHit(System.Int32)
extern void GameManager_BinHit_m8034A1E6DE5E5A0FCAF5A57EDEB2509DDD5E35B8 (void);
// 0x00000020 System.Void GameManager::FloorHit()
extern void GameManager_FloorHit_m0FFE73A6BE907BF89AC8E8E1CB98E10B9B6C9197 (void);
// 0x00000021 System.Void GameManager::myTimer()
extern void GameManager_myTimer_m337989A7B86AE97C4939BD1A6CE207287B6CB832 (void);
// 0x00000022 System.Void GameManager::ReadyNextScene()
extern void GameManager_ReadyNextScene_m9A23CECFA0CA665DDD8BBB19C0D2FDB77DED0565 (void);
// 0x00000023 System.Collections.IEnumerator GameManager::buttonWait()
extern void GameManager_buttonWait_m039E4118017CF537184AA7694B0549C2506CC349 (void);
// 0x00000024 System.Void GameManager::ChangeScene()
extern void GameManager_ChangeScene_m09E1EAF446DD7827CFCC300258111DAD4AE8443A (void);
// 0x00000025 System.Void GameManager::.ctor()
extern void GameManager__ctor_mE8666F6D0CA9C31E16B719F79780DC4B0245B64D (void);
// 0x00000026 System.Void GameManager/<buttonWait>d__16::.ctor(System.Int32)
extern void U3CbuttonWaitU3Ed__16__ctor_m4A9189C1F318A3C59E1B628A300D76CACC43C163 (void);
// 0x00000027 System.Void GameManager/<buttonWait>d__16::System.IDisposable.Dispose()
extern void U3CbuttonWaitU3Ed__16_System_IDisposable_Dispose_mF4C40CF05092899340562F9C68AA6DC58EC1D30B (void);
// 0x00000028 System.Boolean GameManager/<buttonWait>d__16::MoveNext()
extern void U3CbuttonWaitU3Ed__16_MoveNext_mBF8440D6AF7D8267BF98EC77CBF88FA6CCA570B2 (void);
// 0x00000029 System.Object GameManager/<buttonWait>d__16::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CbuttonWaitU3Ed__16_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m54B484CC42314578BC47D5ABF7DC40FD81CBEAC3 (void);
// 0x0000002A System.Void GameManager/<buttonWait>d__16::System.Collections.IEnumerator.Reset()
extern void U3CbuttonWaitU3Ed__16_System_Collections_IEnumerator_Reset_m83DACB2D8C72BB0B824361591AAD5ABBA4C0B5C0 (void);
// 0x0000002B System.Object GameManager/<buttonWait>d__16::System.Collections.IEnumerator.get_Current()
extern void U3CbuttonWaitU3Ed__16_System_Collections_IEnumerator_get_Current_mC2D429CC1374A6A8EF2D34FE4B96C2BF99B5A7CA (void);
// 0x0000002C System.Void Clock::Awake()
extern void Clock_Awake_m805588166684B046EC8C358E039EA1308A7BA75C (void);
// 0x0000002D System.Void Clock::Update()
extern void Clock_Update_mC25EF80523A8D953674A28A6C5DC457B2F6F0E91 (void);
// 0x0000002E System.Void Clock::timerStart()
extern void Clock_timerStart_mC3C113FF5B625A779DF7DCAD6BD4B559FD1B5CCC (void);
// 0x0000002F System.Void Clock::timerStop()
extern void Clock_timerStop_m7F0C239DD6CE6FB5FB203609BB4E7205234A7F12 (void);
// 0x00000030 System.Void Clock::.ctor()
extern void Clock__ctor_mBDFD7E68A1572604275561ED3CA52165D2DBAF9D (void);
// 0x00000031 System.Void ScoreChanger::Awake()
extern void ScoreChanger_Awake_m7A12E4006BC04AD3C2E042E2F39A9E99BE2DC2B5 (void);
// 0x00000032 System.Void ScoreChanger::Update()
extern void ScoreChanger_Update_m6D860976051DCC66A78526B31247BBC7753BAB58 (void);
// 0x00000033 System.Void ScoreChanger::incrementPoints()
extern void ScoreChanger_incrementPoints_m0F460C0941757880C85A4B0F6D27040BC93A902A (void);
// 0x00000034 System.Void ScoreChanger::decreasePoints()
extern void ScoreChanger_decreasePoints_mB0FADF07793A0CFB087DBC9F6380D9BCCC2FBF8A (void);
// 0x00000035 System.Void ScoreChanger::.ctor()
extern void ScoreChanger__ctor_m1DF25C8C33BD9B9A3E980EA50DD282381490A197 (void);
// 0x00000036 System.Void PlaneSpawner::Awake()
extern void PlaneSpawner_Awake_mED03C0829D1B40846EE934B603119ECDB3017887 (void);
// 0x00000037 System.Void PlaneSpawner::OnTriggerEnter(UnityEngine.Collider)
extern void PlaneSpawner_OnTriggerEnter_m5EF37811ED72B73F7544474B12554D3CBAED0947 (void);
// 0x00000038 System.Void PlaneSpawner::OnTriggerExit(UnityEngine.Collider)
extern void PlaneSpawner_OnTriggerExit_m106CFB0C048A5224C35EBC0E36D5FB122513118D (void);
// 0x00000039 System.Void PlaneSpawner::spawnPlain()
extern void PlaneSpawner_spawnPlain_mB4D6CDC71EE998D8EA8A054F13DE3D8BB5FCA0FE (void);
// 0x0000003A System.Void PlaneSpawner::.ctor()
extern void PlaneSpawner__ctor_m88D1F2A34C93FEEC84E41AA8983AE84796BF6D29 (void);
// 0x0000003B System.Void Rotation::Awake()
extern void Rotation_Awake_m3AEB84AB620F08A54E80A8295DE0D6D844DD89BF (void);
// 0x0000003C System.Void Rotation::FixedUpdate()
extern void Rotation_FixedUpdate_m43CDC81683CDA94FABC8416CF7AC5A5A453A818F (void);
// 0x0000003D System.Void Rotation::axisSelection(Rotation/Direction)
extern void Rotation_axisSelection_mFA0E4F1619191C2D8D73632270762F3FA0034C01 (void);
// 0x0000003E System.Void Rotation::.ctor()
extern void Rotation__ctor_mE37308CA0B03685698CC3A3EFD8EF606585B6297 (void);
// 0x0000003F System.Void TrashBin::Awake()
extern void TrashBin_Awake_m2B78BC636A588146DA9A2CC5568117489E03EBDE (void);
// 0x00000040 System.Void TrashBin::OnTriggerEnter(UnityEngine.Collider)
extern void TrashBin_OnTriggerEnter_m4A9E89B13FD5AADE9ACBDC3461CDF3EA0F109B76 (void);
// 0x00000041 System.Void TrashBin::.ctor()
extern void TrashBin__ctor_m00601F6BBAB51B5731B636F2995155AD2A42D724 (void);
static Il2CppMethodPointer s_methodPointers[65] = 
{
	AirPlanePhysics_Awake_mB0BBF2136AF5C82C9BD0E594618AD3AC24C66EA9,
	AirPlanePhysics_FixedUpdate_m313CA8DD8BF5F5EE43419583DFFEE5F838A6A584,
	AirPlanePhysics_isGrabbed_mC58CCD7BCB4340A08465389DA238B44531F946BF,
	AirPlanePhysics_notGrabbed_m2171D9DEE2C20AE44E4C24C2C892B5BC8CA9C5F8,
	AirPlanePhysics_enableGravity_mE7B99306E251EE15F9561929A9E11DEF6D6E5FFE,
	AirPlanePhysics_OnTriggerExit_mBE5A5F918002E364E7FED21501220342025ABC4E,
	AirPlanePhysics_OnCollisionEnter_mFE624EFA54F92F381938B86ADDE00C3DE4B75851,
	AirPlanePhysics__ctor_m3608F0C95E4509331B49B2B6112EC50BAF136FA4,
	U3CenableGravityU3Ed__12__ctor_m7E41019B54AFAA1B5F385EF299B7CD8EB5C2B095,
	U3CenableGravityU3Ed__12_System_IDisposable_Dispose_m01AD3DD3E53580ED79DB591C0C290C304F3CD78A,
	U3CenableGravityU3Ed__12_MoveNext_m6C834BD2B8B179B6FC93ED526239ED453C759E13,
	U3CenableGravityU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m45E1BDE7E0E35A6D6D28BF5945F56CD35146221A,
	U3CenableGravityU3Ed__12_System_Collections_IEnumerator_Reset_m2D8C6F450365D15647B1529E343CFF15CB4F5C0E,
	U3CenableGravityU3Ed__12_System_Collections_IEnumerator_get_Current_mABC768192C954672765A28B9C67642C5E7C8EA26,
	AirplaneBehaviour_Awake_m93BFA5041E1CBC5BCB1AD8BF6BBFA7BFB6A909E8,
	AirplaneBehaviour_isGrabbed_m23E472F46D773BD722C742C45AE4017A375F64E6,
	AirplaneBehaviour_notGrabbed_m3E1AA0E21C02DDA0C3DE7B3F6427514BF6555BC0,
	AirplaneBehaviour_OnTriggerEnter_m3ECED2738ABA9A793072AA1F0A72A9309FCD1A4F,
	AirplaneBehaviour_OnCollisionEnter_m367FF392B889FB2FBA068882D8A24886036FAA93,
	AirplaneBehaviour__ctor_m279B66357CF9C55DDC47BB124B0AC728492DB1D7,
	ChangeLevel_Start_m4979F83BADD865245FBDB157935FFD9AF1C38E30,
	ChangeLevel_OnTriggerEnter_m6822A9F83A2348BCB1540B5A4C360DA12D7F09E0,
	ChangeLevel__ctor_m04A1580C1031D1A07639022C6B262618F552F9A2,
	ChildRotation_Awake_m244BEF106A088971B09470BED60DC1CD37300046,
	ChildRotation_FixedUpdate_m8DEF8481587A67FD4F884896745144D1BBBEACDF,
	ChildRotation_axisSelection_m9C7555FA41CB7057B1F45198C0DB0CAE80239B00,
	ChildRotation_OnTriggerStay_mB7209287E611DD4976DA9F3C85677A417A9EE5B2,
	ChildRotation__ctor_m63191F23E36BCC421CA097B822AB7CB95BC54D89,
	GameManager_Awake_m22F42B2A82708B10F652CAD8F2E0A4767110FF30,
	GameManager_Update_mC9303BA7C3117BD861F49F8E36151CC52117E6C1,
	GameManager_BinHit_m8034A1E6DE5E5A0FCAF5A57EDEB2509DDD5E35B8,
	GameManager_FloorHit_m0FFE73A6BE907BF89AC8E8E1CB98E10B9B6C9197,
	GameManager_myTimer_m337989A7B86AE97C4939BD1A6CE207287B6CB832,
	GameManager_ReadyNextScene_m9A23CECFA0CA665DDD8BBB19C0D2FDB77DED0565,
	GameManager_buttonWait_m039E4118017CF537184AA7694B0549C2506CC349,
	GameManager_ChangeScene_m09E1EAF446DD7827CFCC300258111DAD4AE8443A,
	GameManager__ctor_mE8666F6D0CA9C31E16B719F79780DC4B0245B64D,
	U3CbuttonWaitU3Ed__16__ctor_m4A9189C1F318A3C59E1B628A300D76CACC43C163,
	U3CbuttonWaitU3Ed__16_System_IDisposable_Dispose_mF4C40CF05092899340562F9C68AA6DC58EC1D30B,
	U3CbuttonWaitU3Ed__16_MoveNext_mBF8440D6AF7D8267BF98EC77CBF88FA6CCA570B2,
	U3CbuttonWaitU3Ed__16_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m54B484CC42314578BC47D5ABF7DC40FD81CBEAC3,
	U3CbuttonWaitU3Ed__16_System_Collections_IEnumerator_Reset_m83DACB2D8C72BB0B824361591AAD5ABBA4C0B5C0,
	U3CbuttonWaitU3Ed__16_System_Collections_IEnumerator_get_Current_mC2D429CC1374A6A8EF2D34FE4B96C2BF99B5A7CA,
	Clock_Awake_m805588166684B046EC8C358E039EA1308A7BA75C,
	Clock_Update_mC25EF80523A8D953674A28A6C5DC457B2F6F0E91,
	Clock_timerStart_mC3C113FF5B625A779DF7DCAD6BD4B559FD1B5CCC,
	Clock_timerStop_m7F0C239DD6CE6FB5FB203609BB4E7205234A7F12,
	Clock__ctor_mBDFD7E68A1572604275561ED3CA52165D2DBAF9D,
	ScoreChanger_Awake_m7A12E4006BC04AD3C2E042E2F39A9E99BE2DC2B5,
	ScoreChanger_Update_m6D860976051DCC66A78526B31247BBC7753BAB58,
	ScoreChanger_incrementPoints_m0F460C0941757880C85A4B0F6D27040BC93A902A,
	ScoreChanger_decreasePoints_mB0FADF07793A0CFB087DBC9F6380D9BCCC2FBF8A,
	ScoreChanger__ctor_m1DF25C8C33BD9B9A3E980EA50DD282381490A197,
	PlaneSpawner_Awake_mED03C0829D1B40846EE934B603119ECDB3017887,
	PlaneSpawner_OnTriggerEnter_m5EF37811ED72B73F7544474B12554D3CBAED0947,
	PlaneSpawner_OnTriggerExit_m106CFB0C048A5224C35EBC0E36D5FB122513118D,
	PlaneSpawner_spawnPlain_mB4D6CDC71EE998D8EA8A054F13DE3D8BB5FCA0FE,
	PlaneSpawner__ctor_m88D1F2A34C93FEEC84E41AA8983AE84796BF6D29,
	Rotation_Awake_m3AEB84AB620F08A54E80A8295DE0D6D844DD89BF,
	Rotation_FixedUpdate_m43CDC81683CDA94FABC8416CF7AC5A5A453A818F,
	Rotation_axisSelection_mFA0E4F1619191C2D8D73632270762F3FA0034C01,
	Rotation__ctor_mE37308CA0B03685698CC3A3EFD8EF606585B6297,
	TrashBin_Awake_m2B78BC636A588146DA9A2CC5568117489E03EBDE,
	TrashBin_OnTriggerEnter_m4A9E89B13FD5AADE9ACBDC3461CDF3EA0F109B76,
	TrashBin__ctor_m00601F6BBAB51B5731B636F2995155AD2A42D724,
};
static const int32_t s_InvokerIndices[65] = 
{
	2890,
	2890,
	2890,
	2890,
	2834,
	2308,
	2308,
	2890,
	2292,
	2890,
	2858,
	2834,
	2890,
	2834,
	2890,
	2890,
	2890,
	2308,
	2308,
	2890,
	2890,
	2308,
	2890,
	2890,
	2890,
	2292,
	2308,
	2890,
	2890,
	2890,
	2292,
	2890,
	2890,
	2890,
	2834,
	2890,
	2890,
	2292,
	2890,
	2858,
	2834,
	2890,
	2834,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2890,
	2308,
	2308,
	2890,
	2890,
	2890,
	2890,
	2292,
	2890,
	2890,
	2308,
	2890,
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	65,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
